#' Check if file exists
#'
#' @param file character string, name of file(s).
#' @param ... further arguments passed to or from other methods.
#' @return logical
#' @export file_exists
#' @examples
#' # specify file (which exists)
#' file <- system.file("extdata/control.inp", package = "controlR")
#' file_exists(file = file)
#'
#' # in case a file does not exists
#' file <- system.file("extdata/CoNtRoL.inp", package = "controlR")
#' file_exists(file = file, case_sensitive = FALSE)
#' file_exists(file = file, case_sensitive = TRUE)
file_exists <- function(file, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("case_sensitive", "quiet")
  case_sensitive <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", paste(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(case_sensitive)) case_sensitive <- TRUE
  if (is.null(quiet)) quiet <- FALSE

  # --- main part of procedure ---

  # check if file exists
  exists <- file.exists(file)
  if (!all(exists)) {

    if (!quiet) message(paste0("\nfile does not exists '", basename(file[!exists]), "'"))

  } else {

    # check if case sensitive (only filename and not directory)
    if (case_sensitive) {

      # list files
      list_files <- list.files(path = unique(dirname(file)))
      idx <- is.na(match(x = basename(file), table = list_files))

      if (any(idx)) {
        if (!quiet) message(paste0("\nfile does not exists '", basename(file[idx]), "' (R is case-sensitive)"))
        exists[idx] <- FALSE
      }
    }
  }

  # --- return of procedure ---

  return(exists)
}
