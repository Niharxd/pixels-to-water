#' SWAPtools
#'
#' \href{https://www.swap.wur.nl}{SWAP (Soil, Water, Atmosphere and Plant)}.
#' R-scripts for preparation of weather and precipitation data for \href{https://www.knmi.nl/home}{KNMI} weather and precipitation stations.
#' R-scripts for handling dynamic SWAP templates (for regional, sensitivity or uncertainty analyses).
#' R-scripts for handling SWAP simulations (submitting multiple simulations using sqlite database or EXCEL).
#' R-scripts for visualising individual SWAP simulation results (including modelperformance indexes)
#'
"_PACKAGE"
