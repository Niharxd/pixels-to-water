#' Create plot with selection of soil profiles of the Dutch soil map
#'
#' @param ... Arguments to pass, either \code{soil_id}, \code{profile_id}, \code{bofek_id} or \code{cluster_id} should be specified. Look at \code{Details} for further arguments to pass.
#' @importFrom readr read_rds read_csv
#' @importFrom fs path_package
#' @importFrom stringr str_c str_detect str_split str_replace_all
#' @importFrom dplyr mutate filter select rename arrange left_join group_by ungroup lag pull
#' @importFrom rlang .data
#' @importFrom ggplot2 ggplot aes geom_text scale_fill_manual coord_cartesian labs position_stack theme element_blank
#' @importFrom ggpattern geom_col_pattern scale_pattern_manual
#' @importFrom controlR get_my_theme create_label
#' @export plot_soilprofile
#' @description Creating a plot for a selection of soil profiles (either specified by \code{soil_id}, \code{profile_id}, \code{bofek_id} or \code{cluster_id}).
#' @details
#' Base information is the Dutch soil map (1:50,000) distinguishing 370 soil profiles (\href{https://edepot.wur.nl/298371}{de Vries, 1999}).
#' Each soil profile contains a sequence of soil layers that are linked to texture groups of the Staringreeks (\href{https://edepot.wur.nl/512761}{Heinen et al., 2020}).
#' Based on the soil physical properties, i.e. water retention and hydraulic conductivity, clusters of soil profiles can be created.
#'
#' Soil profiles to be included in the plot can be selected by \code{soil_id} (options are 1-370) or \code{profile_id} (vector of soil profile numbers mentioned in \href{https://edepot.wur.nl/541544}{Heinen et al., 2021}).
#' Alternatively the dominant soil profiles within a BOFEK cluster can be selected by specifying \code{bofek_id}. All soil profiles within a BOFEK cluster can be selected by specifying a single \code{cluster_id}.
#' In case of a selection by \code{bofek_id} the type of BOFEK should be specified, options are 'BOFEK2012' (\href{https://edepot.wur.nl/247678}{Wosten et al., 2013}) or 'BOFEK2020' (\href{https://edepot.wur.nl/541544}{Heinen et al., 2021}).
#'
#' The maximum depth of the soil profiles to be plotted is set to -120 cm below soil surface. Optionally this can be adjusted by specifying \code{max_depth}.
#'
#' As default the soil profiles are arranged by area which is presented at the top of the graph, this can be turned off by setting \code{plot_area} to FALSE. In case \code{plot_area} is set to FALSE the soil profiles are arranged by user defined input.
#'
#' The labels of the plot can be set to 'EN' (English; default) or 'NL' (Dutch) using \code{language}.
#' @examples
#' # plot selection of soil profiles
#' print(plot_soilprofile(soil_id = c(36, 61, 79, 253, 367)))
#'
#' # plot selection of bofek_id
#' print(plot_soilprofile(bofek_id = c(1006, 2006, 3015, 4018, 5007), type = "BOFEK2020"))
#'
#' # plot selection within BOFEK cluster
#' print(plot_soilprofile(cluster_id = 3015, type = "BOFEK2020"))
plot_soilprofile <- function(...) {

  thickness <- sfu <- label <- NULL

  # --- initial part of procedure ---

  opt_selection <- c("soil_id", "profile_id", "bofek_id", "cluster_id")
  opt_type <- c("BODEM", "BOFEK2012", "BOFEK2020")

  # set optional arguments
  opt_param <- c("soil_id", "profile_id", "bofek_id", "cluster_id", "type", "file_prof", "file_area", "file_sfu", "max_depth", "plot_area", "language")
  soil_id <- profile_id <- bofek_id <- cluster_id <- type <- file_prof <- file_area <- file_sfu <- max_depth <- plot_area <- language <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # load default soilinfo
  soilinfo <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/soilinfo.rds"))

  # check used arguments
  selection <- opt_selection[!c(is.null(soil_id), is.null(profile_id), is.null(bofek_id), is.null(cluster_id))]
  if (length(selection) != 1) stop("either 'soil_id', 'profile_id', 'bofek_id' or 'cluster_id' should be specified")
  if (is.null(type) & selection %in% c("bofek_id", "cluster_id")) stop("in case of 'bofek_id' or 'cluster_id' the BOFEK version should be specified using 'type' (option: 'BOFEK2012' or 'BOFEK2020')")
  if (!is.null(type) & selection %in% c("bofek_id", "cluster_id")) {
    if (!type %in% c("BOFEK2012", "BOFEK2020")) stop("in case of 'bofek_id' or 'cluster_id' the BOFEK version should be specified with 'BOFEK2012' or 'BOFEK2020'")
  }

  if (is.null(file_prof)) db_prof <- soilinfo$profiles
  if (is.null(file_area)) db_area <- soilinfo$area
  if (is.null(file_sfu)) db_sfu <- soilinfo$sfu
  if (is.null(type)) type <- "BODEM"
  if (type == "BOFEK2012") db_link <- soilinfo$BOFEK2012
  if (type == "BOFEK2020") db_link <- soilinfo$BOFEK2020
  if (is.null(max_depth)) max_depth <- -120.0
  if (is.null(plot_area)) plot_area <- TRUE
  if (is.null(language)) language <- "NL"

  # --- main part of procedure ---

  # load user-information if specified (profile, area, sfu)
  if (!is.null(file_prof)) db_prof <- read_csv(file = file_prof, col_types = "icdd", progress = FALSE)
  if (!is.null(file_area)) db_area <- read_csv(file = file_area, col_types = "ddd", progress = FALSE)
  if (!is.null(file_sfu)) db_sfu <- read_csv(file = file_sfu, col_types = "ccccc", progress = FALSE)

  # check selected type
  if (!type %in% opt_type) stop(str_c("'type' should have one of the following options: '", str_c(opt_type, collapse = "' '"), "'"))

  # select profiles in case of BOFEK id's
  if (selection == "bofek_id") {

    # change label of profile
    db_area <- left_join(x = db_area, y = db_link, by = join_by("soil_id")) |>
      mutate(profile_id = .data$BOFEK) |>
      select(-"BOFEK")

    # extract BOFEK cluster
    db_bofek <- db_link |>
      filter(.data$BOFEK %in% bofek_id & .data$dominant == 1)

    # check selected BOFEK id's
    if (nrow(db_bofek) != length(bofek_id)) warning(str_c("unknown BOFEK selected: '", str_c(bofek_id[!bofek_id %in% db_bofek$BOFEK], collapse = "' '"), "'"))

    # select soil id's
    s_soil_id <- db_bofek |>
      mutate(order = match(x = .data$BOFEK, table = bofek_id)) |>
      arrange(.data$order) |>
      pull("soil_id")

    # check selected SOIL id's
    if (length(s_soil_id) == 0) stop("no profiles to plot")
  }

  # select profiles in case of BOFEK cluster
  if (selection == "cluster_id") {

    if (length(cluster_id) > 1) stop("only a single is cluster allowed")
    if (!cluster_id %in% db_link$BOFEK) stop("unknown cluster selected")

    # extract BOFEK cluster
    s_soil_id <- db_link |>
      filter(.data$BOFEK == cluster_id) |>
      pull("soil_id")

    # check selected SOIL id's
    if (length(s_soil_id) == 0) stop("no profiles to plot")
  }

  # select profiles in case of SOIL id
  if (selection == "soil_id") {

    # extract soil_id
    s_soil_id <- soil_id
    s_soil_id <- db_area |>
      filter(.data$soil_id %in% s_soil_id) |>
      mutate(order = match(x = .data$soil_id, table = s_soil_id)) |>
      arrange(.data$order) |>
      pull("soil_id")

    # check selected SOIL id's
    if (length(s_soil_id) != length(soil_id)) warning(str_c("unknown soilprofile selected: '", str_c(soil_id[!soil_id %in% s_soil_id], collapse = "' '"), "'"))
    if (length(s_soil_id) == 0) stop("no profiles to plot")

  }

  # select profiles in case of PROFILE id
  if (selection == "profile_id") {

    # extract soil_id
    s_profile_id <- profile_id
    db_profile <- db_area |>
      filter(.data$profile_id %in% s_profile_id)

    # check selected BOFEK id's
    if (nrow(db_profile) != length(profile_id)) warning(str_c("unknown PROFILE selected: '", str_c(profile_id[!profile_id %in% db_profile$profile_id], collapse = "' '"), "'"))

    # select soil id's
    s_soil_id <- db_profile |>
      mutate(order = match(x = .data$profile_id, table = s_profile_id)) |>
      arrange(.data$order) |>
      pull("soil_id")

    # check selected SOIL id's
    if (length(s_soil_id) == 0) stop("no profiles to plot")

  }

  # filter soil
  db_soil <- db_prof |>
    filter(.data$soil_id %in% s_soil_id) |>
    group_by(.data$soil_id) |>
    mutate(
      y_pos = pmin(-max_depth, cumsum(.data$thickness)),
      y_label = 0.5 * .data$y_pos + 0.5 * lag(x = .data$y_pos, default = 0)) |>
    ungroup() |>
    select("soil_id", "sfu", "order", "thickness", "y_label")

  # area info
  db_area <- db_area |>
    filter(.data$soil_id %in% s_soil_id) |>
    mutate(label = str_c(signif(x = .data$area, digits = 3), " ha"))

  # order by area (default)
  if (plot_area | selection == "cluster_id") {
    db_area <- db_area |>
      arrange(-.data$area)
  } else {
    db_area <- db_area |>
      mutate(order = match(x = .data$soil_id, table = s_soil_id)) |>
      arrange(.data$order)
  }

  # set dataframe figure and legend
  db_soil <- left_join(x = db_soil, y = db_sfu, by = join_by("sfu")) |>
    rename(label = ifelse(language == "NL", "sfu_label_NL", "sfu_label_EN")) |>
    mutate(label = str_c(.data$sfu, "\n", str_replace_all(string = .data$label, pattern = "\\\\n", replacement = "\n"))) |>
    select("soil_id", "sfu", "order", "thickness", "y_label", "label")

  db_legend <- db_sfu |>
    filter(.data$sfu %in% db_soil$sfu)

  # create factors
  db_soil$soil_id <- factor(x = db_soil$soil_id, levels = db_area$soil_id, labels = db_area$profile_id, ordered = TRUE)
  db_soil$order <- factor(x = db_soil$order, levels = 1:max(db_soil$order), ordered = TRUE)
  db_area$soil_id <- factor(x = db_area$soil_id, levels = db_area$soil_id, labels = db_area$profile_id, ordered = TRUE)
  db_legend$sfu <- factor(x = db_legend$sfu, levels = db_legend$sfu, ordered = TRUE)

  # set labels
  if (language == "NL") {
    x_label <- ifelse(selection  == "bofek_id", "BOFEK", "profiel")
    y_label <- "diepte"
    y_unit <- "cm+mv"
  }
  if (language == "EN") {
    x_label <- ifelse(selection  == "bofek_id", "BOFEK", "profile")
    y_label <- "depth"
    y_unit <- "cm+MSL"
  }

  # create plot
  P <- ggplot(data = db_soil) +
    geom_col_pattern(aes(x = soil_id, y = -thickness, fill = sfu, pattern = sfu, group = order), colour = "grey75", pattern_fill = "grey75", pattern_angle = 10, pattern_density = 0.08, pattern_alpha = 0.5, pattern_linetype = "blank", position = position_stack(reverse = TRUE), alpha = 0.7) +
    geom_text(aes(x = soil_id, y = -y_label, label = label), colour = "grey15", fontface = "bold", size = 2.5) +
    scale_pattern_manual(values = db_legend$pattern, guide = "none") +
    scale_fill_manual(values = db_legend$fill, guide = "none") +
    coord_cartesian(ylim = c(max_depth, 2)) +
    labs(x = create_label(label = x_label), y = create_label(label = y_label, unit = y_unit)) +
    get_my_theme("figure") +
    theme(panel.grid.major.x = element_blank())

  # add area of each soil profile
  if (plot_area) P <- P + geom_text(data = db_area, aes(x = soil_id, y = 2.0, label = label), fontface = "italic", size = 3.0)

  # --- return of procedure ---

  return(P)
}

#' Create figure with SWAP results
#'
#' @param ctrl character string of figure template.
#' @param ... further arguments passed to or from other methods
#' @importFrom fs path_file dir_create
#' @importFrom stringr str_c str_to_lower str_to_upper str_split str_trim str_replace
#' @importFrom lubridate NA_POSIXct_
#' @importFrom readr read_lines write_csv
#' @importFrom tibble add_column
#' @importFrom dplyr mutate select
#' @importFrom rlang .data
#' @importFrom grDevices graphics.off
#' @importFrom ggplot2 ggsave
#' @importFrom ggpubr ggarrange
#' @importFrom controlR get_record get_my_theme
#' @export plot_SWAP
plot_SWAP <- function(ctrl, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- "quiet"
  quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(quiet)) quiet <- TRUE

  # --- load settings ---

  default_column <- list(
    data = tibble(datetime_start = NA_POSIXct_, datetime_end = NA_POSIXct_, depth = NA_character_, variable = NA_character_, value = NA_real_, value_min = NA_real_, value_max = NA_real_),
    predicted = tibble(datetime_end = NA_POSIXct_, variable = NA_character_, depth = NA_character_, predicted = NA_real_, observed = NA_real_),
    stats = tibble(stats = NA_real_, index = NA_character_, value = NA_real_),
    gxg = tibble(ghg = NA_real_, glg = NA_real_, gvg = NA_real_)
  )

  opt_stats <- c("avgobs", "avgmdl", "varobs", "varmdl", "rpearson", "syserr", "rnderr", "sse", "mse", "rmse", "mae", "ioa", "nse")

  # --- controlfile ---

  # load controlfile
  text <- read_lines(file = ctrl, progress = FALSE)

  # set filenames
  file_swp <- get_record(text = text, item = "FILSWP")
  file_png <- get_record(text = text, item = "FILPNG")

  # set timers
  tstart <- get_record(text = text, item = "TSTART", item_exists = FALSE)
  tend <- get_record(text = text, item = "TEND", item_exists = FALSE)

  # set language
  language <- get_record(text = text, item = "LANGUAGE", opt = c("EN", "NL"), item_exists = FALSE)
  if (is.null(language)) language <- "EN"

  # set graph settings
  graph <- str_to_upper(get_record(text = text, item = "GRAPH", split = TRUE))

  # set default cropfil
  cropfil_default <- get_record(text = text, item = "CROPFIL", split = TRUE, item_exists = FALSE)

  # set default xmin and xmax
  xmin_default <- get_record(text = text, item = "XMIN", item_exists = FALSE)
  xmax_default <- get_record(text = text, item = "XMAX", item_exists = FALSE)

  # set default ymin and ymax
  ymin_default <- get_record(text = text, item = "YMIN", item_exists = FALSE)
  ymax_default <- get_record(text = text, item = "YMAX", item_exists = FALSE)

  # observations
  dir_obs <- get_record(text = text, item = "DIROBS", item_exists = FALSE)
  stats <- digits <- NULL
  if (!is.null(dir_obs)) stats <- get_record(text = text, item = "STATS", split = TRUE, item_exists = FALSE)
  if (!is.null(stats)) digits <- get_record(text = text, item = "DIGITS", item_exists = FALSE)

  # aggregate
  aggregate_default <- get_record(text = text, item = "AGGREGATE", opt = c("year", "month", "decade"), item_exists = FALSE)

  # set size of figure
  width <- get_record(text = text, item = "WIDTH", item_exists = FALSE)
  if (is.null(width)) width <- 10
  height <- get_record(text = text, item = "HEIGHT", item_exists = FALSE)
  if (is.null(height)) height <- 5

  # set default pF
  pF_default <- get_record(text = text, item = "PF", item_exists = FALSE)

  # add GxG characteristics (optional)
  add_gxg <- FALSE; min_year <- NULL
  record <- get_record(text = text, item = "ADD_GXG", item_exists = FALSE)
  if (!is.null(record)) add_gxg <- ifelse(record == "Yes", TRUE, FALSE)
  if (add_gxg) min_year <- get_record(text = text, item = "MIN_YEAR", item_exists = FALSE)

  # create meta-information
  create_meta <- get_switch(text = text, item = "CREATE_META", item_exists = FALSE, default = FALSE)

  # save general information (if needed)
  flag_unbind <- bind_swap_settings(file_swp = file_swp)

  # initialize output
  plotlist <- list(); datalist <- list()

  # --- main part of procedure ---

  n_plt <- length(graph)

  # check selected graphs
  for (i_plt in seq_along(graph)) {
    if (!delete_tz_info(graph[i_plt]) %in% names(.swp_env$out)) stop(str_c("unknown graph selected '", graph[i_plt], "'"))
  }

  # check selected performance indexes
  if (!is.null(stats)) {
    stats <- str_to_lower(string = stats)
    if (!all(stats %in% opt_stats)) stop("unknown stats index selected")
  }

  # check selected period
  settings <- get_records_SWAP(file = file_swp, variable = c("TSTART", "TEND"), quiet = quiet)
  if (is.null(tstart)) tstart <- settings$TSTART
  if (is.null(tend)) tend <- settings$TEND

  # create list of plots
  db_data <- db_stats <- db_predicted <- db_gxg <- NULL
  for (i_plt in 1:n_plt) {

    graph_select <- delete_tz_info(graph[i_plt])

    # - check specific plot settings -

    # set cropfil of specific graph
    cropfil <- get_record(text = text, item = str_c(graph_select, "_CROPFIL"), item_exists = FALSE)
    if (is.null(cropfil)) cropfil <- cropfil_default

    # set level of aggregation of specific graph
    aggregate <- get_record(text = text, item = str_c(graph_select, "_AGGREGATE"), item_exists = FALSE)
    if (is.null(aggregate)) aggregate <- aggregate_default

    # set xmin and xmax of specific graph
    xmin <- get_record(text = text, item = str_c(graph_select, "_XMIN"), item_exists = FALSE)
    if (is.null(xmin)) xmin <- xmin_default
    xmax <- get_record(text = text, item = str_c(graph_select, "_XMAX"), item_exists = FALSE)
    if (is.null(xmax)) xmax <- xmax_default

    # set x-limit
    if (is.null(xmin) & is.null(xmax)) {
      xlim <- NULL
    } else {
      xlim <- c(ifelse(is.null(xmin), NA_real_, xmin), ifelse(is.null(xmax), NA_real_, xmax))
    }

    # set ymin and ymax of specific graph
    ymin <- get_record(text = text, item = str_c(graph_select, "_YMIN"), item_exists = FALSE)
    if (is.null(ymin)) ymin <- ymin_default
    ymax <- get_record(text = text, item = str_c(graph_select, "_YMAX"), item_exists = FALSE)
    if (is.null(ymax)) ymax <- ymax_default

    # set y-limit
    if (is.null(ymin) & is.null(ymax)) {
      ylim <- NULL
    } else {
      ylim <- c(ifelse(is.null(ymin), NA_real_, ymin), ifelse(is.null(ymax), NA_real_, ymax))
    }

    # set xmin and xmax of specific graph
    pF <- get_record(text = text, item = str_c(graph_select, "_PF"), item_exists = FALSE)
    if (is.null(pF)) pF <- pF_default

    # create plot
    output <- get_plot(file_swp = file_swp, variable = graph[i_plt], tstart = tstart, tend = tend, xlim = xlim, ylim = ylim, aggregate = aggregate, dir_obs = dir_obs, stats = stats, digits = digits, cropfil = cropfil, pF = pF, add_gxg = add_gxg, min_year = min_year, language = language, quiet = quiet)

    # collect plot
    plotlist[[length(plotlist) + 1]] <- output$plot

    # collect data
    for (name in names(default_column)) {
      if (!is.null(output[[name]])) {
        db_tmp <- output[[name]]
        db_tmp <- add_column(db_tmp, !!!default_column[[name]][!names(default_column[[name]]) %in% names(db_tmp)]) |>
          mutate(graph = graph[i_plt]) |>
          select("graph", all_of(names(default_column[[name]])))
        datalist[[name]] <- rbind(datalist[[name]], db_tmp)
      }
    }
  }

  # create output directory
  dir_create(path_dir(file_png), recurse = TRUE)

  # write meta-information figure
  if (create_meta) {
    for (name in names(default_column)) {
      if (!is.null(datalist[[name]])) {
        file_csv <- str_replace(string = file_png, pattern = ".png", replacement = str_c("_", name, ".csv"))
        write_csv(x = datalist[[name]], file = file_csv, progress = FALSE, append = FALSE, num_threads = 1)
      }
    }
  }

  # arrange plots
  n_plt <- length(plotlist)
  if (n_plt > 0) {

    # set language
    if (language == "EN") mssg <- Sys.setlocale(category = "LC_ALL", locale = "EN")
    if (language == "NL") mssg <- Sys.setlocale(category = "LC_ALL", locale = "NL")

    # save figure
    p <- ggarrange(plotlist = plotlist, ncol = 1, align = "v")
    ggsave(filename = file_png, plot = p, width = width, height = height, dpi = "retina", bg = "white")
    graphics.off()
    if (!quiet) message(str_c("create plot: ", path_file(file_png)))
  }

  # --- return of procedure ---

  # remove general information (if binded at the beginning of the procedure)
  mssg <- Sys.setlocale (category = "LC_ALL", locale = "")
  if (flag_unbind) unbind_swap_settings()

}

#' Get plot of SWAP output variable
#'
#' @param file_swp character string of main SWAP inputfile (swp-file).
#' @param variable character string of SWAP variable.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_replace str_to_upper
#' @importFrom lubridate as_datetime
#' @importFrom dplyr mutate filter select rename if_else
#' @importFrom rlang .data
#' @importFrom ggplot2 ggplot aes geom_line geom_linerange geom_rect geom_point geom_text geom_path geom_hline scale_colour_manual scale_fill_manual scale_linetype_manual scale_x_datetime coord_cartesian labs layer_scales guide_legend annotate
#' @importFrom controlR get_my_theme
#' @export get_plot
#' @description Creates timeseries-plot for a specific SWAP variable.
#' @details
#' Based on the main inputfile of SWAP (\code{file_swp}) and SWAP variable (\code{variable}) a plot is created.
#' The x-axis of the plot can be adjusted by \code{tstart}, \code{tend} or \code{xlim}. The y-axis can be adjusted by \code{ylim}.
#' The labels of the plot can be set to 'EN' (English; default) or 'NL' (Dutch) using \code{language}.
#'
#' Optionally results can be aggregated in time by \code{aggregate} (options: "YEAR", "MONTH", "DECADE" or "DAY").
#' In case SWAP output is created with multiple records during a day (NPRINTDAY > 1) and the level of aggregation is not set,
#' the unit of the plot will be converted to daily fluxes in case a flux variable is selected.
#'
#' The type of plot can be set to 'bar' or 'line' using \code{graph_type}. In case 'bar' is used, space between bars can be adjusted by setting a relative width by \code{width} (default: 0.9).
#'
#' If observations are available it is possible to add the observations as red dots in the plot.
#' A path to a folder with observations should be specified with \code{dir_obs}.
#' In this folder a csv-file with the name of the SWAP-variable should be present.
#' The file itself should have two columns: 'DATE' or 'DATETIME' and 'VALUE'. The unit of the values should be equal to the SWAP output.
#' In case 'DATE' is provided, it assumes this indicates the end of the day, DATE will be converted to 'DATETIME' by adding one day and time 00:00:00.
#' Optionally the model performance (\code{stats}) can be added in the plot (see also: \link{get_performance}).
#'
#' In case variable 'GWL' is selected, characteristics of the highest and lowest average groundwater level ('MHG' and 'MLG'; see also \link{get_gxg}) can be added to the plot by setting \code{add_gxg} to TRUE.
#'
#' @examples
#' # extract example
#' dir_out <- tempfile(pattern = "swap_")
#' file_swp <- paste0(dir_out, "/swap.swp")
#' zipfile <- system.file("extdata/input.zip", package = "SWAPtools")
#' unzip(zipfile = zipfile, exdir = dir_out)
#'
#' # plot timeseries of groundwater level
#' get_plot(file_swp = file_swp, variable = "GWL",
#'   dir_obs = paste0(dir_out, "/observed"), stats = "rmse")
#'
#' # plot timeseries of water content at depth close to -15.0 cm
#' get_plot(file_swp = file_swp, variable = "WC[-15.0]",
#'   dir_obs = paste0(dir_out, "/observed"), stats = "rpearson")
#'
#' # plot profile of pressure head at date 2018-05-31
#' get_plot(file_swp = file_swp, variable = "H[2018-05-31]", ylim = c(-150.0, 0.0),
#'   dir_obs = paste0(dir_out, "/observed"), stats = "rpearson")
#'
#' # plot profile of waterbalance aggregated to monthly output
#' get_plot(file_swp = file_swp, variable = "SUBREG_MIN[0.0:-40.0]", aggregate = "MONTH")
#'
#' # clean example
#' unlink(x = dir_out, recursive = TRUE)
get_plot <- function(file_swp, variable, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("tstart", "tend", "xlim", "ylim", "language", "aggregate", "graph_type", "width", "cropfil",  "pF", "add_gxg", "min_year", "dir_obs", "stats", "digits", "quiet")
  tstart <- tend <- xlim <- ylim <- language <- aggregate <- graph_type <- width <- cropfil <- pF <- add_gxg <- min_year <- dir_obs <- stats <- digits <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(xlim)) xlim <- c(NA_real_, NA_real_)
  if (is.null(ylim)) ylim <- c(NA_real_, NA_real_)
  if (is.null(language)) language <- "EN"
  if (is.null(add_gxg)) add_gxg <- FALSE
  if (is.null(digits)) digits <- 3
  if (is.null(quiet)) quiet <- TRUE

  # save general information (if needed)
  flag_unbind <- bind_swap_settings(file_swp = file_swp)

  # --- main part of procedure ---

  # get plot info
  variable <- str_to_upper(variable)
  plot_info <- get_plot_info(file_swp = file_swp, variable = variable, tstart = tstart, tend = tend, language = language, aggregate = aggregate, graph_type = graph_type, cropfil = cropfil, pF = pF, quiet = quiet)

  # groundwater characteristics
  gxg <- NULL
  if (variable == "GWL" && add_gxg) {
    gxg <- get_gxg(db = plot_info$db, min_year = min_year, quiet = quiet)
    if (is.na(gxg$ghg)) gxg <- NULL
  }

  # rearrange data in case of barplot
  if (plot_info$plot_type %in% c("time", "depth") && plot_info$graph_type == "bar") plot_info <- rearrange_db(plot_info)

  # extract data of figure
  db_fig <- plot_info$db

  # add observed data
  add_obs <- add_perf <- FALSE
  if (!is.null(dir_obs) && plot_info$graph_type == "line") {
    db_fig <- add_observed(db = db_fig, dir_obs = dir_obs, factor = plot_info$factor)
    if (!all(is.na(db_fig$observed))) {
      add_obs <- TRUE
      if (!is.null(stats)) {
        add_perf <- TRUE
        perf <- get_performance(actual = db_fig$observed, predicted = db_fig$value, stats = stats, digits = digits)
      }
    }
  }

  # filter crop rotation
  if (plot_info$filter_crop) {
    db_croprotation <- CROPROTATION()
    if (!is.null(db_croprotation)) {

      db_fig <- db_fig |> mutate(group = NA_real_)
      for (i_rec in seq_along(db_croprotation$CROPSTART)) {
        db_fig <- db_fig |>
          mutate(
            group = if_else(.data$datetime_start < db_croprotation$CROPEND[i_rec] & .data$datetime_end >= db_croprotation$CROPSTART[i_rec], db_croprotation$i_crp[i_rec], .data$group)
          )
      }

      if (plot_info$plot_type == "time" && plot_info$graph_type == "bar") {
        db_fig <- db_fig |>
          mutate(
            group = str_c(.data$group, .data$variable),
            value_min = if_else(is.na(.data$group), NA_real_, .data$value_min),
            value_max = if_else(is.na(.data$group), NA_real_, .data$value_max)
          )
      } else {
        db_fig <- db_fig |>
          mutate(
            group = str_c(.data$group, .data$variable),
            value = if_else(is.na(.data$group), NA_real_, .data$value)
          )
      }
    }
  }

  # create factors
  if (plot_info$plot_type %in% c("time", "depth")) {

    # multiple variable
    if (!is.null(plot_info$labels)) {
      plot_info$plot_guide <- TRUE
      db_fig$level <- factor(x = db_fig$variable, levels = plot_info$levels, labels = plot_info$labels)
      if (!plot_info$filter_crop) db_fig$group <- match(x = db_fig$level, table = plot_info$labels)
      if (plot_info$graph_type == "line") plot_info$linetype <- rep(x = 1, times = length(plot_info$levels))
    }

    # single variable
    if (is.null(plot_info$labels)) {

      if (plot_info$plot_type == "time") {
        if (is.null(plot_info$depth)) {
          plot_info$plot_guide <- FALSE
          plot_info$labels <- ""
          if (plot_info$graph_type == "line") plot_info$linetype <- 1
          db_fig$level <- factor(x = db_fig$variable, levels = plot_info$name, labels = plot_info$name)
          if (!plot_info$filter_crop) db_fig$group <- match(x = db_fig$level, table = plot_info$name)
        } else {
          plot_info$plot_guide <- TRUE
          plot_info$labels <- plot_info$depth
          plot_info$colour <- rep(x = plot_info$colour, times = length(plot_info$labels))
          if (plot_info$graph_type == "line") plot_info$linetype <- 1:length(plot_info$labels)
          db_fig$level <- factor(x = str_c(db_fig$variable, "[", formatC(x = db_fig$depth, format = "f", digits = DIGITS()),"]"), levels = str_c(plot_info$name, "[", plot_info$depth, "]"), labels = plot_info$depth)
          if (!plot_info$filter_crop) db_fig$group <- match(x = db_fig$level, table = plot_info$depth)
        }
      } else {
        plot_info$plot_guide <- TRUE
        plot_info$labels <- plot_info$datetime
        plot_info$colour <- rep(x = plot_info$colour, times = length(plot_info$datetime))
        if (plot_info$graph_type == "line") plot_info$linetype <- 1:length(plot_info$datetime)
        db_fig$depth <- db_fig$depth
        db_fig$level <- factor(x = str_c(db_fig$variable, "[", db_fig$datetime_end,"]"), levels = str_c(plot_info$name, "[", plot_info$datetime, "]"), labels = plot_info$datetime)
      }
    }
  }

  # time plot
  if (plot_info$plot_type == "time") {

    # type of plot
    if (plot_info$graph_type == "line") {

      # set guide
      if (plot_info$plot_guide) {
        guide <- guide_legend()
      } else {
        guide <- "none"
      }

      p <- ggplot(data = db_fig) +
        geom_line(aes(x = .data$datetime_end, y = .data$value, linetype = .data$level, colour = .data$level, group = .data$group), na.rm = TRUE, alpha = 0.8) +
        scale_colour_manual(name = "", values = plot_info$colour, guide = guide) +
        scale_linetype_manual(name = "", values = plot_info$linetype, guide = guide) +
        scale_x_datetime(limits = c(plot_info$tstart, plot_info$tend)) +
        coord_cartesian(ylim = ylim) +
        labs(x = "", y = parse(text = plot_info$label)) +
        get_my_theme("figure")

      if (add_obs) {
        p <- p +
          geom_point(aes(x = .data$datetime_end, y = .data$observed), colour = "red", na.rm = TRUE, alpha = 0.8) +
          geom_linerange(aes(x = .data$datetime_end, ymin = .data$observed_min, ymax = .data$observed_max), colour = "red", na.rm = TRUE, alpha = 0.8)
      }

    }
    if (plot_info$graph_type == "bar") {

      # set guide
      if (plot_info$plot_guide) {
        guide <- guide_legend(reverse = TRUE)
      } else {
        guide <- "none"
      }

      # set width of bars
      shift <- set_shift_datetime(db = db_fig, width = width, quiet = quiet)

      p <- ggplot(data = db_fig) +
        geom_rect(aes(xmin = .data$datetime_start + shift, xmax = .data$datetime_end - shift, ymin = .data$value_min, ymax = .data$value_max, fill = .data$level), na.rm = TRUE, alpha = 0.8) +
        scale_fill_manual(name = "", values = plot_info$colour, guide = guide) +
        scale_x_datetime(limits = c(plot_info$tstart, plot_info$tend)) +
        coord_cartesian(ylim = ylim) +
        labs(x = "", y = parse(text = plot_info$label)) +
        get_my_theme("figure")

      if (add_obs) {
        p <- p +
          geom_point(aes(x = .data$datetime_start + 0.5 * (.data$datetime_end - .data$datetime_start), y = .data$observed), colour = "red", na.rm = TRUE, alpha = 0.8) +
          geom_linerange(aes(x = .data$datetime_start + 0.5 * (.data$datetime_end - .data$datetime_start), ymin = .data$observed_min, ymax = .data$observed_max), colour = "red", na.rm = TRUE, alpha = 0.8)
      }

    }

    # add groundwater characteristics
    if (!is.null(gxg)) {
      p <- p +
        geom_hline(aes(yintercept = gxg$ghg), colour = "darkblue", alpha = 0.8) +
        annotate(geom = "text", x = plot_info$tend, y = gxg$ghg, label = ifelse(language == "NL", "GHG", "MHG"), colour = "darkblue", vjust = -0.4, hjust = "left", size = 3) +
        geom_hline(aes(yintercept = gxg$glg), colour = "red", alpha = 0.8) +
        annotate(geom = "text", x = plot_info$tend, y = gxg$glg, label = ifelse(language == "NL", "GLG", "MLG"), colour = "red", vjust = -0.4, hjust = "left", size = 3)
    }

  }

  # depth plot
  if (plot_info$plot_type == "depth") {

    # type of plot
    if (plot_info$graph_type == "line") {

      # create ggplot
      p <- ggplot(data = db_fig) +
        geom_path(aes(x = .data$value, y = .data$depth, linetype = .data$level, colour = .data$level), na.rm = TRUE, alpha = 0.8) +
        scale_colour_manual(name = "", values = plot_info$colour) +
        scale_linetype_manual(name = "", values = seq_along(plot_info$datetime)) +
        coord_cartesian(xlim = xlim, ylim = ylim) +
        labs(x = parse(text = plot_info$label), y = parse(text = ifelse(language == "EN", "bold(Depth)~(cm+ss)", "bold(Diepte)~(cm+mv)"))) +
        get_my_theme("figure")

    }
    if (plot_info$graph_type == "bar") {

      # set guide
      if (plot_info$plot_guide) {
        guide <- guide_legend(reverse = TRUE)
      } else {
        guide <- "none"
      }

      # add discretisation
      if (plot_info$type_tz_info == "center") {
        db_fig <- db_fig |>
          mutate(depth = as.numeric(.data$depth))
        db_fig <- left_join(x = db_fig, y = DISCR(), by = join_by("depth"))
      } else {
        db_fig <- db_fig |>
          mutate(top = as.numeric(.data$depth))
        db_fig <- left_join(x = db_fig, y = DISCR() |> select(-"depth"), by = join_by("top"))
      }

      # create ggplot
      p <- ggplot(data = db_fig) +
        geom_rect(aes(xmin = .data$value_min, xmax = .data$value_max, ymin = .data$bottom, ymax = .data$top, fill = .data$level), na.rm = TRUE, alpha = 0.8) +
        scale_fill_manual(name = "", values = plot_info$colour, guide = guide) +
        coord_cartesian(xlim = xlim, ylim = ylim) +
        labs(x = parse(text = plot_info$label), y = parse(text = ifelse(language == "EN", "bold(Depth)~(cm+ss)", "bold(Diepte)~(cm+mv)"))) +
        get_my_theme("figure")
    }

    if (add_obs) {
      p <- p +
        geom_point(aes(x = .data$observed, y = .data$depth), colour = "red", na.rm = TRUE, alpha = 0.8) +
        geom_linerange(aes(xmin = .data$observed_min, xmax = .data$observed_max, y = .data$depth), colour = "red", na.rm = TRUE, alpha = 0.8)
    }

  }

  # depth-time plot
  if (plot_info$plot_type == "depth-time") {

    # add top and bottom of each compartment
    if (plot_info$type_tz_info == "center") {
      db_fig <- db_fig |>
        mutate(depth = as.numeric(.data$depth)) |>
        left_join(y = DISCR(), by = join_by("depth"))
    } else {
      db_fig <- db_fig |>
        mutate(top = as.numeric(.data$depth)) |>
        left_join(y = DISCR() |> select(-"depth"), by = join_by("top"))
    }

    # create ggplot
    p <- ggplot(data = db_fig) +
      geom_rect(aes(xmin = .data$datetime_start, xmax = .data$datetime_end, ymin = .data$bottom, ymax = .data$top, fill = .data$value), na.rm = TRUE, alpha = 0.8) +
      scale_fill_gradientn(name = parse(text = plot_info$label), colours = plot_info$colour, na.value = "transparent") +
      scale_x_datetime(limits = c(plot_info$tstart, plot_info$tend)) +
      coord_cartesian(ylim = ylim) +
      labs(x = "", y = parse(text = ifelse(language == "EN", "bold(Depth)~(cm+ss)", "bold(Diepte)~(cm+mv)"))) +
      get_my_theme("figure")
  }


  # add performance info
  if (add_perf) {

    # extract range of plot
    xlim <- layer_scales(p)$x$get_limits()
    ylim[is.na(ylim)] <- layer_scales(p)$y$get_limits()[is.na(ylim)]

    # create text
    db_text <- perf$label |>
      mutate(
        x = as_datetime(xlim[1]),
        y = ylim[1] + .data$y_rel * (ylim[2] - ylim[1])
      ) |>
      select("x", "y", "label")

    p <- p + geom_text(data = db_text, aes(x = .data$x, y = .data$y, label = .data$label), hjust = "left", vjust = "center", colour = "grey45", parse = TRUE)

  }

  # add depth info
  if (delete_tz_info(variable) %in% c("SUBREG_MIN", "SUBREG_ALL")) {
    ylim[is.na(ylim)] <- layer_scales(p)$y$get_limits()[is.na(ylim)]
    info <- str_c(str_replace(string = str_replace(string = plot_info$depth, pattern = "-", replacement = ""), pattern = ":", replacement = " - "), " cm")
    p <- p + geom_text(x = plot_info$tstart, y = ylim[2], label = info, vjust = "outward", hjust = "inward")
  }

  # --- return of procedure ---

  # remove general information (if binded at the beginning of the procedure)
  if (flag_unbind) unbind_swap_settings()

  output <- list(plot = p, data = plot_info$db)

  # add observations
  if (add_perf) output$stats <- perf$data
  if (add_obs) output$predicted <- db_fig |> filter(!is.na(.data$observed)) |> rename(predicted = "value") |> select("datetime_end", "variable", "depth", "predicted", "observed")

  # add groundwater characteristics
  if (!is.null(gxg)) {
    output$gxg <- tibble(
      ghg = signif(x = gxg$ghg, digits = 3),
      glg = signif(x = gxg$glg, digits = 3),
      gvg = signif(x = gxg$gvg, digits = 3)
    )
  }

  return(output)

}

#' Get plot settings based on SWAP variable
#'
#' @param file_swp character string, name of swp-file.
#' @param variable character string of SWAP variable.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_to_upper str_to_lower
#' @importFrom fs path_package
#' @importFrom lubridate as_date as_datetime
#' @importFrom readr read_rds
#' @importFrom dplyr rename mutate filter select if_else all_of pull summarise group_by left_join lag
#' @importFrom pals viridis cividis warmcool parula
#' @importFrom rlang := parse_expr
#' @importFrom controlR is_date is_datetime is_numeric
#' @keywords internal
#' @export get_plot_info
get_plot_info <- function(file_swp, variable, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("tstart", "tend", "language", "aggregate", "graph_type", "cropfil", "pF", "quiet")
  tstart <- tend <- language <- aggregate <- graph_type <- cropfil <- pF <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(language)) language <- "EN"
  if (is.null(quiet)) quiet <- TRUE

  # save general information (if needed)
  flag_unbind <- bind_swap_settings(file_swp = file_swp)

  # --- main part of procedure ---

  # check user-specified input
  if (length(variable) > 1) stop("select only one variable!")

  # check type of graph
  if (!is.null(graph_type)) {
    if (!graph_type %in% c("line", "bar")) stop("unknown graph_type; options are 'bar' or 'line'")
  }

  # check language options
  if (!language %in% c("EN", "NL")) stop("unknown language selected; options are 'EN' (English) or 'NL' (Dutch)")

  # check level of aggregation
  if (!is.null(aggregate)) {
    aggregate <- str_to_upper(aggregate)
    if (!aggregate %in% c("YEAR", "MONTH", "DECADE", "DAY")) stop("unknown level of aggregation selected; options are 'YEAR', 'MONTH', 'DECADE' or 'DAY'")
  }

  # get variable info
  plot_info <- get_var_info(variable = variable)
  if (!is.null(aggregate) && plot_info$plot_type == "depth") {
    warning("option 'aggregate' ignored in case of 'profile-plot'"); aggregate <- NULL
  }

  # - check period -

  # convert tstart to class datetime
  if (!is.null(tstart)) {
    if (is_date(text = as.character(tstart))) {
      plot_info$tstart <- as_datetime(str_c(tstart, " 00:00:00"))
    } else {
      if (!is_datetime(text = tstart)) stop("unknown format for 'tstart' specified")
      plot_info$tstart <- as_datetime(tstart)
    }
    if (plot_info$tstart < TSTART()) stop("selected period before simulation period!")
  } else {
    plot_info$tstart <- TSTART()
  }

  # convert tend to class datetime
  if (!is.null(tend)) {
    if (is_date(text = tend)) {
      addtime <- ifelse("POSIXt" %in% class(tend), 0, 1)
      plot_info$tend <- as_datetime(str_c(as_date(tend) + addtime, " 00:00:00"))
    } else {
      if (!is_datetime(text = tend)) stop("unknown format for 'tend' specified")
      plot_info$tend <- as_datetime(tend)
    }
    if (plot_info$tend > TEND()) stop("selected period after simulation period!")
  } else {
    plot_info$tend <- TEND()
  }

  # check selected datetime (optional)
  if (!is.null(plot_info$datetime)) {
    if (any(plot_info$datetime < plot_info$tstart) | any(plot_info$datetime > plot_info$tend)) stop("selected 'datetime' outside simulation or plotting period!")
  }

  # - plot settings -

  out <- .swp_env$out[[plot_info$name]]

  # set factor (to apply on observations)
  factor <- ifelse(is.null(out$factor), 1.0, out$factor)
  if (is.null(aggregate) && out$type == "flux") factor <- factor * NPRINTDAY()
  plot_info$factor <- factor

  # set pF (if needed)
  if (!is.null(out$pF)) {
    if (is.null(pF)) {
      plot_info$pF <- out$pF
    } else {
      plot_info$pF <- pF
    }
  }

  # set graph_type
  if (plot_info$plot_type != "depth-time") {
    if (is.null(graph_type)) {
      plot_info$graph_type <- out$graph_type
      if (!is.null(aggregate)) {
        if (aggregate != "DAY") plot_info$graph_type <- "bar"
      }
    } else {
      plot_info$graph_type <- graph_type
    }
    if (plot_info$plot_type == "depth" && plot_info$graph_type == "bar" && length(plot_info$datetime) > 1) {
      warning("multiple 'datetime' ignored in case of 'bar-plot'; only first value is used"); plot_info$datetime <- plot_info$datetime[1]
    }
  } else {
    plot_info$graph_type <- "bar"
  }

  # set labels
  if (language == "NL") {
    label <- out$label_NL
    unit <- out$unit_NL
  }
  if (language == "EN") {
    label <- out$label_EN
    unit <- out$unit_EN
  }

  # add time component in case of flux variable
  if (out$type == "flux") {
    if (language == "NL") unit_time <- ifelse(is.null(aggregate), "d", ifelse(aggregate == "YEAR", "jaar", ifelse(aggregate == "MONTH", "maand", ifelse(aggregate == "DECADE", "decade", "d"))))
    if (language == "EN") unit_time <- ifelse(is.null(aggregate), "d", ifelse(aggregate == "YEAR", "year", ifelse(aggregate == "MONTH", "month", ifelse(aggregate == "DECADE", "decade", "d"))))
    unit <- str_c(unit, "~", unit_time, "^-1")
  }

  # combine label and unit
  plot_info$label <- str_c("bold(", label, ")~(", unit, ")")

  # - load simulation output -

  # load csv output
  db_swp <- read_csv_SWAP(file_swp = file_swp, variable = plot_info$output) |>
    rename(datetime_end = "datetime") |>
    mutate(
      datetime_start = lag(.data$datetime_end, default = TSTART()),
      group = 1
    ) |>
    filter(.data$datetime_end > plot_info$tstart & .data$datetime_end <= plot_info$tend)

  # add crop info
  plot_info$filter_crop <- FALSE
  if (out$module == "crop") {
    if (!is.null(CROPROTATION())) {

      # set filter_crop
      plot_info$filter_crop <- TRUE

      # add DMREST in case of GRASS
      if (any(c("CROPFIL", "SWWOFOST", "DMREST") %in% out$dependency) || !is.null(cropfil)) {
        db_crop <- left_join(x = CROPROTATION(), y = DMREST(), by = join_by("CROPFIL"))
        if (is.null(cropfil)) cropfil <- unique(db_crop$CROPFIL)
        db_swp <- db_swp |> mutate(group = NA_real_)
        for (i_rec in seq_along(db_crop$CROPSTART)) {
          if (any(str_to_lower(cropfil) %in% str_to_lower(db_crop$CROPFIL[i_rec]))) {
          db_swp <- db_swp |>
            mutate(group = if_else(.data$datetime_start >= db_crop$CROPSTART[i_rec] & .data$datetime_end <= db_crop$CROPEND[i_rec], db_crop$i_crp[i_rec], .data$group))
          }
        }
        db_swp <- db_swp |>
          mutate(
            CROPFIL = db_crop$CROPFIL[match(x = .data$group, table = db_crop$i_crp)],
            SWWOFOST = db_crop$SWWOFOST[match(x = .data$group, table = db_crop$i_crp)],
            DMREST = db_crop$DMREST[match(x = .data$group, table = db_crop$i_crp)]
          )
      }
    } else stop("No crop active")
  }

  # apply expression
  if (out$n_expr > 0) {

    if (is.null(plot_info$depth)) {

      # add dependency if missing
      dependency <- out$dependency
      check <- dependency[!dependency %in% names(db_swp)]
      for (i_rec in seq_along(check)) db_swp <- db_swp |> mutate(!!check[i_rec] := 0.0)

      # loop over expressions
      for (i_expr in 1:out$n_expr) {
        db_swp <- db_swp |>
          mutate(!!out$expr$variable[i_expr] := !!parse_expr(out$expr$expr[i_expr]))
      }

      # define new output in case of output contains only one variable
      plot_info$output <- out$levels[!out$levels %in% check]

    } else {

      # loop over info
      for (i_rec in seq_along(plot_info$depth)) {

        info <- plot_info$depth[i_rec]

        # loop over expressions
        for (i_expr in 1:out$n_expr) {

          # check if range can be replaced by depth

          # check WPF dependency
          W_PF <- NULL
          if ("WPF" %in% out$dependency) {
            W_PF <- MVG() |>
              filter(.data$layer == DISCR() |> filter(.data$depth == as.numeric(info)) |> pull("layer")) |>
              mutate(W_PF = get_wc_MvG(H = 10^plot_info$pF, WCR = .data$ORES, WCS = .data$OSAT, ALPHA = .data$ALFA, NPAR = .data$NPAR)) |>
              pull("W_PF")
          }

          # add dependency if missing
          dependency <- str_c(out$dependency, "[", info, "]")
          check <- dependency[!dependency %in% names(db_swp)]
          for (i_rec in seq_along(check)) db_swp <- db_swp |> mutate(!!check[i_rec] := 0.0)

          # set list for renaming variables
          dependency <- unique(c(out$dependency, out$expr$variable[i_expr]))
          lst_excl <- str_c(dependency, "[", info, "]"); names(lst_excl) <- dependency
          lst_incl <- dependency; names(lst_incl) <- str_c(dependency, "[", info, "]")

          db_swp <- db_swp |>
            rename(any_of(lst_excl)) |>
             mutate(
               WPF = W_PF,
               !!out$expr$variable[i_expr] := !!parse_expr(out$expr$expr[i_expr])
             ) |>
            rename(any_of(lst_incl))
        }
      }

      # define new output in case of output contains only one variable
      plot_info$output <- str_c(out$levels, "[", plot_info$depth, "]")[!str_c(out$levels, "[", plot_info$depth, "]") %in% check]
    }

  }

  # set colours
  if (plot_info$plot_type == "depth-time") {
    colour <- do.call(what = out$palette, args = list(100))
    if (out$palette_flip) colour <- colour[100:1]
    plot_info$colour <- colour
  } else {
    levels <- out$levels
    if (is.null(levels)) levels <- delete_tz_info(out$variable)
    index <- rep(x = FALSE, times = length(levels))
    for (i_rec in seq_along(plot_info$output)) index[str_which(levels, pattern = delete_tz_info(plot_info$output[i_rec]))] <- TRUE
    plot_info$levels <- levels[index]
    if (!is.null(out$labels_EN)) {
      if (language == "EN") plot_info$labels <- out$labels_EN[index]
      if (language == "NL") plot_info$labels <- out$labels_NL[index]
    }
    plot_info$colour <- out$colour[index]
  }

  # filter datetime in case of usage datetime
  if (plot_info$plot_type == "depth") {
    db_swp <- db_swp |> filter(.data$datetime_end %in% plot_info$datetime)
    if (nrow(db_swp) == 0) stop("unable to select datetime; check provided TZ_INFO")
  }

  # set data to plot
  output <- plot_info$output
  db <- NULL
  for (i_out in seq_along(output)) {
    info <- get_tz_info(output[i_out])
    info_value <- ifelse(is.null(info), NA_real_, ifelse(is_numeric(text = info), as.numeric(info), info))
    db_tmp <- db_swp |>
      rename(value = all_of(output[i_out])) |>
      mutate(
        variable = delete_tz_info(output[i_out]),
        depth = info_value
      ) |>
      select("datetime_start", "datetime_end", "depth", "variable", "group", "value")
    db <- rbind(db, db_tmp)
  }

  # apply factor
  db <- db |> mutate(value = if_else(!is.na(.data$group), .data$value * plot_info$factor, NA_real_)) |>
    select(-"group")

  # - aggregate -

  if (!is.null(aggregate)) {

    # set aggregate level
    if (aggregate == "YEAR") col_agg <- c("year", "depth", "variable")
    if (aggregate == "MONTH") col_agg <- c("year", "month", "depth", "variable")
    if (aggregate == "DECADE") col_agg <- c("year", "decade", "depth", "variable")
    if (aggregate == "DAY") col_agg <- c("year", "month", "day", "depth", "variable")

    # add all levels of aggregation
    db <- db |>
      mutate(
        year = year(.data$datetime_start),
        month = month(.data$datetime_start),
        day = day(.data$datetime_start),
        decade = if_else(.data$day <= 10, 1, if_else(.data$day <= 20, 2, 3)) + (.data$month - 1) * 3
      )

    # aggregate data
    if (out$type == "flux") {
      db_agg <- db |>
        group_by(db[, col_agg]) |>
        summarise(value = sum(.data$value, na.rm = TRUE), .groups = "drop")
    } else {
      db_agg <- db |>
        group_by(db[, col_agg]) |>
        summarise(value = mean(.data$value, na.rm = TRUE), .groups = "drop")
    }

    # set datetime_start and datetime_end of new period
    col_agg <- col_agg[!col_agg %in% c("depth", "variable")]
    db_per <- db |>
      group_by(db[, col_agg]) |>
      summarise(
        datetime_start = min(.data$datetime_start),
        datetime_end = max(.data$datetime_end),
        .groups = "drop"
      )

    # combine data
    db <- left_join(x = db_per, y = db_agg, by = col_agg) |>
      select(-all_of(col_agg))

  }

  plot_info$db <- db

  # --- return of procedure ---

  # remove general information (if binded at the beginning of the procedure)
  if (flag_unbind) unbind_swap_settings()

  return(plot_info)
}

#' Extract and adjust variable settings based on swp-file
#'
#' @param variable character string of SWAP variable.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_detect str_locate_all str_sub str_split str_squish
#' @importFrom lubridate as_date ymd
#' @importFrom controlR is_date is_datetime is_numeric
#' @importFrom dplyr filter select mutate pull lag slice_head slice_tail
#' @importFrom rlang .data
#' @keywords internal
#' @export get_var_info
get_var_info <- function(variable, ...) {

  # --- initial part of procedure ---

  # check SWAP environment
  if (is.null(OUTFIL())) stop("No SWAP environment available!")

  # set optional arguments
  opt_param <- c("quiet")
  quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(quiet)) quiet <- TRUE

  # --- main part of procedure ---

  # extract variable name
  var_info <- list()
  var_info$name <- delete_tz_info(variable = variable)

  # check variable
  if (!var_info$name %in% names(.swp_env$out)) stop(str_c("unknown variable selected: '", variable, "'"))

  # check if scalar or vector data
  if (.swp_env$out[[var_info$name]]$quantity == "scalar") {

    var_info$plot_type <- "time"
#    var_info$output <- var_info$name

  } else {

    # save type of tz_info (option top_bottom, center or top)
    var_info$type_tz_info <- .swp_env$out[[var_info$name]]$type_tz_info

    # extract info from variable (if exists)
    if (detect_tz_info(variable)) {

      # extract raw info
      info <- get_tz_info(variable = variable)

      # check and adjust date
      if (all(is_date(info)) || all(is_datetime(info))) {

        # convert to datetime
        if (all(is_date(info))) {
          info <- str_c(ymd(as_date(info) + 1), " 00:00:00")
        } else {
          info <- as_datetime(info)
        }

        # adjust datetime
        tstart <- as_datetime(min(as_date(info)))
        tend <- as_datetime(max(as_date(info)) + 1)
        db_time <- tibble(datetime_end = seq(from = tstart, to = tend, by = 86400 / NPRINTDAY())) |>
          mutate(
            datetime_start = lag(x = .data$datetime_end, default = tstart -  86400 / NPRINTDAY()),
            select = 0
          )
        for (i_rec in seq_along(info)) {
          db_time <- db_time |> mutate(select = if_else(info[i_rec] > .data$datetime_start & info[i_rec] <= .data$datetime_end, 1, .data$select))
        }

        # filter based on TZ_Z1_Z2
        db_cmp <- DISCR()
        if (!all(TZ_Z1_Z2() == 0.0)) db_cmp <- db_cmp |> filter(.data$bottom < TZ_Z1_Z2()[1], .data$top > TZ_Z1_Z2()[2])

        var_info$plot_type <- "depth"
        var_info$datetime <- db_time |> filter(.data$select == 1) |> pull("datetime_end")
        if (var_info$type_tz_info == "top_bottom") {
          stop(str_c("wrong usage of TZ_INFO for variable '", name, "'; only depth range is allowed!"))
        } else {
          if (var_info$type_tz_info == "center") {
            var_info$depth <- formatC(x = db_cmp |> pull("depth"), format = "f", digits = DIGITS())
          } else {
            if (var_info$type_tz_info != "top") stop(str_c("unknown type of TZ_INFO specified for variable '", name, "'"))
            var_info$depth <- formatC(x = c(db_cmp |> pull("top"), db_cmp |> slice_tail(n = 1) |> pull("bottom")), format = "f", digits = DIGITS())
          }
        }

      } else {

        # check depth
        if (all(is_numeric(info))) {

          # check depth
          info <- as.numeric(info)

          # loop over records
          db_cmp <- DISCR() |> mutate(select = 0)
          for (i_rec in seq_along(info)) {

            # adjust depth info
            if (info[i_rec] <= 0) {
              db_cmp <- db_cmp |> mutate(select = if_else(.data$bottom < info[i_rec] & .data$top >= info[i_rec], 1, .data$select))
            } else {
              db_cmp <- db_cmp |> mutate(select = if_else(.data$node >= info[i_rec] & lag(x = .data$node, default = 0) < info[i_rec], 1, .data$select))
            }
          }

          var_info$plot_type <- "time"
          if (var_info$type_tz_info == "top_bottom") {
            stop(str_c("wrong usage of TZ_INFO for variable '", name, "'; only depth range is allowed!"))
          } else {
            if (var_info$type_tz_info == "center") {
              var_info$depth <- formatC(x = db_cmp |> filter(.data$select == 1) |> pull("depth"), format = "f", digits = DIGITS())
            } else {
              if (var_info$type_tz_info != "top") stop(str_c("unknown type of TZ_INFO specified for variable '", name, "'"))
              var_info$depth <- formatC(x = db_cmp |> filter(.data$select == 1) |> pull("top"), format = "f", digits = DIGITS())
            }
          }

        } else {

          # check range in depth
          if (any(str_detect(string = info, pattern = ":"))) {
            if (length(info) >= 2) warning("multiple depth TZ-info not yet implemented, only first depth is used!")
            info <- str_split(string = info[1], pattern = ":", simplify = TRUE)[1,]
            if (all(is_numeric(info))) {

              # adjust depth range settings (in case of subregion)
              info <- as.numeric(info)
              if (all(info <= 0)) {
                db_cmp <- DISCR() |> filter(.data$bottom < info[1], .data$top > info[2])
              } else {
                db_cmp <- DISCR() |> filter(.data$node <= info[2], .data$node >= info[1])
              }

              if (var_info$type_tz_info == "top_bottom") {
                var_info$plot_type <- "time"
                var_info$depth <- str_c(formatC(x = c(db_cmp |> slice_head(n=1) |> pull("top"), db_cmp |> slice_tail(n=1) |> pull("bottom")), format = "f", digits = DIGITS()), collapse = ":")
              } else {
                var_info$plot_type <- "depth-time"
                if (var_info$type_tz_info == "center") {
                  var_info$depth <- formatC(x = db_cmp |> pull("depth"), format = "f", digits = DIGITS())
                } else {
                  if (var_info$type_tz_info != "top") stop(str_c("unknown type of TZ_INFO specified for variable '", name, "'"))
                  var_info$depth <- formatC(x = c(db_cmp |> pull("top"), db_cmp |> slice_tail(n = 1) |> pull("bottom")), format = "f", digits = DIGITS())
                }
              }
            }
          }
        }
      }

    } else {

      # filter based on TZ_Z1_Z2
      db_cmp <- DISCR()
      if (!all(TZ_Z1_Z2() == 0.0)) db_cmp <- db_cmp |> filter(.data$bottom < TZ_Z1_Z2()[1], .data$top > TZ_Z1_Z2()[2])

      # extract all depths of vector
      var_info$plot_type <- "depth-time"
      if (var_info$type_tz_info == "center") {
        var_info$depth <- formatC(x = db_cmp |> pull("depth"), format = "f", digits = DIGITS())
      } else {
        if (var_info$type_tz_info != "top") stop(str_c("unknown type of TZ_INFO specified for variable '", name, "'"))
        var_info$depth <- formatC(x = c(db_cmp |> pull("top"), db_cmp |> slice_tail(n = 1) |> pull("bottom")), format = "f", digits = DIGITS())
      }

    }
  }

  # check if var_info is present
  if (is.null(var_info$plot_type)) stop(str_c("wrong/mixed TZ-info specified, check TZ-info of variable '", variable, "'"))

  # extract depth-info
  info <- NULL; if (!is.null(var_info$depth)) info <- str_c("[", var_info$depth, "]")

  # set requested output
  if (is.null(.swp_env$out[[var_info$name]]$dependency)) {
    if (is.null(info)) {
      var_info$output <- var_info$name
    } else {
      var_info$output <- str_c(var_info$name, "[", info, "]")
    }
  } else {
    if (is.null(info)) {
      var_info$output <- .swp_env$out[[var_info$name]]$dependency
    } else {
      dependency <- NULL; for(i_rec in seq_along(info)) dependency <- c(dependency, str_c(.swp_env$out[[var_info$name]]$dependency, info[i_rec]))
      var_info$output <- dependency
    }
  }

  # check if model output is available
  if (!all(var_info$output %in% INLIST())) {

    if (is.null(info)) {
      dependency <- .swp_env$out[[var_info$name]]$dependency
    } else {
      dependency <- NULL; for(i_rec in seq_along(info)) dependency <- c(dependency, str_c(.swp_env$out[[var_info$name]]$dependency, info[i_rec]))
    }

    optional <- NULL
    if (!is.null(.swp_env$out[[var_info$name]]$optional)) {
      if (is.null(info)) {
        optional <- .swp_env$out[[var_info$name]]$optional
      } else {
        for(i_rec in seq_along(info)) optional <- c(optional, str_c(.swp_env$out[[var_info$name]]$optional, info[i_rec]))
      }
    }

    # set variables to extract (and check if available)
    check <- dependency[!dependency %in% optional]
    if (!all(check %in% INLIST())) {
      stop(str_c("missing variables in output '", str_c(check[!check %in% INLIST()], collapse = "' '"), "'; check INLIST_CSV"))
    }

    var_info$output <- dependency[dependency %in% INLIST()]
  }

  # --- return part of procedure ---

  return(var_info)

}

#' Rearrange data
#'
#' @param plot_info list with plot settings obtained by \code{get_plot_info}.
#' @importFrom stringr str_c str_replace str_to_upper
#' @importFrom lubridate year month day
#' @importFrom dplyr mutate select all_of left_join group_by ungroup summarise summarise_at
#' @importFrom rlang .data
#' @export rearrange_db
#' @keywords internal
#' @details
#' Rearrange data set by \code{position} (options are: "DODGE" (default) or "STACK").
#' The columns datetime_start and datetime_end must be present in the data. By default all columns are rearranged, use \code{column} to filter.
rearrange_db <- function(plot_info) {

  # --- main part of procedure ---

  # rearrange data
  db_out <- NULL

  first <- TRUE
  for (level in plot_info$levels) {

    db_tmp <- plot_info$db |>
      filter(.data$variable == level)

    if (first) {

      db_tmp <- db_tmp |>
        mutate(
          value_min = if_else(.data$value < 0, .data$value, 0),
          value_max = if_else(.data$value >= 0, .data$value, 0),
          lower = .data$value_min,
          upper = .data$value_max
        )

    } else {

      db_tmp <- left_join(x = db_tmp, y = db_prv, by = join_by("datetime_start", "datetime_end")) |>
        mutate(
          value_min = if_else(.data$value < 0, .data$value + .data$lower, .data$upper),
          value_max = if_else(.data$value < 0, .data$lower, .data$value + .data$upper),
          lower = if_else(.data$value < 0, .data$value + .data$lower, .data$lower),
          upper = if_else(.data$value < 0, .data$upper, .data$value + .data$upper)
        )

    }

    # combine data
    db_out <- rbind(db_out, db_tmp)

    # save lower and upper value
    first <- FALSE
    db_prv <- db_tmp |>
      select("datetime_start", "datetime_end", "lower", "upper")
  }

  plot_info$db <- db_out |>
    select("datetime_start", "datetime_end", "depth", "variable", "value_min", "value_max")

  # --- return of procedure ---

  return(plot_info)
}

#' Set width barplot
#'
#' @param db tibble with columns datetime_start and datetime_end to determine shift in seconds.
#' @importFrom dplyr pull
#' @keywords internal
#' @export set_shift_datetime
set_shift_datetime <- function(db, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("width", "quiet")
  width <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(width)) width <- 0.9
  if (is.null(quiet)) quiet <- TRUE

  # --- main part of procedure ---

  # check user input
  if (width < 0.5 && !quiet) message("too low value for width specified; width is reset to 0.5")
  if (width > 1.0 && !quiet) message("too high value for width specified; width is reset to 1.0")

  # reset width if needed
  width <- min(1.0, max(0.5, width))

  # set width of cols
  shift <- 0
  if (width < 1.0) {
    start <- db |> pull("datetime_start") |> min() |> as.numeric()
    end <- db |> pull("datetime_end") |> max() |> as.numeric()
    n_intervals <- db |> pull("datetime_start") |> unique() |> length()
    shift <- ceiling((end - start) / n_intervals * 0.5 * (1 - width))
  }

  # --- return of procedure ---

  return(shift)

}
