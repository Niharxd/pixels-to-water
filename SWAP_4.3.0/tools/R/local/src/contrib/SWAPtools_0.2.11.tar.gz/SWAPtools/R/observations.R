#' Add observations to data
#'
#' @param db tibble of model results.
#' @param dir_obs character string of directory with observations.
#' @param ... further arguments passed to or from other methods.
#' @importFrom readr read_csv
#' @importFrom fs file_exists path_ext_remove
#' @importFrom stringr str_c str_to_lower str_replace
#' @importFrom lubridate as_date
#' @importFrom dplyr mutate select rename left_join join_by rename_all group_by summarise count pull
#' @importFrom rlang .data
#' @export add_observed
#' @keywords internal
add_observed <- function(db, dir_obs, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- "factor"
  factor <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(factor)) factor <- 1.0

  # --- main part of procedure ---

  # load observations
  db_obs <- NULL
  if (!is.null(dir_obs)) {

    # check variable usage in graph
    var <- db |> pull("variable") |> unique()

    # loop over variables
    for (s_var in var) {

      file_obs <- str_c(dir_obs, "/", str_replace(string = s_var, pattern = ":", replacement = "_"), ".csv")
      if (file_exists(path = file_obs)) {

        # scan available variables
        header <- str_to_upper(as.character(read_csv(file = file_obs, comment = "*", col_names = FALSE, n_max = 1, show_col_types = FALSE, lazy = FALSE, num_threads = 1, progress = FALSE)))
        convert_date <- ifelse("DATETIME" %in% header, FALSE, TRUE)

        # set format of columns
        format <- rep(x = "-", times = length(header))
        clm <- match(x = c("DATE", "DATETIME"), table = header)
        format[clm] <- ifelse(convert_date, "D", "T")
        clm <- match(x = c("VALUE", "DEPTH"), table = header)
        format[clm] <- "d"

        # extract requested variables from file
        db_tmp <- read_csv(file = file_obs, col_types = format, comment = "*", lazy = FALSE, num_threads = 1, progress = FALSE) |>
          rename_all(.funs = str_to_lower) |>
          rename(observed = all_of("value")) |>
          mutate(observed = .data$observed * factor) |>
          select(any_of(c("date", "datetime", "depth", "observed")))

        # add observations (if possible)
        if (nrow(db_tmp) > 0) {

          # convert date to datetime
          if (convert_date) {
            db_tmp <- db_tmp |> mutate(datetime_end = as_datetime(as_date(.data$date + 1))) |> select(-"date")
          } else {
            db_tmp <- db_tmp |> rename(datetime_end = "datetime")
          }

          # adjust depth info
          if (.swp_env$out[[s_var]]$quantity == "vector") {

            # in case of vector, depth information should be present
            if (!"depth" %in% names(db_tmp)) stop(str_c("column 'DEPTH' should be present in file '", path_file(file_obs),"' (observed data)"))

            db_tmp <- db_tmp |> rename(depth_obs = all_of("depth"))
            db_lnk <- tibble(depth_obs = db_tmp |> pull("depth_obs") |> unique(), depth = NA_character_, variable = s_var) |>
              mutate(
                var_obs = str_c(s_var, "[", .data$depth_obs, "]"),
                var = adjust_tz_info(.data$var_obs)
              )
            for (i_rec in seq_along(db_lnk$var)) db_lnk$depth[i_rec] <- get_tz_info(db_lnk$var[i_rec])
            db_lnk <- db_lnk |> select("depth_obs", "depth", "variable")

            db_tmp <- db_tmp |> left_join(y = db_lnk, by = join_by("depth_obs")) |> select(-"depth_obs")
          } else {
            db_tmp <- db_tmp |> mutate(depth = NA_character_, variable = s_var)
          }

          # check if multiple observations at one day
          n_obs <- max(db_tmp |> group_by(.data$datetime_end, .data$depth, .data$variable) |> count() |> pull("n"))
          if (n_obs == 1) {
            db_tmp <- db_tmp |>
              mutate(
                observed_min = NA_real_,
                observed_max = NA_real_
              ) |>
              select("datetime_end", "depth", "variable", "observed", "observed_min", "observed_max")
          } else {
            db_tmp <- db_tmp |>
              group_by(.data$datetime_end, .data$depth, .data$variable) |>
              summarise(
                observed_min = min(.data$observed),
                observed_max = max(.data$observed),
                observed = mean(.data$observed),
                .groups = "drop"
              ) |>
              select("datetime_end", "depth", "variable", "observed", "observed_min", "observed_max")
          }

          db_obs <- rbind(db_obs, db_tmp)
        }
      }
    }
  }

  # join observed data
  if (is.null(db_obs)) {
    db <- db |> mutate(observed = NA_real_, observed_min = NA_real_, observed_max = NA_real_)
  } else {
    db <- left_join(x = db, y = db_obs |> mutate(depth = as.numeric(.data$depth)), by = join_by("datetime_end", "depth", "variable"))
  }

  # --- return of procedure ---

  return(db)

}

#' Calculate model performance
#'
#' @param actual numeric vector, observed values
#' @param predicted numeric vector, modelled values
#' @param stats character vector, statistics to be calculated
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_to_upper
#' @importFrom Metrics mae sse mse rmse
#' @importFrom tibble tibble
#' @importFrom dplyr select
#' @importFrom stats cor var
#' @export get_performance
#' @keywords internal
#' @details
#' Calculate model performance, options are: Pearson correlation ('rpearson'), systematic and random ('syserr' and 'rnderr'),
#' (root) mean squared error ('rmse' and 'mse') or sum of squared errors 'sse', mean absolute error 'mae', index of agreement 'ioa' (Willmot, 1981) and Nash-Sutcliff efficiency (1970) 'nse'. Missing values are removed before the computation proceeds.
#' The average observed (\code{actual}) or simulated (\code{perdicted}) can be obtained by 'avgobs' and 'avgmdl', and similar for variation obtained by 'varobs' and 'varmdl'.
#' @references
#' Willmott, C. J. 1981. On the validation of models. Physical Geography, 2, 184–194
#'
#' Nash, J. E. and J. V. Sutcliffe (1970), River flow forecasting through conceptual models part I -A discussion of principles, Journal of Hydrology, 10 (3), 282-290
get_performance <- function(actual, predicted, stats, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("index", "digits")
  index <- n_digits <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(digits)) digits <- 3

  # set possible model performance indexes
  opt_stats <- c(
    "avgobs" = "AVG[obs]", "avgmdl" = "AVG[mdl]",
    "varobs" = "VAR[obs]", "varmdl" = "VAR[mdl]",
    "rpearson" = "r[pearson]",
    "syserr" = "SYS[err]", "rnderr" = "RND[err]",
    "sse" = "SSE", "mse" = "MSE", "rmse" = "RMSE", "mae" = "MAE",
    "ioa" = "IoA", "nse" = "NSE"
  )

  # --- main part of procedure ---

  modelperformance <- NULL

  # set index
  if (is.null(index)) {
    idx <- rep(x = 1, times = length(actual))
  } else {
    idx <- index
  }

  # check user-specified input
  s_stats <- stats[!stats %in% names(opt_stats)]
  if (length(s_stats) > 0) stop(str_c("unknown model performance index selected '", s_stats, "'", collapse = "\n"))

  # check length values
  if (length(predicted) != length(actual)) stop("number of observations is not equal to number of modelled values")
  if (length(predicted) != length(idx)) stop("length of index is not equal to number of modelled values")

  # select only modelled values with observations
  rec <- !is.na(predicted) & !is.na(actual) & !is.na(idx)
  predicted <- predicted[rec]
  actual <- actual[rec]
  idx <- idx[rec]

  # index
  idx_uni <- unique(idx)
  n_idx <- length(idx_uni)

  # set performance for each index
  db_stats <- db_label <- NULL
  for (i_idx in seq_along(idx_uni)) {

    # filter index
    rec <- idx_uni[i_idx] == idx

    # initialise label
    text_prf <- NULL
    text_lbl <- ifelse(!is.null(index), str_c("~~'", idx_uni[i_idx], "'~~"), "~~")

    # loop over statistics
    for (s_stats in stats) {

      output <- switch(
        s_stats,
        "avgobs" = mean(actual[rec]),
        "varobs" = var(actual[rec]),
        "avgmdl" = mean(predicted[rec]),
        "varmdl" = var(predicted[rec]),
        "mae" = mae(actual = actual[rec], predicted = predicted[rec]),
        "sse" = sse(actual = actual[rec], predicted = predicted[rec]),
        "mse" = mse(actual = actual[rec], predicted = predicted[rec]),
        "rmse" = rmse(actual = actual[rec], predicted = predicted[rec]),
        "rpearson" = ifelse(var(actual[rec]) == 0 || var(predicted[rec]) == 0, NA_real_, cor(x = actual[rec], y = predicted[rec], method = "pearson")),
        "syserr" = mean(actual[rec]) - mean(predicted[rec]),
        "rnderr" = mean(((actual[rec] - predicted[rec]) - (mean(actual[rec]) - mean(predicted[rec])))^2),
        "ioa" = 1 - sum((predicted[rec]-actual[rec])^2) / sum((abs(predicted[rec] - mean(actual[rec])) + abs(actual[rec] - mean(actual[rec])))^2),
        "nse" = 1 - sum((predicted[rec] - actual[rec])^2) / sum((actual[rec] - mean(actual[rec]))^2)
      )

      # create tibble
      value <- signif(x = output, digits = digits)

      db_tmp <- tibble(
        stats = s_stats,
        index = ifelse(is.null(index), NA_character_, idx_uni[i_idx]),
        value = value)

      # save data
      db_stats <- rbind(db_stats, db_tmp)

      # add performance to text
      text <- as.character(opt_stats[s_stats])
      text <- str_c(text,"*~'", ifelse(is.na(value), "NA", value), "'")
      if (is.null(text_prf)) {text_prf <- text} else {text_prf <- str_c(text_prf, "*';'~~", text)}

    }

    # save lavel
    db_tmp <- tibble(x_rel = 0.0, y_rel = 0.05 * (n_idx:1)[i_idx], label = str_c("italic(", text_lbl, text_prf, ")"))
    db_label <- rbind(db_label, db_tmp)
  }

  if (!is.null(db_stats)) modelperformance <- list(data = db_stats, label = db_label)

  # --- return of procedure ---

  return(modelperformance)
}
