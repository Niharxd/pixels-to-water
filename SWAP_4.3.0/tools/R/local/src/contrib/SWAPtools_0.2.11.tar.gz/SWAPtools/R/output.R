#' Scan SWAP-csv-output
#'
#' @param file_csv character string, name of SWAP csv-file (obtained by SWAP options SWCSV = 1).
#' @param filter logical, filter variables only.
#' @importFrom readr read_csv
#' @importFrom stringr str_c str_to_upper
#' @export scan_csv_SWAP
#' @keywords internal
scan_csv_SWAP <- function(file_csv, filter = TRUE) {

  # --- main part of procedure ---

  # read header
  variables <- str_to_upper(as.character(read_csv(file = file_csv, comment = "*", col_names = FALSE, n_max = 1, show_col_types = FALSE, lazy = FALSE, progress = FALSE, num_threads = 1)))
  if (length(variables) == 1) stop("SWAP csv-output should be ',' separated, re-run the model!")
  if (filter) variables <- variables[!variables %in% c("DATETIME", "DATE")]

  # --- return of procedure ---

  return(variables)
}

#' Read SWAP-csv-output
#'
#' @param file_swp character string of main SWAP inputfile (swp-file).
#' @param variable character string, name of SWAP variable to extract.
#' @param ... further arguments passed to or from other methods
#' @importFrom readr read_csv read_rds
#' @importFrom fs path_file path_dir
#' @importFrom stringr str_c str_to_lower str_to_upper
#' @importFrom dplyr rename select all_of any_of
#' @importFrom rlang .data
#' @export read_csv_SWAP
#' @details
#' As default csv-output with information as function of time is read which is obtained by SWAP using SWCSV = 1.
#' @examples
#' # extract example
#' dir_out <- paste0(tempfile(pattern = "swap_"))
#' file_swp <- paste0(dir_out, "/swap.swp")
#' file_crp <- paste0(dir_out, "/snijmais.crp")
#' file_csv <- paste0(dir_out, "/result_output.csv")
#' zipfile <- system.file("extdata/input.zip", package = "SWAPtools")
#' unzip(zipfile = zipfile, exdir = dir_out)
#'
#' # plot timeseries of groundwater level
#' read_csv_SWAP(file_swp = file_swp, variable = c("GWL", "WC[-15.50]"))
#'
#' # clean example
#' unlink(x = dir_out, recursive = TRUE)
read_csv_SWAP <- function(file_swp, variable, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- "quiet"
  quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(quiet)) quiet <- TRUE

  # save general information (if needed)
  flag_unbind <- bind_swap_settings(file_swp = file_swp)

  # --- main part of procedure ---

  # set file_csv
  file_csv <- str_c(path_dir(file_swp), "/", str_to_lower(OUTFIL()), "_output.csv")
  if (!quiet) message(str_c("reading file: ", path_file(file_csv)))

  # scan available variables
  header <- scan_csv_SWAP(file_csv = file_csv, filter = FALSE)
  if (any(!variable %in% header)) stop(str_c("unable to extract variable '", str_c(variable[!variable %in% header], collapse = "' '"), "' from file '", path_file(file_csv), "'"))

  # set format of columns
  format <- rep(x = "-", times = length(header))
  clm <- match(x = c("DATESTART", "DATE", "DATETIME"), table = header)
  format[clm] <- "T"
  clm <- match(x = str_to_upper(variable), table = header)
  format[clm[!is.na(clm)]] <- "d"
  format <- str_c(format, collapse = "")

  # extract requested variables from file
  db_swp <- read_csv(file = file_csv, comment = "*", n_max = -1, col_types = format, lazy = FALSE, num_threads = 1, progress = FALSE) |>
    rename(any_of(c(datetime = "DATE", datetime = "DATETIME")))

  # convert date to datetime (in case NPRINTDAY = 1)
  if (NPRINTDAY() == 1) {
    db_swp <- db_swp |> mutate(datetime = .data$datetime + 86400)
  }

  # --- return of procedure ---

  # remove general information (if binded at the beginning of the procedure)
  if (flag_unbind) unbind_swap_settings()

  return(db_swp)
}

#' Get SWAP version
#'
#' @param file_swp character string, name of swp-file.
#' @importFrom stringr str_replace
#' @importFrom fs path_dir
#' @importFrom readr read_lines
#' @details Extracts SWAP version number from csv-output
#' @export get_version_SWAP
get_version_SWAP <- function(file_swp) {

  # --- main part of procedure ---

  # load dynamic variables
  OUTFIL <- get_record_SWAP(file = file_swp, variable = "OUTFIL")
  file <- str_c(path_dir(file_swp), "/", OUTFIL, "_output.csv")
  string <- read_lines(file = file, skip = 3, n_max = 1, lazy = FALSE, num_threads = 1, progress = FALSE)
  version <- str_replace(string = str_to_lower(string), pattern = "\\* model version: swap ", replacement = "")

  # --- return of procedure ---

  return(version)
}

#' Rename columns of SWAP output (for backward compatibility)
#'
#' @param db tibble with SWAP output
#' @importFrom stringr str_c str_split str_detect
#' @importFrom readr read_rds
#' @importFrom tibble tibble
#' @importFrom dplyr mutate if_else pull right_join join_by rename
#' @importFrom rlang .data
#' @keywords internal
#' @export replace_header
replace_header <- function(db) {

  # --- main part of procedure ---

  db_rename <- .swp_env$replace |>
    mutate(
      name_new = str_split(string = .data$name, pattern = "\\[", simplify = TRUE)[,1],
      name_old = str_split(string = .data$name_old, pattern = "\\[", simplify = TRUE)[,1],
      quantity = if_else(str_detect(string = .data$name, pattern = "\\["), "vector", "scalar")
    ) |>
    select("name_new", "name_old", "quantity")

  db_header <- tibble(header_old = names(db)) |>
    mutate(
      name_old = str_split(string = .data$header_old, pattern = "\\[", simplify = TRUE)[,1],
      tz = str_split(string = .data$header_old, pattern = "\\[", simplify = TRUE)[,2],
      tz = if_else(.data$tz == "", "", str_c("[", .data$tz)),
      quantity = if_else(.data$tz == "", "scalar", "vector")
    ) |>
    right_join(x = db_rename, by = join_by("name_old", "quantity")) |>
    mutate(header_new = if_else(is.na(.data$name_new), .data$header_old, str_c(.data$name_new, .data$tz)))

  # set header
  header <- db_header |> pull("header_old")
  names(header) <- db_header |> pull("header_new")

  # rename columns
  db <- db |> rename(all_of(header))

  # --- return of procedure ---

  return(db)
}

