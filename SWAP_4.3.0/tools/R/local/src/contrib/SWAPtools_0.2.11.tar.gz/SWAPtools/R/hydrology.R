#' Determine mean highest and mean lowest groundwater level
#'
#' @param db dataframe with columns 'date' or 'datetime' and 'value'.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom lubridate year month day as_date interval time_length
#' @importFrom tibble tibble
#' @importFrom dplyr .data rename mutate select filter left_join join_by group_by summarise arrange pull
#' @importFrom stats aggregate
#' @return return list of mean highest, mean lowest and averaged spring groundwater level [cm+mv]
#' @details
#' To derive the mean highest (GHG) and mean lowest (GLG) groundwater level, all values on the 14th and 28th day of the month are selected leaded to 24 values for each hydrologic year (April - March).
#' From this the three highest (HG3) and three lowest (LG3) values are selected and averaged over a long term period resulting in the GHG and GLG. #' To derive the average groundwater level in spring,
#' the values on the 14th and 28th of March and 14th of April are averaged over a long term period. Normally the long term period should be 8 years at least.
#'
#' In case of incomplete timeseries of groundwater level observations on the 14th and 28th day of the month a certain shift in days is allowed. As a default a maximum of 5 days is used, but this can be adjusted by \code{max_shift}.
#' Although the shift in days, it is still possible the timeseries is missing observations. A certain amount of missing observations is allowed (default 0.9; this can be adjusted by \code{min_frac}.
#' Furthermore the length of the long term period can be adjusted by \code{min_year} (default: 8 years).
#'
#' The period over which the groundwater characteristics should be determined can be adjusted by specifying \code{tstart} and/or \code{tend}.
#' @export get_gxg
get_gxg <- function(db, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("max_shift", "min_frac", "min_year", "tstart", "tend", "quiet")
  max_shift <- min_frac <- min_year <- tstart <- tend <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (!is.null(tstart)) tstart <- as_date(tstart)
  if (!is.null(tend)) tend <- as_date(tend)
  if (is.null(max_shift)) max_shift <- 5
  if (is.null(min_frac)) min_frac <- 0.9
  if (is.null(min_year)) min_year <- 8
  if (is.null(quiet)) quiet <- FALSE

  # --- main part of procedure ---

  # check if columns 'datetime' and 'value' are available
  header <- names(db)
  if (!any(c("value", "GWL") %in% header)) stop("data should contain column 'value' or 'GWL'")
  if (!any(c("date", "datetime", "datetime_end") %in% header)) stop("data should contain column 'date', 'datetime' or 'datetime_end'")

  # convert GWL
  if ("GWL" %in% header && !"value" %in% header) {
    db <- db |>
      rename(value = "GWL")
  }

  # convert datetime to date
  if ("date" %in% header) {
    db <- db |> mutate(date = as_date(.data$date))
  } else {
    if ("datetime_end" %in% header) db <- db |> rename(datetime = "datetime_end")
    db <- db |> mutate(date = as_date(as_datetime(.data$datetime) - 86400)) |> select(-"datetime")
  }

  # set period
  if (is.null(tstart)) tstart <- min(db$date)
  if (is.null(tend)) tend <- max(db$date)

  if (time_length(interval(tstart, tend), "day") < 365) {
    if (!quiet) message("unable to calculate gxg, interval is too small")
    gxg <- list("ghg" = NA_real_, "glg" = NA_real_, "gvg" = NA_real_)
    return(gxg)
  }

  # sequence of 14th and 28th
  db_sel <- tibble(date = seq(from = tstart, to = tend, by = 1), observed = NA) |>
    filter(day(.data$date) %in% c(14, 28)) |>
    mutate(gvg = ifelse(month(.data$date) == 3 | (month(.data$date) == 4 & day(.data$date) == 14), 1, 0))

  # merge datasets
  db_sel <- left_join(x = db_sel, y = db[, c("date", "value")], by = join_by("date")) |>
    mutate(observed = if_else(is.na(.data$value), NA_real_, .data$value)) |>
    select("date", "observed", "gvg")

  # shift observation in case of missing values
  done <- all(!is.na(db_sel$observed))
  if (!done) {

    shift <- 1
    db <- db |> mutate(date_org = .data$date)

    # shift days till all records are filled
    while (!done) {

      # shift up and down
      db_min <- db |>
        mutate(date = .data$date_org - shift) |>
        filter(day(.data$date) %in% c(14, 28)) |>
        select("date", "value")
      db_max <- db |>
        mutate(date = .data$date_org + shift) |>
        filter(day(.data$date) %in% c(14, 28)) |>
        select("date", "value")
      db_add <- rbind(db_min, db_max) |>
        group_by(.data$date) |>
        summarise(
          value = mean(.data$value, na.rm = TRUE),
          .groups = "drop"
        )

      # merge shifted observations
      if (nrow(db_add) != 0) {
        db_sel <- left_join(x = db_sel, y = db_add, by = join_by("date")) |>
          mutate(observed = if_else(is.na(.data$observed), if_else(is.na(.data$value), NA_real_, .data$value), .data$observed)) |>
          select("date", "observed", "gvg")
      }

      # check if done
      shift <- shift + 1
      if (shift > max_shift) done <- TRUE
      if (all(!is.na(db_sel$observed))) done <- TRUE
    }
  }

  # determine GxG
  db_sel <- db_sel |>
    mutate(
      year = year(.data$date),
      hydryear = if_else(month(.data$date) <= 3, str_c(.data$year - 1, "-", .data$year), str_c(.data$year, "-", .data$year + 1))
    )
  db_gxg <- tibble(period = unique(db_sel$hydryear), hg3 = NA_real_, lg3 = NA_real_, n_obs = NA_real_)
  for (i_rec in seq_along(db_gxg$period)) {
    gxg <- db_sel |>
      filter(.data$hydryear == db_gxg$period[i_rec] & !is.na(.data$observed)) |>
      arrange(.data$observed) |>
      pull("observed")

    n_obs <- length(gxg)
    if (n_obs >= min_frac * 24) {
      db_gxg$hg3[i_rec] <- mean(gxg[(n_obs - 2):n_obs])
      db_gxg$lg3[i_rec] <- mean(gxg[1:3])
    }
    db_gxg$n_obs[i_rec] <- n_obs
  }

  db_gvg <- tibble(year = unique(db_sel$year), gvg = NA_real_, n_obs = NA_real_)
  for (i_rec in seq_along(db_gvg$year)) {
    gvg <- db_sel |>
      filter(.data$year == db_gvg$year[i_rec] & !is.na(.data$observed) & .data$gvg == 1) |>
      pull("observed")
    n_obs <- length(gvg)
    if (n_obs >= min_frac * 3) {
      db_gvg$gvg[i_rec] <- mean(gvg, na.rm = TRUE)
    }
    db_gvg$n_obs[i_rec] <- n_obs
  }

  # set GHG and GLG
  n_year <- db_gxg |> filter(!is.na(.data$hg3)) |> nrow()
  if (n_year >= min_year) {
    ghg <- mean(db_gxg$hg3, na.rm = TRUE)
    glg <- mean(db_gxg$lg3, na.rm = TRUE)
    if (!quiet) {
      message(str_c("\nGHG:", formatC(x = round(-ghg), format = "d", width = 4), " [cm-mv]"))
      message(str_c("GLG:", formatC(x = round(-glg), format = "d", width = 4), " [cm-mv]"))
    }
  } else {
    ghg <- NA_real_
    glg <- NA_real_
    if (!quiet) {
      frac <- nrow(db_sel[!is.na(db_sel$observed),]) / nrow(db_sel)
      message(str_c("unable to determine GxG (", formatC(x = frac * 100, format = "f", digits = 1), "% observed)"))
    }
  }

  n_year <- db_gvg |> filter(!is.na(.data$gvg)) |> nrow()
  if (n_year >= min_year) {
    gvg <- mean(db_gvg$gvg, na.rm = TRUE)
    if (!quiet) message(str_c("GVG:", formatC(x = round(-gvg), format = "d", width = 4), " [cm-mv]"))
  } else {
    gvg <- NA_real_
    if (!quiet) {
      frac <- nrow(db_sel[db_sel$gvg == 1 & !is.na(db_sel$observed),]) / nrow(db_sel[db_sel$gvg == 1, ])
      message(str_c("unable to determine GVG (", formatC(x = frac * 100, format = "f", digits = 1), "% observed)"))
    }
  }

  # --- return of procedure ---

  gxg <- list("ghg" = ghg, "glg" = glg, "gvg" = gvg, "gxg" = db_gxg, "gvg" = db_gvg)
  return(gxg)
}

#' Get GT class
#'
#' @param ghg value. Average highest groundwaterlevel [cm+mv].
#' @param glg value. Average lowest groundwaterlevel [cm+mv].
#' @param opt character string. options: 1966, 1977 or 1995.
#' @importFrom stringr str_c
#' @return return GT based on \code{GHG} and \code{GLG}
#' @export get_gt
get_gt <- function(ghg, glg, opt = "1966") {

  # --- initial part of procedure ---

  # check selected option of GT
  if (!opt %in% c("1966", "1977", "1995")) stop(str_c("selected opt '", opt, "' not available"))

  # initialize Gt
  gt <- rep(x = NA_real_, times = length(ghg))

  # --- main part of procedure ---

  # check statistics
  if (any(ghg - glg < 0)) warning("Check groundwater level statistics; GHG decends below GLG")

  if (opt == "1966") {
    gt[glg > -50] <- "I"
    gt[glg <= -50 & glg > -80] <- "II"
    gt[glg <= -80 & glg > -120 & ghg > -40] <- "III"
    gt[glg <= -80 & glg > -120 & ghg <= -40] <- "IV"
    gt[glg <= -120 & ghg > -40] <- "V"
    gt[glg <= -120 & ghg <= -40 & ghg > -80] <- "VI"
    gt[glg <= -120 & ghg <= -80] <- "VII"
  }

  if (opt == "1977") {
    gt[glg > -50] <- "I"
    gt[glg <= -50  & glg > -80 & ghg > -25] <- "II"
    gt[glg <= -50  & glg > -80 & ghg <= -25] <- "II*"
    gt[glg <= -80  & glg > -120 & ghg > -25] <- "III"
    gt[glg <= -80  & glg > -120 & ghg <= -25 & ghg > -40] <- "III*"
    gt[glg <= -80  & glg > -120 & ghg <= -40] <- "IV"
    gt[glg <= -120 & ghg > -25] <- "V"
    gt[glg <= -120 & ghg <= -25 & ghg > -40] <- "V*"
    gt[glg <= -120 & ghg <= -40 & ghg > -80] <- "VI"
    gt[glg <= -120 & ghg <= -80 & ghg > -140] <- "VII"
    gt[glg <= -120 & ghg <= -140] <- "VII*"
  }

  if (opt == "1995") {
    gt[glg > -50   & ghg > -25] <- "Ia"
    gt[glg > -50   & ghg <= -25] <- "Ic"
    gt[glg <= -50  & glg > -80 & ghg > -25] <- "IIa"
    gt[glg <= -50  & glg > -80 & ghg <= -25 & ghg > -40] <- "IIb"
    gt[glg <= -50  & glg > -80 & ghg <= -40] <- "IIc"
    gt[glg <= -80  & glg > -120 & ghg > -25] <- "IIIa"
    gt[glg <= -80  & glg > -120 & ghg <= -25 & ghg > -40] <- "IIIb"
    gt[glg <= -80  & glg > -120 & ghg <= -40 & ghg > -80] <- "IVu"
    gt[glg <= -80  & glg > -120 & ghg <= -80] <- "IVc"
    gt[glg <= -120 & ghg > -25] <- "Va"
    gt[glg <= -120 & ghg <= -25 & ghg > -40] <- "Vb"
    gt[glg <= -120 & ghg <= -40 & ghg > -80] <- "VI"
    gt[glg <= -120 & ghg <= -80 & ghg > -140] <- "VII"
    gt[glg <= -120 & ghg <= -140] <- "VIII"
  }

  if (opt == "2018") {
    gt[glg > -50   & ghg > -25] <- "Ia"
    gt[glg > -50   & ghg <= -25] <- "Ic"
    gt[glg <= -50  & glg > -80 & ghg > -25] <- "IIa"
    gt[glg <= -50  & glg > -80 & ghg <= -25 & ghg > -40] <- "IIb"
    gt[glg <= -50  & glg > -80 & ghg <= -40] <- "IIc"
    gt[glg <= -80  & glg > -120 & ghg > -25] <- "IIIa"
    gt[glg <= -80  & glg > -120 & ghg <= -25 & ghg > -40] <- "IIIb"
    gt[glg <= -80  & glg > -120 & ghg <= -40 & ghg > -80] <- "IVu"
    gt[glg <= -80  & glg > -120 & ghg <= -80] <- "IVc"
    gt[glg <= -120 & ghg > -25] <- "Va"
    gt[glg <= -120 & glg > -180 & ghg > -25] <- "Vao"
    gt[glg <= -180 & ghg > -25] <- "Vad"
    gt[glg <= -120 & ghg <= -25 & ghg > -40] <- "Vb"
    gt[glg <= -120 & glg > -180 & ghg <= -25 & ghg > -40] <- "Vbo"
    gt[glg <= -180 & ghg <= -25 & ghg > -40] <- "Vbd"
    gt[glg <= -120 & ghg <= -40 & ghg > -80] <- "VI"
    gt[glg <= -120 & glg > -180 & ghg <= -40 & ghg > -80] <- "VIo"
    gt[glg <= -180 & ghg <= -40 & ghg > -80] <- "VId"
    gt[glg <= -120 & ghg <= -80 & ghg > -140] <- "VII"
    gt[glg <= -120 & glg > -180 & ghg <= -80 & ghg > -140] <- "VIIo"
    gt[glg <= -180 & ghg <= -80 & ghg > -140] <- "VIId"
    gt[glg <= -120 & ghg <= -140] <- "VIII"
    gt[glg <= -120 & glg > -180 & ghg <= -140] <- "VIIIo"
    gt[glg <= -180 & ghg <= -140] <- "VIIId"
  }

  # --- return of procedure ---

  return(gt)
}
