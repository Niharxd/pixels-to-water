#' Create meteo files for SWAP
#'
#' @param ctrl character string of figure template.
#' @param source character string, source of meteo data (options: 'KNMI' or 'OPEN-METEO')
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_to_upper
#' @importFrom readr read_lines
#' @importFrom controlR get_record get_dir get_switch
#' @export create_meteo_SWAP
#' @details Download of meteorological data from \href{https://www.knmi.nl/home}{KNMI} or \href{https://open-meteo.com}{OPEN-METEO}.
create_meteo_SWAP <- function(ctrl, source, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- "quiet"
  quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(quiet)) quiet <- TRUE

  # --- controlfile ---

  # check source
  if (!str_to_upper(source) %in% c("KNMI", "OPEN-METEO")) stop("source should be 'KNMI' or 'OPEN-METEO'")

  # load controlfile
  text <- read_lines(file = ctrl, progress = FALSE)

  # set directories
  dir_out <- get_dir(text = text, item = "DIROUT", create = FALSE)

  # set period
  tstart <- get_record(text = text, item = "TSTART")
  tend <- get_record(text = text, item = "TEND")

  # in case of source KNMI
  if (str_to_upper(source) == "KNMI") {

    # set station KNMI
    station <- get_record(text = text, item = "STATION", split = TRUE)
    replace <- get_record(text = text, item = "REPLACE", split = TRUE, item_exists = FALSE)

    # set time interval
    topt <- get_record(text = text, item = "TOPT", opt = c("day", "hour"), item_exists = FALSE, default = "day")

    # daytime averaged windspeed
    daytime_windspeed <- get_switch(text = text, item = "DAYTIME_WINDSPEED", item_exists = FALSE, default = TRUE)

    # windfactor (optional)
    f_wind <- NULL
    if (!daytime_windspeed) {
      f_wind <- get_record(text = text, item = "FWIND", item_exists = FALSE)
    }

    # actual vapour pressure
    average_humidity <- get_switch(text = text, item = "AVERAGE_HUMIDITY", item_exists = FALSE, default = FALSE)

    # windfactor (optional)
    f_hum <- NULL
    if (average_humidity) {
      f_hum <- get_record(text = text, item = "FHUM", item_exists = FALSE)
    }
  }

  # in case of source OPEN-METEO
  if (str_to_upper(source) == "OPEN-METEO") {

    # set location
    latitude <- get_record(text = text, item = "LATITUDE")
    longitude <- get_record(text = text, item = "LONGITUDE")

  }

  # split met-files
  split <- get_switch(text = text, item = "SPLIT", item_exists = FALSE, default = FALSE)

  # analyse meeorological conditions
  analyse <- get_switch(text = text, item = "ANALYSE", item_exists = FALSE, default = FALSE)

  width <- height <- NULL
  if (analyse) {
    width <- get_record(text = text, item = "WIDTH", item_exists = FALSE)
    height <- get_record(text = text, item = "HEIGHT", item_exists = FALSE)
  }

  # --- main part of procedure ---

  # in case of source KNMI
  if (str_to_upper(source) == "KNMI") {

    create_meteo_KNMI(
      dir_out = dir_out, station = station, tstart = tstart, tend = tend, topt = topt, split = split, replace = replace,
      daytime_windspeed = daytime_windspeed, f_wind = f_wind, average_humidity = average_humidity, f_hum = f_hum,
      analyse = analyse, width = width, height = height)
  }

  # in case of source OPEN-METEO
  if (str_to_upper(source) == "OPEN-METEO") {

    create_meteo_OPENMETEO(
      dir_out = dir_out, latitude = latitude, longitude = longitude, tstart = tstart, tend = tend, split = split,
      analyse = analyse, width = width, height = height)
  }

}

#' Create precipitation files for SWAP
#'
#' @param ctrl character string of figure template.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_to_upper
#' @importFrom readr read_lines
#' @importFrom controlR get_record get_dir get_switch
#' @export create_precipitation_SWAP
#' @details Download of precipitation data from \href{https://www.knmi.nl/home}{KNMI}.
create_precipitation_SWAP <- function(ctrl, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- "quiet"
  quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(quiet)) quiet <- TRUE

  # --- controlfile ---

  # load controlfile
  text <- read_lines(file = ctrl, progress = FALSE)

  # set directories
  dir_out <- get_dir(text = text, item = "DIROUT", create = FALSE)

  # set period
  tstart <- get_record(text = text, item = "TSTART")
  tend <- get_record(text = text, item = "TEND")

  # set station KNMI
  station <- get_record(text = text, item = "STATION", split = TRUE)
  replace <- get_record(text = text, item = "REPLACE", split = TRUE, item_exists = FALSE)

  # set time interval
  topt <- get_record(text = text, item = "TOPT", opt = c("day", "hour"), item_exists = FALSE, default = "day")

  # split met-files
  split <- get_switch(text = text, item = "SPLIT", item_exists = FALSE, default = FALSE)

  # --- main part of procedure ---

  create_precipitation_KNMI(
    dir_out = dir_out, station = station, tstart = tstart, tend = tend, topt = topt, split = split, replace = replace)

}

#' Create meteo files for SWAP (based on KNMI data)
#'
#' Based on observations from \href{https://www.knmi.nl/home}{KNMI}
#'
#' @param dir_out character string, name of directory
#' @param station character string, name(s) of meteo stations
#' @param tstart date, start of period
#' @param tend date, end of period
#' @param ... further arguments passed to or from other methods
#' @importFrom utils write.table
#' @importFrom stringr str_c str_sub str_replace_all str_to_upper str_pad
#' @importFrom fs path_package dir_create file_temp path_file
#' @importFrom readr read_rds read_csv
#' @importFrom lubridate year month day hour
#' @importFrom dplyr mutate filter select if_else left_join join_by
#' @importFrom rlang .data
#' @importFrom KNMItools get_station_KNMI download_meteo_KNMI actual_vapour_pressure
#' @importFrom ggplot2 ggsave
#' @details Download of daily meteorological data \code{topt} = 'day' (default) or hourly \code{topt} = 'hour' data.
#' Optionally the data is split in yearly files by specifying \code{split} = TRUE.
#' Missing data can be replaced by specifying by alternative stations with the option \code{replace}.
#' An overview of missing data can be obtained by specifying \code{analyse} = TRUE.
#'
#' In case of creating daily meteorological conditions, the averaged daytime windspeed is determined between 07:00 - 19:00 as required by Penman Monteith.
#' For backward compatibility reasons this behavior can be switched off by \code{daytime_windspeed} = FALSE. If so, a windfactor can be defined with \code{f_wind} (default: f_wind = 1.0).
#'
#' As preferred by Penman Monteith the actual vapour pressure in case of daily meteorological data, is by default determined by the minimum and maximum values of temperature and relative humidity.
#' In case \code{average_humidity} = .TRUE., the actual vapour pressure is determined by the minimum and maximum temperature and average humidity. In so, a humidity-factor can be defined with \code{f_hum} (default: f_hum = 1.0).
#' @export create_meteo_KNMI
#' @examples
#' # create SWAP meteo files from KNMI (do not run!)
#' #create_meteo_KNMI(dir_out = "../temp_swap",
#' # station = "de Bilt", tstart = "1980-01-01", tend = "1980-12-31")
create_meteo_KNMI <- function(dir_out, station, tstart, tend, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("topt", "split", "replace", "analyse", "width", "height", "daytime_windspeed", "f_wind", "average_humidity", "f_hum", "quiet")
  topt <- split <- replace <- analyse <- width <- height <- daytime_windspeed <- f_wind <- average_humidity <- f_hum <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(topt)) topt <- "day"
  if (is.null(split)) split <- FALSE
  if (is.null(analyse)) analyse <- FALSE
  if (is.null(width)) width <- 10.0
  if (is.null(height)) height <- 10.0
  if (is.null(daytime_windspeed)) daytime_windspeed <- TRUE
  if (is.null(f_wind)) f_wind <- 1.0
  if (is.null(average_humidity)) average_humidity <- FALSE
  if (is.null(f_hum)) f_hum <- 1.0
  if (is.null(quiet)) quiet <- TRUE

  # --- main part of procedure ---

  # check period
  tmax <- as_date(Sys.time())
  if (tend >= tmax) stop(str_c("tend should be earlier than ", tmax))

  # check user-specific input
  if (dir_out %in% c("", "./")) dir_out <- "."
  if (!topt %in% c("day", "hour")) stop("topt should be 'day' or 'hour'")
  if (f_wind < 0.5 || f_wind > 1.5) stop("f_wind should be in range 0.5 - 1.5")
  if (f_hum < 0.5 || f_hum > 1.5) stop("f_hum should be in range 0.5 - 1.5")

  station <- str_to_upper(string = station)
  if (!is.null(replace)) replace <- str_to_upper(string = replace)
  station_KNMI <- get_station_KNMI(type = "weather", station_name = c(station, replace))

  # variables to download
  if (topt == "day") {
    if (!average_humidity) {
      variable_humidity <- c("UN", "UX")
    } else {
      variable_humidity <- c("UG")
    }
    if (daytime_windspeed) {
      variable_day <- c("TN", "TX", "Q", "DR", "RH", variable_humidity, "EV24")
      variable_hour <- c("FH")
    } else {
      variable_day <- c("FG", "TN", "TX", "Q", "DR", "RH", variable_humidity, "EV24")
      variable_hour <- NULL
    }
  } else {
    variable_day <- NULL
    variable_hour <- c("FH", "T", "Q", "DR", "RH", "U")
  }

  # check date
  if (!is_date(tstart)) stop("unknown format for 'tstart', use 'YYYY-MM-DD'")
  if (!is_date(tend)) stop("unknown format for 'tend', use 'YYYY-MM-DD'")
  tstart <- as_date(tstart)
  tend <- as_date(tend)

  # create directory
  dir_tmp <- file_temp()
  dir_create(path = dir_tmp)

  # download data from KNMI
  if (!is.null(variable_day)) download_meteo_KNMI(dir_out = dir_tmp, station = station, variable = variable_day, tstart = tstart, tend = tend, topt = "day", replace = replace)
  if (!is.null(variable_hour)) download_meteo_KNMI(dir_out = dir_tmp, station = station, variable = variable_hour, tstart = tstart, tend = tend, topt = "hour", replace = replace)

  # loop over station
  for (s_station in station) {

    # set info station
    info <- station_KNMI |> filter(.data$STATION_NAME == s_station)

    # set file
    stn <- info$STATION_ID

    # load daily data
    gapfilling_stn <- NULL
    if (!is.null(variable_day)) {
      start <- format(x = tstart, "%Y%m%d")
      end <- format(x = tend, "%Y%m%d")
      file_knmi <- str_c(dir_tmp, "/KNMI_", info$STATION_ID, "_", start, "-", end, ".csv")
      col_types <- str_c("D-i", str_c(rep(x = "d", times = length(variable_day)), collapse = ""))
      db_day <- read_csv(file = file_knmi, col_names = TRUE, col_types = col_types, lazy = FALSE, num_threads = 1, progress = FALSE)
      stn_used <- unique(db_day$stn_id)
      if (length(stn_used[stn_used != info$STATION_ID]) > 0) gapfilling_stn <- stn_used[stn_used != info$STATION_ID]
    }

    # load hourly data
    if (!is.null(variable_hour)) {
      start <- str_c(format(x = tstart, "%Y%m%d"), "01")
      end <- str_c(format(x = tend, "%Y%m%d"), "24")
      file_knmi <- str_c(dir_tmp, "/KNMI_", info$STATION_ID, "_", start, "-", end, ".csv")
      col_types <- str_c("Dti", str_c(rep(x = "d", times = length(variable_hour)), collapse = ""))
      db_hour <- read_csv(file = file_knmi, col_names = TRUE, col_types = col_types, lazy = FALSE, num_threads = 1, progress = FALSE)
      stn_used <- unique(db_hour$stn_id)
      if (length(stn_used[stn_used != info$STATION_ID]) > 0) gapfilling_stn <- unique(c(gapfilling_stn, stn_used[stn_used != info$STATION_ID]))
    }

    if (topt == "day") {
      if (daytime_windspeed) {

        # determine daily average windspeed (07:00 - 19:00)
        db_hour <- db_hour |>
          filter(hour(.data$time) %in% 7:18) |>
          group_by(.data$date) |>
          summarise(FG = mean(.data$FH, na.rm = TRUE), .groups = "drop")

        db <- left_join(x = db_day, y = db_hour, by = join_by("date"))
      } else {
        db <- db_day
      }
    } else {
      db <- db_hour
    }

    # extract date info
    db <- db |>
      mutate(
        YYYY = year(.data$date),
        MM = str_pad(string = month(.data$date), width = 2, pad = "0"),
        DD = str_pad(string = day(.data$date), width = 2, pad = "0")
      )

    # check consistence between rainfall and duration
    # - Set rainfall to zero in case duration is less than 1.e-6
    # - Set duration to zero in case rainfall is less than 1.e-6
    db <- db |>
      mutate(
        RH = if_else(.data$DR < 1.e-6, 0, .data$RH),
        DR = if_else(.data$RH < 1.e-6, 0, .data$DR)
      )

    # windfactor (optional)
    if (!daytime_windspeed && f_wind != 1.0) {
      db <- db |> mutate(FG = .data$FG * f_wind)
    }

    # convert relative humidity UG [%] to actual vapour pressure HUM [kPa]
    if (topt == "day") {
      if (!average_humidity) {
        db <- db |> mutate(HUM = actual_vapour_pressure(TN = .data$TN, TX = .data$TX, UN = .data$UN, UX = .data$UX))
      } else {
        db <- db |> mutate(HUM = actual_vapour_pressure(TN = .data$TN, TX = .data$TX, UG = .data$UG))
        if (f_hum != 1.0) db <- db |> mutate(HUM = .data$HUM * f_hum)
      }
    } else {
      db <- db |> mutate(HUM = actual_vapour_pressure(TN = .data$T, TX = .data$T, UG = .data$U))
    }

    # prepare output
    if (topt == "day") {
      db <- db |>
        mutate(
          STN = str_c("'", .data$stn_id, "'"),
          Q = if_else(is.na(.data$Q), NA_character_, formatC(x = .data$Q, format = "f", digits = 1)),
          TN = if_else(is.na(.data$TN), NA_character_, formatC(x = .data$TN, format = "f", digits = 1)),
          TX = if_else(is.na(.data$TX), NA_character_, formatC(x = .data$TX, format = "f", digits = 1)),
          HUM = if_else(is.na(.data$HUM), NA_character_, formatC(x = .data$HUM, format = "f", digits = 6)),
          FG = if_else(is.na(.data$FG), NA_character_, formatC(x = .data$FG, format = "f", digits = 2)),
          RH = if_else(is.na(.data$RH), NA_character_, formatC(x = .data$RH, format = "f", digits = 3)),
          EV24 = if_else(is.na(.data$EV24), NA_character_, formatC(x = .data$EV24, format = "f", digits = 1)),
          DR = if_else(is.na(.data$DR), NA_character_, formatC(x = .data$DR, format = "f", digits = 3))
        )
    } else {
      db <- db |>
        mutate(
          rec = hour(.data$time) + 1,
          Q = if_else(is.na(.data$Q), NA_character_, formatC(x = .data$Q, format = "f", digits = 1)),
          T = if_else(is.na(.data$T), NA_character_, formatC(x = .data$T, format = "f", digits = 1)),
          HUM = if_else(is.na(.data$HUM), NA_character_, formatC(x = .data$HUM, format = "f", digits = 6)),
          FH = if_else(is.na(.data$FH), NA_character_, formatC(x = .data$FH, format = "f", digits = 2)),
          RH = if_else(is.na(.data$RH), NA_character_, formatC(x = .data$RH, format = "f", digits = 3))
        )
    }

    # create header
    header <- c(
      "*------------------------------------------------------------------------------------",
      "* Source of data    : Royal Netherlands Meterological Institute (https://www.knmi.nl)",
      "* File content      : Meteo data for SWAP 4.3.0 (https://swap.wur.nl)",
      "*",
      str_c("* Station           : ", info$STATION_NAME, " (", info$STATION_ID,")"),
      str_c("* Longitude         : ", ifelse(is.na(info$LON), "unknown", info$LON)),
      str_c("* Latitude          : ", ifelse(is.na(info$LAT), "unknown", info$LAT)),
      str_c("* Altitude          : ", ifelse(is.na(info$ALT), "unknown", info$ALT)),
      "*")

    if (topt == "day") {
      header <- c(header,
                  "* Rad               : Solar radiation (kJ m-2)",
                  "* Tmin              : Minimum air temperature (degree C)",
                  "* Tmax              : Maximum air temperature (degree C)",
                  ifelse(!average_humidity,
                         "* Hum               : Air humidity (kPa)",
                         str_c("* Hum               : Air humidity (kPa); determined by average humidity", ifelse(f_hum != 1.0, str_c("; humidityfactor: ", f_hum), ""))),
                  ifelse(daytime_windspeed,
                         "* Wind              : Average windspeed; 7-19h (m s-1)",
                         str_c("* Wind              : Average windspeed; 24h (m s-1)", ifelse(f_wind != 1.0, str_c("; windfactor: ", f_wind), ""))),
                  "* Rain              : Rainfall (mm)",
                  "* ETref             : Reference evapotranspiration; Makkink (mm)",
                  "* Wet               : Fraction of time with rainfall (-)")
    } else {
      header <- c(header,
                  "* Rad               : Solar radiation (kJ m-2)",
                  "* Temp              : Air temperature (degree C)",
                  "* Hum               : Air humidity (kPa)",
                  "* Wind              : Average windspeed (m s-1)",
                  "* Rain              : Rainfall (mm)")
    }

    if (!is.null(gapfilling_stn)) {
      header <- c(header, "*")
      for (s_replace in replace) {
        info_alt <- station_KNMI |> filter(.data$STATION_NAME == s_replace)
        if (info_alt$STATION_ID %in% gapfilling_stn) header <- c(header, str_c("* Missing values are replaced by station ", info_alt$STATION_NAME, " (", info_alt$STATION_ID,")"))
      }
    }

    header <- c(header,
      "*",
      "* File generated by : Wageningen Environmental Research",
      str_c("* File generated at : ",str_sub(string = Sys.time(), start = 1, end = 20)),
      "*------------------------------------------------------------------------------------",
      ifelse(topt == "day", "Station,DD,MM,YYYY,Rad,Tmin,Tmax,Hum,Wind,Rain,ETref,Wet", "Date,Record,Rad,Temp,Hum,Wind,Rain"))

    # create output directory
    dir_create(dir_out)

    # create meteo files
    if (!split) {

      # prepare output
      if (topt == "day") {
        db <- db |> select("STN", "DD", "MM", "YYYY", "Q", "TN", "TX", "HUM", "FG", "RH", "EV24", "DR")
      } else {
        db <- db |> select("date", "rec", "Q", "T", "HUM", "FH", "RH")
      }

      # write data
      file <- str_c(dir_out, "/", info$STATION_ID, ifelse(topt == "day", "", "_h"), ".met")
      writeLines(text = header, con = file)
      write.table(x = db, file = file, na = "-99.9", sep = ",", dec = ".", append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE)

      if(any(is.na(db))) warning("incomplete data for file: ", file, "\n")

    } else {

      for (year in unique(db$YYYY)) {

        s_db <- db |> filter(.data$YYYY == year)

        # prepare output
        if (topt == "day") {
          s_db <- s_db |> select("STN", "DD", "MM", "YYYY", "Q", "TN", "TX", "HUM", "FG", "RH", "EV24", "DR")
        } else {
          s_db <- s_db |> select("date", "rec", "Q", "T", "HUM", "FH", "RH")
        }

        # write data
        file <- str_c(dir_out, "/", info$STATION_ID, ifelse(topt == "day", "", "_h"), ".", str_sub(string = year, start = 2, end = 4))
        writeLines(text = header, con = file)
        write.table(x = s_db, file = file, na = "-99.9", sep = ",", dec = ".", append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE)

        if(any(is.na(s_db))) warning("incomplete data for file: ", file, "\n")

      }
    }

    # analyse meteorological conditions (optional)
    if (analyse) {
      if (topt == "day") {
        db <- db |> select("STN", "DD", "MM", "YYYY", "Q", "TN", "TX", "HUM", "FG", "RH", "EV24", "DR")
      } else {
        db <- db |> select("date", "rec", "Q", "T", "HUM", "FH", "RH")
      }
      filename <- str_c(dir_out, "/KNMI_", info$STATION_ID, "_", format(x = tstart, "%Y%m%d"), "-", format(x = tend, "%Y%m%d"), ".png")
      ggsave(filename = filename, plot = plot_meteo(db = db)$plot, width = width, height = height, dpi = "retina", bg = "white")
      if (!quiet) message(str_c("create plot: ", path_file(filename)))
    }

    # clean directory
    unlink(x = file_knmi, force = TRUE)
  }
}

#' Create precipitation files for SWAP (based on KNMI data)
#'
#' Based on observations from \href{https://www.knmi.nl/home}{KNMI}
#'
#' @param dir_out character string, name of directory
#' @param station character string, name(s) of meteo stations
#' @param tstart date, start of period
#' @param tend date, end of period
#' @param ... further arguments passed to or from other methods
#' @importFrom utils write.table
#' @importFrom stringr str_c str_sub str_replace_all str_to_upper str_pad
#' @importFrom fs path_package dir_create file_temp
#' @importFrom readr read_rds read_csv
#' @importFrom lubridate year month day hour as_date
#' @importFrom dplyr mutate filter select if_else lead
#' @importFrom rlang .data
#' @importFrom KNMItools get_station_KNMI download_precipitation_KNMI download_meteo_KNMI
#' @details Download of daily precipitation \code{topt} = 'day' or hourly precipitation \code{topt} = 'hour'.
#' Optionally the data is split in yearly files by specifying \code{split} = TRUE.
#' Missing data can be replaced by specifying a second station with the option \code{replace}.
#' @export create_precipitation_KNMI
#' @examples
#' # create SWAP precipitation files from KNMI (do not run!)
#' #create_precipitation_KNMI(dir_out = "../temp_swap",
#' # station = "de-Bilt", tstart = "1980-01-01", tend = "1980-12-31")
create_precipitation_KNMI <- function(dir_out, station, tstart, tend, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("topt", "split", "replace")
  topt <- split <- replace <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(topt)) topt <- "day"
  if (is.null(split)) split <- FALSE

  # --- main part of procedure ---

  station <- str_to_upper(string = station)
  if (!is.null(replace)) replace <- str_to_upper(string = replace)

  # load settings KNMI
  if (topt == "day") {
    station_KNMI <- get_station_KNMI(type = "precipitation", station_name = c(station, replace))
  } else {
    station_KNMI <- get_station_KNMI(type = "weather", station_name = c(station, replace))
  }

  # check period
  tmax <- as_date(Sys.time()) - 1
  if (tend >= tmax) stop(str_c("tend should be earlier than ", tmax))

  # create directory
  dir_tmp <- file_temp()
  dir_create(path = dir_tmp)

  # download data from KNMI
  if (topt == "day") {
    download_precipitation_KNMI(dir_out = dir_tmp, station = station, tstart = tstart, tend = tend, replace = replace)
  } else {
    download_meteo_KNMI(dir_out = dir_tmp, station = station, variable = "RH", tstart = as_date(tstart), tend = as_date(tend), topt = topt, replace = replace)
  }

  # loop over station
  for (s_station in station) {

    # set info station
    info <- station_KNMI |> filter(.data$STATION_NAME == s_station)

    # set file
    start <- format(x = as_date(tstart), "%Y%m%d")
    end <- format(x = as_date(tend), "%Y%m%d")
    if (topt == "day") {
      file_knmi <- str_c(dir_tmp, "/KNMI_", str_pad(string = info$STATION_ID, width = 3, pad = "0"), "_", start, "-", end, "_prec.csv")
    } else {
      file_knmi <- str_c(dir_tmp, "/KNMI_", str_pad(string = info$STATION_ID, width = 3, pad = "0"), "_", start, "01-", end, "24.csv")
    }

    # load data and shift one timestep
    db <- read_csv(file = file_knmi, col_names = TRUE, col_types = "Dtid", lazy = FALSE, num_threads = 1, progress = FALSE) |>
      mutate(
        date = lead(.data$date),
        time = lead(.data$time)
      ) |>
      filter(.data$date >= tstart, .data$date <= tend)

    # rename variable in case of precipitation station
    if (topt == "day") db <- db |> rename(RH = "RD")

    # check gapfilling data
    gapfilling_stn <- NULL
    stn_used <- unique(db$stn_id)
    if (length(stn_used[stn_used != info$STATION_ID]) > 0) gapfilling_stn <- stn_used[stn_used != info$STATION_ID]

    # extract date info
    db <- db |>
      mutate(
        YYYY = year(.data$date),
        MM = str_pad(string = month(.data$date), width = 2, pad = "0"),
        DD = str_pad(string = day(.data$date), width = 2, pad = "0"),
        HH = hour(.data$time),
        FacDay = .data$HH / 24.0,
        FacDay = if_else(is.na(.data$FacDay), NA_character_, formatC(x = .data$FacDay, format = "f", digits = 3)),
        RH = if_else(is.na(.data$RH), NA_character_, formatC(x = .data$RH, format = "f", digits = 1))
      ) |>
      select("stn_id", "DD", "MM", "YYYY", "FacDay", "RH")

    # create header
    header <- c(
      "*------------------------------------------------------------------------------------",
      "* Source of data    : Royal Netherlands Meterological Institute (https://www.knmi.nl)",
      "* File content      : Precipitation data SWAP 4.3.0 (https://swap.wur.nl)",
      "*",
      str_c("* Station           : ", str_to_upper(s_station), " (", info$STATION_ID,")"),
      str_c("* Longitude         : ", ifelse(is.na(info$LON), "unknown", info$LON)),
      str_c("* Latitude          : ", ifelse(is.na(info$LAT), "unknown", info$LAT)),
      str_c("* Altitude          : ", ifelse(is.na(info$ALT), "unknown", info$ALT)))

    if (!is.null(gapfilling_stn)) {
      header <- c(header, "*")
      for (s_replace in replace) {
        info_alt <- station_KNMI |> filter(.data$STATION_NAME == s_replace)
        if (info_alt$STATION_ID %in% gapfilling_stn) header <- c(header, str_c("* Missing values are replaced by station ", str_to_upper(s_replace), " (", info_alt$STATION_ID,")"))
      }
    }

    header <- c(header,
      "*",
      "* File generated by : Wageningen Environmental Research",
      str_c("* File generated at : ",str_sub(string = Sys.time(), start = 1, end = 20)),
      "*------------------------------------------------------------------------------------",
      "Station,Day,Month,Year,Time,Amount"
    )

    # create output directory
    dir_create(dir_out)

    # create precipitation files
    if (!split) {

      # write data
      file <- str_c(dir_out, "/", str_pad(string = info$STATION_ID, width = 3, pad = "0"), ".rain")
      writeLines(text = header, con = file)
      write.table(x = db, file = file, na = "-99.9", sep = ",", dec = ".", append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE)

      if(any(is.na(db))) warning("incomplete data for file: ", file, "\n")

    } else {

      for (year in unique(db$YYYY)) {

        s_db <- db |> filter(.data$YYYY == year)

        # write data
        file <- str_c(dir_out, "/", str_pad(string = info$STATION_ID, width = 3, pad = "0"), "_prec.", str_sub(string = year, start = 2, end = 4))
        writeLines(text = header, con = file)
        write.table(x = s_db, file = file, na = "-99.9", sep = ",", dec = ".", append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE)

        if(any(is.na(s_db))) warning("incomplete data for file: ", file, "\n")
      }
    }

  }

  # clean directory
  unlink(x = dir_tmp, recursive = TRUE, force = TRUE)

}

#' Create meteo files for SWAP (based on AgERA5 data)
#'
#' Based on observations from \href{https://cds.climate.copernicus.eu}{AgERA5}
#'
#' @param dir_out character string, name of directory
#' @param latitude numeric, the latitude of the site in decimal degrees
#' @param longitude numeric, the longitude of the site in decimal degrees
#' @param tstart date, start of period
#' @param tend date, end of period
#' @param ... further arguments passed to or from other methods
#' @importFrom utils write.table
#' @importFrom stringr str_c str_sub str_replace_all str_to_upper
#' @importFrom fs path_package dir_create file_temp path_file
#' @importFrom readr read_rds read_csv
#' @importFrom lubridate year month day
#' @importFrom dplyr mutate filter select if_else
#' @importFrom rlang .data
#' @importFrom KNMItools download_meteo_AgERA5
#' @importFrom ggplot2 ggsave
#' @details Download of meteorological data.
#' Optionally the data is split in yearly files by specifying \code{split} = TRUE.
#' An overview of the data can be obtained by specifying \code{analyse} = TRUE.
#'
#' It is known that the precipitation predicted by AgERA5 is biased in certain areas, particularly in the tropics.
#' Therefore this procedure provides the opportunity to replace the precipitation estimates from AgERA5 with precipitation
#' estimates from CHIRPS by specifying \code{opt_rain}.
#' @export create_meteo_AgERA5
#' @keywords internal
create_meteo_AgERA5 <- function(dir_out, latitude, longitude, tstart, tend, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("opt_rain", "split", "analyse", "width", "height", "quiet")
  opt_rain <- split <- analyse <- width <- height <- quiet <- NULL
  output <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(opt_rain)) opt_rain <- "AgERA5"
  if (!opt_rain %in% c("AgERA5", "CHIRPS")) stop("rain should be specified with 'AgERA5' (default) or 'CHIRPS'")
  if (is.null(split)) split <- FALSE
  if (is.null(analyse)) analyse <- FALSE
  if (is.null(width)) width <- 10.0
  if (is.null(height)) height <- 10.0
  if (is.null(quiet)) quiet <- TRUE

  # check period
  tmax <- as_date(Sys.time())
  if (tend >= tmax) stop(str_c("tend should be earlier than ", tmax))

  variable <- c("windspeed", "temperature_min", "temperature_max", "radiation", "precipitation", "vapourpressure")

  # --- main part of procedure ---

  # create directory
  dir_tmp <- file_temp()
  dir_create(path = dir_tmp)

  # download data from KNMI
  download_meteo_AgERA5(dir_out = dir_tmp, latitude = latitude, longitude = longitude, variable = variable, tstart = tstart, tend = tend, opt_rain = opt_rain)

  # set file
  start_id <- str_replace_all(string = tstart, pattern = "-", replacement = "")
  end_id <- str_replace_all(string = tend, pattern = "-", replacement = "")
  file_AgERA <- str_c(dir_tmp, "/AgERA5", ifelse(opt_rain == "CHIRPS", "-CHIRPS", ""), "_", start_id, "-", end_id, ".csv")

  # load header
  header <- read_lines(file = file_AgERA, n_max = 10, lazy = FALSE, num_threads = 1, progress = FALSE)
  long <- str_trim(string = str_split(string = header[str_detect(string = header, pattern = "Longitude")], pattern = ":", simplify = TRUE)[2])
  lat <- str_trim(string = str_split(string = header[str_detect(string = header, pattern = "Latitude")], pattern = ":", simplify = TRUE)[2])
  alt <- str_trim(string = str_split(string = header[str_detect(string = header, pattern = "Altitude")], pattern = ":", simplify = TRUE)[2])

  long_id <- formatC(x = as.numeric(long) * 100, format = "d", width = 4, flag = "0")
  lat_id <- formatC(x = as.numeric(lat) * 100, format = "d", width = 4, flag = "0")

  # load data
  db <- read_csv(file = file_AgERA, col_names = TRUE, comment = "*", col_types = "D-dddddd", lazy = FALSE, num_threads = 1, progress = FALSE)

  # extract date info
  db <- db |>
    mutate(
      YYYY = year(.data$date),
      MM = formatC(x = month(.data$date), format = "d", width = 2, flag = "0"),
      DD = formatC(x = day(.data$date), format = "d", width = 2, flag = "0")
    )

  # prepare output
  db <- db |>
    mutate(
      STN = opt_rain,
      radiation = if_else(is.na(.data$radiation), NA_character_, formatC(x = .data$radiation, format = "f", digits = 1)),
      temperature_min = if_else(is.na(.data$temperature_min), NA_character_, formatC(x = .data$temperature_min, format = "f", digits = 1)),
      temperature_max = if_else(is.na(.data$temperature_max), NA_character_, formatC(x = .data$temperature_max, format = "f", digits = 1)),
      vapourpressure = if_else(is.na(.data$vapourpressure), NA_character_, formatC(x = .data$vapourpressure, format = "f", digits = 6)),
      windspeed = if_else(is.na(.data$windspeed), NA_character_, formatC(x = .data$windspeed, format = "f", digits = 1)),
      precipitation = if_else(is.na(.data$precipitation), NA_character_, formatC(x = .data$precipitation, format = "f", digits = 3)),
      etref = NA_character_,
      duration = NA_character_
    ) |>
    select("STN", "DD", "MM", "YYYY", "radiation", "temperature_min", "temperature_max", "vapourpressure", "windspeed", "precipitation", "etref", "duration")

  # create header
  header <- c(
    "*------------------------------------------------------------------------------------",
    str_c("* Source of data    : AgERA5", ifelse(opt_rain == "CHIRPS", "-CHIRPS", ""), " (https://cds.climate.copernicus.eu)"),
    "* File content      : Meteo data for SWAP 4.3.0 (https://swap.wur.nl)",
    "*",
    str_c("* Longitude         : ", long),
    str_c("* Latitude          : ", lat),
    str_c("* Altitude          : ", alt),
    "*",
    "* Rad               : Solar radiation (kJ m-2)",
    "* Tmin              : Minimum air temperature (degree C)",
    "* Tmax              : Maximum air temperature (degree C)",
    "* Hum               : Air humidity (kPa)",
    "* Wind              : Average windspeed; 24h (m s-1)",
    "* Rain              : Rainfall (mm)",
    "* ETref             : Reference evapotranspiration (mm)",
    "* Wet               : Duration of rainfall (d)",
    "*",
    "* File generated by : Wageningen Environmental Research",
    str_c("* File generated at : ",str_sub(string = Sys.time(), start = 1, end = 20)),
    "*------------------------------------------------------------------------------------",
    "Station,DD,MM,YYYY,Rad,Tmin,Tmax,Hum,Wind,Rain,ETref,Wet"
  )

  # create output directory
  dir_create(dir_out)

  # create meteo files
  if (!split) {

    # write data
    file <- str_c(dir_out, "/", long_id, "_", lat_id, ".met")
    writeLines(text = header, con = file)
    write.table(x = db, file = file, na = "-99.9", sep = ",", dec = ".", append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE)

    db_tmp <- db |> select(-"etref", -"duration")
    if (any(is.na(db_tmp))) warning("incomplete data for file: ", file, "\n")

  } else {

    for (year in unique(db$YYYY)) {

      s_db <- db |> filter(.data$YYYY == year)

      # write data
      file <- str_c(dir_out, "/", long_id, "_", lat_id, ".", str_sub(string = year, start = 2, end = 4))
      writeLines(text = header, con = file)
      write.table(x = s_db, file = file, na = "-99.9", sep = ",", dec = ".", append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE)

      db_tmp <- s_db |> select(-"etref", -"duration")

      if (any(is.na(db_tmp))) warning("incomplete data for file: ", file, "\n")

    }
  }

  # analyse meteorological conditions (optional)
  if (analyse) {
    start <- format(x = tstart, "%Y%m%d")
    end <- format(x = tend, "%Y%m%d")
    filename <- str_c(dir_out, "/AgERA5", ifelse(opt_rain == "CHIRPS", "-CHIRPS", ""), "_", start, "-", end, ".png")
    ggsave(filename = filename, plot = plot_meteo(db = db)$plot, width = width, height = height, dpi = "retina", bg = "white")
    if (!quiet) message(str_c("create plot: ", path_file(filename)))
  }

  # clean directory
  unlink(x = file_AgERA, force = TRUE)
}

#' Create meteo files for SWAP (based on OPEN-METEO data)
#'
#' Based on observations from \href{https://open-meteo.com}{OPEN-METEO}
#'
#' @param dir_out character string, name of directory
#' @param latitude numeric, the latitude of the site in decimal degrees
#' @param longitude numeric, the longitude of the site in decimal degrees
#' @param tstart date, start of period
#' @param tend date, end of period
#' @param ... further arguments passed to or from other methods
#' @importFrom utils write.table
#' @importFrom stringr str_c str_sub str_replace_all str_to_upper str_pad
#' @importFrom fs path_package dir_create file_temp path_file
#' @importFrom readr read_rds read_csv
#' @importFrom lubridate year month day hour
#' @importFrom dplyr mutate filter select if_else left_join join_by
#' @importFrom rlang .data
#' @importFrom KNMItools download_meteo_OPENMETEO actual_vapour_pressure
#' @importFrom ggplot2 ggsave
#' @export create_meteo_OPENMETEO
create_meteo_OPENMETEO <- function(dir_out, latitude, longitude, tstart, tend, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("split", "analyse", "width", "height", "quiet")
  split <- analyse <- width <- height <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(split)) split <- FALSE
  if (is.null(analyse)) analyse <- FALSE
  if (is.null(width)) width <- 10.0
  if (is.null(height)) height <- 10.0
  if (is.null(quiet)) quiet <- TRUE

  # --- main part of procedure ---

  # check period
  tmax <- as_date(Sys.time())
  if (tend >= tmax) stop(str_c("tend should be earlier than ", tmax))

  # check user-specific input
  if (dir_out %in% c("", "./")) dir_out <- "."

  # check date
  if (!is_date(tstart)) stop("unknown format for 'tstart', use 'YYYY-MM-DD'")
  if (!is_date(tend)) stop("unknown format for 'tend', use 'YYYY-MM-DD'")
  tstart <- as_date(tstart)
  tend <- as_date(tend)

  # set location
  long_id <- str_pad(string = as.numeric(longitude) * 100, width = 4, pad = "0")
  lat_id <- str_pad(string = as.numeric(latitude) * 100, width = 4, pad = "0")

  # create directory
  dir_tmp <- file_temp()
  dir_create(path = dir_tmp)

  # download data from OPEN-METEO
  download_meteo_OPENMETEO(dir_out = dir_tmp, latitude = latitude, longitude = longitude, tstart = tstart, tend = tend)

  # set filename
  file_csv <- str_c(dir_tmp, "/openmeteo_", format(x = tstart, "%Y%m%d"), "-", format(x = tend, "%Y%m%d"), ".csv")

  # load meta-information
  db_info <- read_lines(file = file_csv, n_max = 12)
  info <- list(
    LON = str_squish(string = str_split(string = db_info[str_which(string = db_info, pattern = "Longitude")], pattern = ":", simplify = TRUE)[,2]),
    LAT = str_squish(string = str_split(string = db_info[str_which(string = db_info, pattern = "Latitude")], pattern = ":", simplify = TRUE)[,2]),
    ALT = str_squish(string = str_split(string = db_info[str_which(string = db_info, pattern = "Altitude")], pattern = ":", simplify = TRUE)[,2]),
    TZ = str_squish(string = str_split(string = db_info[str_which(string = db_info, pattern = "Timezone")], pattern = ":", simplify = TRUE)[,2])
  )

  # load data
  db <- read_csv(file = file_csv, comment = "*", col_types = "Dddddddddd")

  # extract date info
  db <- db |>
    mutate(
      YYYY = year(.data$date),
      MM = str_pad(string = month(.data$date), width = 2, pad = "0"),
      DD = str_pad(string = day(.data$date), width = 2, pad = "0")
    )

  # check consistence between rainfall and duration
  # - Set rainfall to zero in case duration is less than 1.e-6
  # - Set duration to zero in case rainfall is less than 1.e-6
  db <- db |>
    mutate(
      RH = if_else(.data$DR < 1.e-6, 0, .data$RH),
      DR = if_else(.data$RH < 1.e-6, 0, .data$DR)
    )

  # convert relative humidity UG [%] to actual vapour pressure HUM [kPa]
  db <- db |> mutate(HUM = actual_vapour_pressure(TN = .data$TN, TX = .data$TX, UN = .data$UN, UX = .data$UX))

  # prepare output
  db <- db |>
    mutate(
      STN = str_c("'open-meteo'"),
      Q = if_else(is.na(.data$Q), NA_character_, formatC(x = .data$Q, format = "f", digits = 1)),
      TN = if_else(is.na(.data$TN), NA_character_, formatC(x = .data$TN, format = "f", digits = 1)),
      TX = if_else(is.na(.data$TX), NA_character_, formatC(x = .data$TX, format = "f", digits = 1)),
      HUM = if_else(is.na(.data$HUM), NA_character_, formatC(x = .data$HUM, format = "f", digits = 6)),
      FG = if_else(is.na(.data$FG), NA_character_, formatC(x = .data$FG, format = "f", digits = 2)),
      RH = if_else(is.na(.data$RH), NA_character_, formatC(x = .data$RH, format = "f", digits = 3)),
      EV24 = if_else(is.na(.data$ET0), NA_character_, formatC(x = .data$ET0, format = "f", digits = 1)),
      DR = if_else(is.na(.data$DR), NA_character_, formatC(x = .data$DR, format = "f", digits = 3))
    )

  # create header
  header <- c(
    "*------------------------------------------------------------------------------------",
    "* Source of data    : OPEN-METEO (https://open-meteo.com)",
    "* File content      : Meteo data for SWAP 4.3.0 (https://swap.wur.nl)",
    "*",
    str_c("* Longitude         : ", ifelse(is.na(info$LON), "unknown", info$LON)),
    str_c("* Latitude          : ", ifelse(is.na(info$LAT), "unknown", info$LAT)),
    str_c("* Altitude          : ", ifelse(is.na(info$ALT), "unknown", info$ALT)),
    "*",
    str_c("* Timezone          : ", ifelse(is.na(info$TZ), "unknown", info$TZ)),
    "*",
    "* Rad               : Solar radiation (kJ m-2)",
    "* Tmin              : Minimum air temperature (degree C)",
    "* Tmax              : Maximum air temperature (degree C)",
    "* Hum               : Air humidity (kPa)",
    "* Wind              : Average windspeed; 24h (m s-1)",
    "* Rain              : Rainfall (mm)",
    "* EV24              : Reference evapotranspiration; FAO (mm)",
    "* Wet               : Fraction of time with rainfall (-)",
    "*",
    "* File generated by : Wageningen Environmental Research",
    str_c("* File generated at : ",str_sub(string = Sys.time(), start = 1, end = 20)),
    "*------------------------------------------------------------------------------------",
    "Station,DD,MM,YYYY,Rad,Tmin,Tmax,Hum,Wind,Rain,ETref,Wet")

  # create output directory
  dir_create(dir_out)

  # create meteo files
  if (!split) {

    # prepare output
    db <- db |> select("STN", "DD", "MM", "YYYY", "Q", "TN", "TX", "HUM", "FG", "RH", "EV24", "DR")

    # write data
    file <- str_c(dir_out, "/", long_id, "_", lat_id, ".met")
    writeLines(text = header, con = file)
    write.table(x = db, file = file, na = "-99.9", sep = ",", dec = ".", append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE)

    if(any(is.na(db))) warning("incomplete data for file: ", file, "\n")

  } else {

    for (year in unique(db$YYYY)) {

      s_db <- db |> filter(.data$YYYY == year)

      # prepare output
      s_db <- s_db |> select("STN", "DD", "MM", "YYYY", "Q", "TN", "TX", "HUM", "FG", "RH", "EV24", "DR")

      # write data
      file <- str_c(dir_out, "/", long_id, "_", lat_id, ".", str_sub(string = year, start = 2, end = 4))
      writeLines(text = header, con = file)
      write.table(x = s_db, file = file, na = "-99.9", sep = ",", dec = ".", append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE)

      if(any(is.na(s_db))) warning("incomplete data for file: ", file, "\n")

    }
  }

  # analyse meteorological conditions (optional)
  if (analyse) {
    db <- db |> select("STN", "DD", "MM", "YYYY", "Q", "TN", "TX", "HUM", "FG", "RH", "EV24", "DR")
    filename <- str_c(dir_out, "/openmeteo_", long_id, "-", lat_id, "_", format(x = tstart, "%Y%m%d"), "-", format(x = tend, "%Y%m%d"), ".png")
    ggsave(filename = filename, plot = plot_meteo(db = db)$plot, width = width, height = height, dpi = "retina", bg = "white")
    if (!quiet) message(str_c("create plot: ", path_file(filename)))
  }

  # clean directory
  unlink(x = file_csv, force = TRUE)
}


#' Create overview of available meteorological data
#'
#' @description Based on the data provided (\code{db}) an overview will be created with available observations present in the data.
#' @param db tibble with meteorological data (SWAP format)
#' @importFrom lubridate year yday
#' @importFrom dplyr mutate across any_of select group_by summarise slice
#' @importFrom rlang .data
#' @importFrom ggplot2 ggplot aes geom_raster scale_fill_gradientn scale_y_reverse scale_x_continuous labs
#' @importFrom pals viridis
#' @importFrom ggpubr ggarrange
#' @importFrom controlR get_my_theme
#' @details Hourly data will be aggregated to daily values before plotting.
#' Optionally a selection of the data can be analysed by specifying either \code{variable} and/or the period using \code{tstart} and \code{tend}.
#' The size of the plot can be adjusted by specifying \code{width} (default 10.0) and/or \code{height} (default 16.0).
#' @keywords internal
#' @export plot_meteo
plot_meteo <- function(db) {

  # --- initial part of procedure ---

  # settings of x-axes
  labels <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
  first_day_decade_365 <- c(1, 11, 21, 32, 42, 52, 60, 70, 80, 91, 101, 111, 121, 131, 141, 152, 162, 172, 182, 192, 202, 213, 223, 233, 244, 254, 264, 274, 284, 294, 305, 315, 325, 335, 345, 355)
  breaks <- first_day_decade_365[seq(from = 1, to = 36, by = 3)]
  minor_breaks <- first_day_decade_365[sort(c(seq(from = 2, to = 36,by = 3), seq(from = 3, to = 36, by = 3)))]

  # --- main part of procedure ---

  # create date info
  if ("YYYY" %in% names(db)) {

    lookup <- c(
      Q = "radiation", EV24 = "etref",
      TN = "temperature_min", TX = "temperature_max",
      HUM = "vapourpressure", FG = "windspeed",
      RH = "precipitation", DR = "duration")

    db <- db |>
      rename(any_of(lookup)) |>
      mutate(
        date = as_date(str_c(.data$YYYY, .data$MM, .data$DD, sep = "-")),
        year = year(.data$date),
        daynr = yday(.data$date)
      ) |>
      select(-"YYYY", -"MM", -"DD", -"date") |>
      mutate(across(.cols = all_of(c("Q", "TN", "TX", "HUM", "FG", "RH", "EV24", "DR")), as.numeric))

  } else {

    db <- db |>
      mutate(
        date = as_date(.data$date),
        year = year(.data$date),
        daynr = yday(.data$date)
      ) |>
      select(-"date", -"rec") |>
      mutate(across(.cols = all_of(c("Q", "T", "HUM", "FH", "RH")), as.numeric)) |>
      group_by(.data$year, .data$daynr) |>
      summarise(
        Q = sum(.data$Q),
        T = mean(.data$T),
        HUM = mean(.data$HUM),
        FH = mean(.data$FH),
        RH = sum(.data$RH),
        .groups = "drop"
      )

  }

  # set variables
  variable <- names(db)[!names(db) %in% c("year", "daynr", "STN")]

  # create list of figures
  plotlist <- list()
  for (s_variable in variable) {

    # subset data
    db_fig <- db |>
      rename(value = all_of(s_variable)) |>
      select("year", "daynr", "value")

    # set labels
    if (s_variable == "Q") label <- "bold(Solar~radiation)~(kJ~m^-2)"
    if (s_variable == "TN") label <- "bold(Minimum~air~temperature)~(degree*C)"
    if (s_variable == "TX") label <- "bold(Maximum~air~temperature)~(degree*C)"
    if (s_variable == "T") label <- "bold(Air~temperature)~(degree*C)"
    if (s_variable == "HUM") label <- "bold(Air~humidity)~(kPa)"
    if (s_variable %in% c("FG", "FH")) label <- "bold(Average~windspeed)~(m~s^-1)"
    if (s_variable == "RH") label <- "bold(Rainfall)~(mm)"
    if (s_variable == "DR") label <- "bold(Rainfall~duration)~('-')"
    if (s_variable == "EV24") label <- "bold(Reference~evapotranspiration)~(mm)"

    # check if any data is available
    if (!any(!is.na(db_fig$value))) {
      dummy_data <- db_fig |>
        slice(1:2) |>
        mutate(
          daynr = c(400, 401),
          value = c(99,-99)
        )
      db_fig <- rbind(db_fig, dummy_data)
    }

    # create plot
    p <- ggplot(data = db_fig) +
      geom_raster(aes(x = .data$daynr, y = .data$year, fill = .data$value), na.rm = TRUE) +
      scale_y_reverse(breaks = unique(db_fig$year)) +
      scale_x_continuous(breaks = breaks, minor_breaks = minor_breaks, labels = labels, limits = c(1,366)) +
      scale_fill_gradientn(name = "", colors = viridis(100), na.value = "red") +
      labs(title = parse(text = label), x = "", y = "") +
      get_my_theme("figure")

    plotlist[[length(plotlist) + 1]] <- p
  }

  # set return of procedure
  p <- ggarrange(plotlist = plotlist, ncol = 1, align = "v")
  output <- list(plot = p)

  # --- return of procedure ---

  return(output)
}

