#' Create sql-database from xls-file (SWAP-variables)
#'
#' @param file_xls character string, name of xls-file.
#' @param file_sql character string, name of sql-file.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_split str_detect
#' @importFrom fs path_package path_dir path_file file_exists dir_create
#' @importFrom readr read_rds
#' @importFrom RSQLite dbConnect SQLite dbGetQuery dbWriteTable dbExecute dbDisconnect SQLITE_RWC
#' @importFrom readxl excel_sheets read_excel cell_rows
#' @importFrom dplyr pull all_of
#' @importFrom progress progress_bar
#' @export create_database_SWAP
create_database_SWAP <- function(file_xls, file_sql, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("quiet")
  quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param)) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(quiet)) quiet <- FALSE

  # --- main part of procedure ---

  # delete old database
  if (file_exists(path = file_sql)) unlink(x = file_sql, force = TRUE)

  # set variables
  inp <- .swp_env$inp
  variable <- names(inp)

  # open connection
  dir_create(path = path_dir(file_sql))
  conn <- dbConnect(RSQLite::SQLite(), dbname = file_sql, flags = RSQLite::SQLITE_RWC)

  # load Excel workbook
  sh <- excel_sheets(path = file_xls)
  s_sh <- sh[str_detect(string = sh, pattern = " ")]
  if (length(s_sh) != 0) stop(str_c("remove whitespace from worksheet: ", str_c("'", s_sh, "'", collapse = " and ")))
  if (!"Runs" %in% sh) stop(str_c("Excel database '", path_file(file_xls), "' should contain sheet 'Runs'"))

  # load sheet columns
  column <- suppressMessages(read_excel(path = file_xls, sheet = "Runs", range = cell_rows(1))) |>
    names()

  # loop over sheets and collect input variabes
  if (!quiet) pb <- progress_bar$new(total = length(sh) + 1, format = "create SQL-database: load sheet :percent (:what)", clear = TRUE)
  for (s_sh in sh) {

    # set progress
    if (!quiet) pb$tick(tokens = list(what = s_sh))

    # load sheet columns
    column <- suppressMessages(read_excel(path = file_xls, sheet = s_sh, range = cell_rows(1))) |>
      names()

    # check column run_id in sheet Runs
    if (s_sh == "Runs") {
      if (!"run_id" %in% column) stop(str_c("Column 'run_id' missing in sheet 'Runs'; check Excel database '", path_file(file_xls), "'"))
    }

    # set format for loading sheet
    n_clm <- length(column)
    col_types <- rep(x = "guess", times = n_clm)
    for (i_clm in 1:n_clm) {

      s_column <- column[i_clm]

      # strip possible depth indication
      t_column <- s_column
      if (str_detect(string = t_column, pattern = "\\[")) {
        t_column <- str_split(string = t_column, pattern = "\\[", simplify = TRUE)[, 1]
      }

      # delete column in if not SWAP variable or index-column
      if ((regexpr(pattern = "_id", text = s_column) < 0) && (!t_column %in% variable)) {
        col_types[i_clm] <- "skip"
      }

      # convert datetime to date
      if (s_column %in% variable) {
        format <- inp[[s_column]]$format
        if (format %in% c("float", "integer")) col_types[i_clm] <- "numeric"
        if (format == "date") col_types[i_clm] <- "date"
        if (format == "string") col_types[i_clm] <- "text"
      }
    }

    # load data sheet
    db <- suppressMessages(read_excel(path = file_xls, sheet = s_sh, col_types = col_types))

    # delete empty columns and check date format
    column <- names(db)
    for (s_column in column) {

      # delete column if all records are empty
      if (all(is.na(db[ , s_column]))) {
        db <- db[ , names(db)[names(db) != s_column]]
      }

      # convert datetime to date
      if (s_column %in% variable) {
        format <- inp[[s_column]]$format
        if (format == "date") db[, s_column] <- db |> pull(all_of(s_column)) |> as_date()
      }
    }

    # upload sheet
    if (ncol(db) != 0) {
      dbWriteTable(conn = conn, name = s_sh, value = db)

      # create index
      index <- names(db)[regexpr(pattern = "_id", text = names(db)) > 0]
      if (length(index) == 0) stop(str_c("upload sheet '", s_sh, "' failed!!!\nNo key variables specified"))
      statement <- str_c("CREATE INDEX swap_idx_", s_sh, " ON ", s_sh, " (", str_c(index, collapse = ", "), ")")
      dbExecute(conn = conn, statement = statement)
    }

    # end progress
    if (!quiet) {
      if (s_sh == sh[length(sh)]) pb$tick(tokens = list(what = s_sh))
    }
  }

  # close connection
  dbDisconnect(conn = conn)
}

#' Get run_id from SQL
#'
#' @param file_sql character string, name of sql-file.
#' @importFrom RSQLite dbConnect SQLite dbGetQuery dbDisconnect SQLITE_RO sqliteSetBusyHandler
#' @importFrom stringr str_c
#' @importFrom fs path_file
#' @export get_run_id_SQL
get_run_id_SQL <- function(file_sql) {

  # --- main part of procedure ---

  # open connection SQL
  conn <- dbConnect(RSQLite::SQLite(), dbname = file_sql, flags = RSQLite::SQLITE_RO)
  sqliteSetBusyHandler(dbObj = conn, handler = 500)

  # check for table 'Runs'
  table <- dbListTables(conn = conn)
  if (!"Runs" %in% table) stop(str_c("unable to extract run information\nTable 'Runs' not found in database ('", path_file(file_sql), "')"))

  # extract run information
  statement <- str_c("SELECT run_id FROM Runs")
  dat <- dbGetQuery(conn = conn, statement = statement)
  run_id <- sort(dat$run_id)

  # close connection SQL
  dbDisconnect(conn = conn)

  # --- return part of procedure ---

  return(run_id)
}

#' Get key_id from SQL
#'
#' @param file_sql character string, name of sql-file.
#' @importFrom RSQLite dbConnect SQLite dbGetQuery dbDisconnect SQLITE_RO sqliteSetBusyHandler
#' @importFrom stringr str_c str_which
#' @importFrom fs path_file
#' @export get_key_id_SQL
#' @keywords internal
get_key_id_SQL <- function(file_sql) {

  # --- main part of procedure ---

  # open connection SQL
  conn <- dbConnect(RSQLite::SQLite(), dbname = file_sql, flags = RSQLite::SQLITE_RO)
  sqliteSetBusyHandler(dbObj = conn, handler = 500)

  # check for table 'Runs'
  table <- dbListTables(conn = conn)
  if (!"Runs" %in% table) stop(str_c("unable to extract run information\nTable 'Runs' not found in database ('", path_file(file_sql), "')"))

  # extract column names
  clm <- dbListFields(conn = conn, name = "Runs")

  # close connection SQL
  dbDisconnect(conn = conn)

  # check column names
  key_id <- clm[str_which(string = clm, pattern = "_id$")]
  if (length(key_id) == 0) key_id <- NULL

  # --- return part of procedure ---

  return(key_id)
}

#' Filter run_id from SQL
#'
#' @param file_sql character string, name of sql-file.
#' @param filter list, optional list with names of key_id and filter settings.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs file_exists
#' @importFrom RSQLite dbConnect dbGetQuery dbDisconnect SQLITE_RO sqliteSetBusyHandler
#' @export filter_run_id_SQL
#' @description Filter run_id in sql-file based on filter settings.
#' @details
#' Filter settings can be provided by specifying a list \code{filter} or by arguments. The list and/or arguments should have names of key_id (see: \code{\link{get_key_id_SQL}}) and should contain settings to be extracted.
filter_run_id_SQL <- function(file_sql, filter = NULL, ...) {

  # --- initial part of procedure ---

  # load additional arguments
  param <- list(...)

  # add optional filter
  if (!is.null(filter)) param <- c(param, filter)

  # assign arguments
  if (length(param) == 0) stop("no additional arguments are specified")
  for (name in names(param)) assign(name, param[[name]])

  # --- main part of procedure ---

  if (!file_exists(path = file_sql)) stop(str_c("sql-file '", file_sql,"' does not exists"))

  # create statement
  statement <- "SELECT run_id FROM Runs"
  first <- TRUE
  for (name in names(param)) {

    if (first) {
      first <- FALSE
      statement <- str_c(statement, " WHERE ", name, " in ('", str_c(param[[name]], collapse = "','"), "')")
    } else {
      statement <- str_c(statement, " AND ", name, " in ('", str_c(param[[name]], collapse = "','"), "')")
    }
  }

  # select variants from wwl-database
  conn <- dbConnect(RSQLite::SQLite(), dbname = file_sql, flags = RSQLite::SQLITE_RO)
  sqliteSetBusyHandler(dbObj = conn, handler = 500)
  db_run <- dbGetQuery(conn = conn, statement = statement)
  dbDisconnect(conn = conn)

  # set run_id
  if (nrow(db_run) != 0) {
    run_id <- db_run$run_id
  } else {
    run_id <- NULL
  }

  # --- return of procedure ---

  return(run_id)
}

#' Get run_id from SQL based on information provided in controlfile.
#'
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_to_upper str_replace_all str_split
#' @importFrom readr read_lines
#' @importFrom controlR get_record string_sequence
#' @export get_run_id_CTRL
#' @description Get run_id in sql-file based on information provided in controlfile. An optional filter can be applied.
#' @details
#' Keywords \code{FILSQL} and \code{RUNID} should be specified in the controlfile (\code{file}). Optionally a filter can be applied specifying additional keywords with names of key_id (see: \code{\link{get_key_id_SQL}}; provided in uppercase) and the settings to be extracted.
get_run_id_CTRL <- function(...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("text", "file")
  for (name in opt_param) assign(name, NULL)

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(text) & is.null(file)) stop("either 'text' or 'file' should be specified")
  if (!is.null(text) & !is.null(file)) message("both 'text' and 'file' are specified, only 'text' is used")

  # --- main part of procedure ---

  # load controlfile
  if (is.null(text)) text <- read_lines(file = file, lazy = FALSE, num_threads = 1, progress = FALSE)

  # extract file_sql and run_id
  file_sql <- get_record(text = text, item = "FILSQL")
  run_id <- get_record(text = text, item = "RUNID")

  # set run_id (all possible options)
  if (run_id == "ALL") {
    run_id <- get_run_id_SQL(file_sql = file_sql)
  } else {
    run_id <- string_sequence(string = run_id)
  }

  # check if filter is provided
  key_id <- get_key_id_SQL(file_sql = file_sql)
  filter <- NULL
  for(s_key_id in key_id) {

    # extract settings
    record <- get_record(text = text, item = str_to_upper(string = s_key_id), item_exists = FALSE)

    # check settings
    if (!is.null(record)) {
      record <- str_replace_all(string = record, pattern = " |\t", replacement = "")
      record <- str_split(string = record, pattern = ",", simplify = TRUE)[1,]

      if (is.null(filter)) filter <- list()
      filter[[s_key_id]] <- record
    }
  }

  # apply filter
  if (!is.null(filter)) {
    filter_run_id <- filter_run_id_SQL(file_sql = file_sql, filter = filter)
    run_id <- run_id[run_id %in% filter_run_id]
  }

  # --- return of procedure ---

  if (length(run_id) == 0) run_id <- NULL
  return(run_id)
}

#' Extract swap-files from zip
#'
#' @param run_id vector, run id.
#' @param dir_run character string, directory to extract file.
#' @param dir_out character string, directory to extract file.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_replace
#' @importFrom fs file_exists
#' @importFrom controlR get_variable
#' @importFrom utils unzip
#' @export extract_run_id
extract_run_id <- function(run_id, dir_run, dir_out, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("run_info", "file_sql", "width")
  run_info <- file_sql <- width <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # --- main part of procedure ---

  # loop over run_id
  for (s_run_id in run_id) {

    # set run-directory
    dir_tmp <- set_dir_run_SQL(dir_run = dir_run, run_id = run_id, run_info = run_info, file_sql = file_sql, create = TRUE)

    # set zip-file
    file_zip <- str_c(dir_tmp, "/run_", str_run_id(run_id = s_run_id, width = width), ".zip")

    # extract all files if exists
    if (fs::file_exists(path = file_zip)) {
      unzip(zipfile = file_zip, overwrite = TRUE, exdir = str_c(dir_out, "/run_", str_run_id(run_id = s_run_id, width = width)))
    }
  }
}

#' Get run_info from SQL
#'
#' @param file_sql character string, name of sql-file.
#' @param run_id numeric, id of run.
#' @importFrom RSQLite dbConnect SQLite dbGetQuery dbDisconnect SQLITE_RO sqliteSetBusyHandler
#' @importFrom stringr str_c
#' @importFrom fs path_file
#' @export get_run_info_SQL
get_run_info_SQL <- function(file_sql, run_id) {

  # --- main part of procedure ---

  # open connection SQL
  conn <- dbConnect(RSQLite::SQLite(), dbname = file_sql, flags = RSQLite::SQLITE_RO)
  sqliteSetBusyHandler(dbObj = conn, handler = 500)

  # check for table 'Runs'
  table <- dbListTables(conn = conn)
  if (!"Runs" %in% table) stop(str_c("unable to extract run information\nTable 'Runs' not found in database ('", path_file(file_sql), "')"))
  field <- dbListFields(conn = conn, name = "Runs")

  # extract run information
  statement <- str_c("SELECT ", str_c(field, collapse = ","), " FROM Runs WHERE run_id in ('", run_id, "')")
  db <- dbGetQuery(conn = conn, statement = statement)

  # close connection SQL
  dbDisconnect(conn = conn)

  # check results query
  if (nrow(db) == 0) stop(str_c("no record found for run_id '", run_id, "'"))
  if (nrow(db) > 1) stop(str_c("multiple records found for run_id '", run_id, "'"))

  # store sql-file used
  run_info <- list()
  run_info[["modus"]] <- "SQL"
  run_info[["file_sql"]] <- file_sql

  # store run information
  key_id <- get_key_id_SQL(file_sql = file_sql)
  for (s_key_id in key_id) {
    if (!is.na(db[, s_key_id])) run_info[[s_key_id]] <- db[, s_key_id]
  }

  # --- return part of procedure ---

  return(run_info)
}

#' Get value of variable from SQL-database
#'
#' @param conn connection to sql-file.
#' @param run_info list, index of run_id.
#' @param variable character string, name of SWAP variable.
#' @param ... further arguments passed to or from other methods
#' @importFrom readr read_rds
#' @importFrom fs path_package
#' @importFrom stringr str_c str_split
#' @importFrom RSQLite dbListTables dbListFields dbGetQuery
#' @importFrom lubridate as_date
#' @keywords internal
#' @export get_record_SQL
get_record_SQL <- function(conn, run_info, variable, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("item_exists", "exclude_column")
  item_exists <- exclude_column <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(item_exists)) item_exists <- TRUE

  # extract list variable
  inp <- .swp_env$inp[[variable]]
  if (is.null(inp)) stop(str_c("unknown variable selected, check '", variable, "'"))

  # --- main part of procedure ---

  # check if multiple variables should be extracted
  var <- variable
  if (inp$format == "table") {
    if (inp$header) var <- inp$column
  }

  # extract names of tables
  table_SQL <- dbListTables(conn = conn)

  # search for table in SQL database
  value <- list(); value_sql <- NULL; tbl <- 0; done <- FALSE
  while (!done) {

    tbl <- tbl + 1

    # extract field from table
    field <- dbListFields(conn = conn, name = table_SQL[tbl])

    # check key_id
    key_id <- field[regexpr(pattern = "_id", text = field) > 0]
    if (all(key_id %in% names(run_info))) {

      # check if variable is present
      found <- FALSE
      if (inp$format == "table") {
        if (any(inp$column[!inp$column %in% inp$index] %in% field) && inp$index %in% field) {
          var_extract <- unique(c(inp$column[inp$column %in% field], inp$index))
          found <- TRUE
        }
      } else {
        if (inp$type == "scalar") {
          if (variable %in% field) {
            var_extract <- variable
            found <- TRUE
          }
        } else {
          if (variable %in% field && inp$index %in% field) {
            var_extract <- unique(c(variable, inp$index))
            found <- TRUE
          }
        }
      }

      # extract variable from table
      if (found) {
        where <- NULL
        for (i_rec in seq_along(key_id)) where <- c(where, str_c(key_id[i_rec], " in ('", run_info[[key_id[i_rec]]], "')"))
        statement <- str_c("SELECT ",str_c(var_extract, collapse = ","), " FROM ", table_SQL[tbl], " WHERE ", str_c(where, collapse = " AND "))
        value_sql <- dbGetQuery(conn = conn, statement = statement)
        if (nrow(value_sql) > 0) done <- TRUE
      }
    }

    # check if done
    if (!done & tbl >= length(table_SQL)) done <- TRUE

  }

  # adjust extracted value
  if (!is.null(value_sql)) {

    # table
    if (inp$format == "table") {

      # order or adjust format of variable if needed
      column <- inp$column[inp$column %in% var_extract]
      value_sql <- value_sql[order(value_sql[, inp$index], decreasing = inp$order == "decreasing"), column]
      for (s_var in column) {
        if (.swp_env$inp[[s_var]]$format == "date") value_sql[, s_var] <- as_date(x = value_sql[, s_var])
        value[[ifelse(!inp$header, str_c(variable, "::", s_var), s_var)]] <- value_sql[, s_var]
      }

    } else {

      if (inp$format == "date") value_sql[, variable] <- as_date(x = value_sql[, variable])
      if (inp$type == "vector") {
        value_sql[, variable] <- value_sql[order(value_sql[, inp$index], decreasing = inp$order == "decreasing"), variable]
      }
      value[[variable]] <- value_sql[, variable]
    }

    # exclude table column
    value <- value[!names(value) %in% exclude_column]
  }

  # check if all settings are found
  if (inp$format == "table") {
    if (inp$header) {
      check <- inp$column
    } else {
      check <- str_c(variable, "::", inp$column)
    }
    check <- check[!check %in% exclude_column]
  } else {
    check <- variable
  }
  if (!all(check %in% names(value)) && item_exists) stop(str_c("unable to find SWAP variable: '", str_c(check[!check %in% names(value)], collapse = "' '"), "'"))

  # --- return part of procedure ---

  return(value)
}

#' Set run-directory
#'
#' @param dir_run character string, path directory (containing optional key-id's).
#' @param ... further arguments passed to or from other methods
#' @importFrom fs dir_create
#' @importFrom stringr str_c str_replace
#' @importFrom controlR get_variable set_variable
#' @export set_dir_run_SQL
set_dir_run_SQL <- function(dir_run, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("run_info" ,"file_sql", "run_id", "create")
  run_info <- file_sql <- run_id <- create <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(create)) create <- FALSE

  # --- main part of procedure ---

  # extract
  key_id <- get_variable(text = dir_run, sign_open = SIGN_OPEN(), sign_close = SIGN_CLOSE())

  # set run-directory
  dir_tmp <- dir_run
  if (!is.null(key_id)) {
    if (is.null(run_info) && (is.null(file_sql) || is.null(run_id))) stop("either 'run_info' or 'file_sql' and 'run_id' should be specified")
    if (is.null(run_info)) run_info <- get_run_info_SQL(file_sql = file_sql, run_id = run_id)
    dir_tmp <- set_variable(text = dir_run, info = run_info)
  }

  if (create) dir_create(path = dir_tmp)

  # --- return part of procedure ---

  return(dir_tmp)
}


#' Set string run_id
#'
#' @param run_id vector, run id.
#' @param ... further arguments passed to or from other methods
#' @export str_run_id
str_run_id <- function(run_id, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("width")
  width <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(width)) width <- 9

  # --- main part of procedure ---

  # check if maximum width is not exceeded
  if (run_id > as.numeric(str_c("1e", width + 1))) stop("increase width (default 9)")

  # set string
  string <- formatC(x = run_id, format = "d", width = width, flag = "0")

  # --- return part of procedure ---

  return(string)
}
