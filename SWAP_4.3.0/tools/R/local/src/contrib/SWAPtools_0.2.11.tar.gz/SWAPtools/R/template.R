#' Get setting of SWAP-variable
#'
#' @param variable character string, name of SWAP variable.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_split str_split_i str_which str_trim str_replace_all str_detect
#' @importFrom fs path_package path_file
#' @importFrom readr read_rds read_lines
#' @importFrom controlR is_numeric is_date
#' @importFrom lubridate parse_date_time
#' @export get_record_SWAP
#' @examples
#' # specify swp-file
#' file_swp <- paste0(tempfile(pattern = "swap"), "/swap.swp")
#' zipfile <- system.file("extdata/input.zip", package = "SWAPtools")
#' unzip(zipfile = zipfile, files = basename(file_swp), exdir = dirname(file_swp))
#'
#' # extract name of project
#' get_record_SWAP(file = file_swp, variable = "PROJECT")
#'
#' # extract number of layers
#' max(get_record_SWAP(file = file_swp, variable = "ISOILLAY")$ISOILLAY)
#'
#' # extract saturated conductivity
#' get_record_SWAP(file = file_swp, variable = "OSAT")
#'
#' # clean example
#' unlink(x = dirname(file_swp), recursive = TRUE)
get_record_SWAP <- function(variable, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("text", "file", "item_exists", "case_sensitive", "exclude_column", "quiet")
  text <- file <- item_exists <- case_sensitive <- exclude_column <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param)) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(item_exists)) item_exists <- TRUE
  if (is.null(case_sensitive)) case_sensitive <- TRUE
  if (is.null(quiet)) quiet <- TRUE

  # extract list variable
  inp <- .swp_env$inp[[variable]]
  if (is.null(inp)) stop(str_c("unknown variable selected, check '", variable, "'"))

  if (is.null(text) & is.null(file)) stop("either 'text' or 'file' should be specified")
  if (!is.null(text) & !is.null(file)) message("both 'text' and 'file' are specified, only 'text' is used")

  # --- main part of procedure ---

  # load template
  if (is.null(text)) {
    if (!quiet) message(str_c("reading file: ", path_file(file)))
    text <- read_lines(file = file, lazy = FALSE, num_threads = 1, progress = FALSE)
    if (!case_sensitive) text <- toupper(text)
  }

  # remove comments
  text <- str_split(string = text, pattern = "[#\\*!]", simplify = TRUE)[, 1]

  # check if multiple variables should be extracted
  var <- variable
  if (inp$format == "table") {
    if (inp$header) var <- inp$column
  }

  # loop over variables
  value <- list()
  for (s_var in var) {

    # extract list variable
    s_inp <- .swp_env$inp[[s_var]]
    if (is.null(s_inp)) stop(str_c("unknown variable selected, check '", s_var, "'"))

    # set type in case of table format
    if (s_inp$format == "table") s_inp$type <- "vector"

    # get line with variable
    lns <- str_which(string = text, pattern = str_c(" ", s_var, " | ", s_var, "=|^", s_var, " |^", s_var, "=| ", s_var, "$"))

    # check if variable is available
    if (length(lns) == 0) {

      # if not, try to set default value
      if (!is.null(s_inp$default)) value[[s_var]] <- s_inp$default

    } else {

      # check if variable is defined only one time
      if (length(lns) > 1) stop(str_c("variable defined multiple times, check '", s_var, "'"))

      s_text <- str_trim(string = text[lns])

      # get setting in case of scalar variable
      if (s_inp$type == "scalar") {

        # get variable setting
        string <- str_trim(str_split(string = s_text, pattern = "=", simplify = TRUE)[, 2])

        # check undefined variable
        if (str_detect(string = string, pattern = SIGN_OPEN())) {
          stop(str_c("undefined variable found, check '", s_var, "'"))
        }

        # store settings
        value[[s_var]] <- string

      } else {

        # check if written as a horizontal vector
        string <- NULL
        if (str_detect(string = s_text, pattern = "=")) {

          orientation <- "horizontal"

          # check first line for values
          add_string <- str_trim(string = str_split(string = s_text, pattern = "=", simplify = TRUE)[, 2])
          if (add_string != "") {
            string <- str_split(string = add_string, pattern = " +| +,|,", simplify = TRUE)[1, ]
          }

        } else {

          orientation <- "vertical"

          # extract column names
          column <- str_split(string = s_text, pattern = " +| +,|,", simplify = TRUE) [1, ]

        }

        # determine end of vector
        lns <- lns + 1
        found <- FALSE
        while (!found) {

          # next line
          add_string <- str_split(string = str_trim(string = text[lns]), pattern = " +| +,|,", simplify = TRUE)[1, ]

          # check end of array
          if (!is_numeric(text = add_string[1]) && !is_date(text = add_string[1])) {
            found <- TRUE
          } else {
            string <- c(string, add_string)
            lns <- lns + 1
          }

          # check end of text
          if (lns > length(text)) found <- TRUE
        }

        # reconstruct table
        if (s_inp$format == "table") {

          n_val <- length(string)
          n_clm <- length(s_inp$column)
          n_row <- n_val / n_clm
          if (n_row %% 1 > 0) stop(str_c("Wrong number of values, check variable '", s_var, "'"))

          # store settings
          for(i_clm in 1:n_clm) {
            clm <- s_inp$column[i_clm]
            if (!s_inp$header) clm <- str_c(s_var, "::", clm)
            value[[clm]] <- string[seq(from = i_clm, to = n_val, by = n_clm)]
          }

        } else {

          if (orientation == "horizontal") {

            # store settings
            value[[s_var]] <- string

          } else {

            n_val <- length(string)
            n_clm <- length(column)
            n_row <- n_val / n_clm
            if (n_row %% 1 > 0) stop(str_c("Wrong number of values, check variable '", s_var, "'"))

            i_clm <- match(x = s_var, table = column)

            # store settings
            value[[s_var]] <- string[seq(from = i_clm, to = n_val, by = n_clm)]
          }
        }
      }
    }
  }

  # exclude table column
  value <- value[!names(value) %in% exclude_column]

  # check if all settings are found
  if (inp$format == "table") {
    if (inp$header) {
      check <- inp$column
    } else {
      check <- str_c(variable, "::", inp$column)
    }
    check <- check[!check %in% exclude_column]
  } else {
    check <- variable
  }
  if (!all(check %in% names(value)) && item_exists) stop(str_c("unable to find SWAP variable: '", str_c(check[!check %in% names(value)], collapse = "' '"), "'"))

  # loop over variable
  var <- names(value)
  for (s_var in var) {

    # extract list variable
    s_inp <- .swp_env$inp[[str_split_i(string = s_var, pattern = "::", i = -1)]]

    # convert format
    if (s_inp$format == "date") {

      if (!s_inp$unit %in% c("yyyy-mm-dd", "dd-mm")) stop("unknown date format, check variable '", s_var, "'")

      if (s_inp$unit == "yyyy-mm-dd") {
        if (!is_date(text = value[[s_var]][1])) stop(str_c("unknown date format found for variable '", s_var, "'"))
        value[[s_var]] <- as_date(parse_date_time(x = value[[s_var]], orders = c("ymd" , "dmy")))
      }

      if (s_inp$unit == "dd-mm") {
        splitvalue <- str_split(string = value[[s_var]], pattern = " +", simplify = TRUE)[,1:2]
        value[[s_var]] <- as_date(parse_date_time(x = str_c("2000-", splitvalue[2], "-", splitvalue[1]), orders = "ymd"))
      }

    }

    if (s_inp$format == "string") {
      value[[s_var]] <- str_replace_all(string = value[[s_var]], pattern = "'|\"", replacement = "")
    }

    if (s_inp$format %in% c("float", "integer", "switch")) {

      # check number of values specified
      if (s_inp$type == "scalar" & length(value[[s_var]]) > 1) {
        stop(str_c(s_inp$format, " '", s_var, "' is specified multiple times"))
      }

      # convert to numeric
      if (all(is_numeric(text = value[[s_var]]))) {
        value[[s_var]] <- as.numeric(value[[s_var]])
      } else {
        splitvalue <- str_split(string = value[[s_var]], pattern = "d|D", simplify = TRUE)[,1:2]
        value[[s_var]] <- as.numeric(splitvalue[1]) * 10^as.numeric(splitvalue[2])
      }
    }
  }

  # --- return of procedure ---

  return(value)
}

#' Get multiple settings of SWAP-variables
#'
#' @param variable character string, name of SWAP variable.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_split
#' @importFrom fs path_package path_file
#' @importFrom readr read_rds read_lines
#' @export get_records_SWAP
#' @examples
#' # specify swp-file
#' file_swp <- paste0(tempfile(pattern = "swap"), "/swap.swp")
#' zipfile <- system.file("extdata/input.zip", package = "SWAPtools")
#' unzip(zipfile = zipfile, files = basename(file_swp), exdir = dirname(file_swp))
#'
#' # extract name of project
#' get_records_SWAP(file = file_swp, variable = c("PROJECT", "OUTFIL"))
#'
#' # extract layer numbers
#' get_records_SWAP(file = file_swp, variable = "ISOILLAY")
#'
#' # extract saturated conductivity
#' get_records_SWAP(file = file_swp, variable = c("OSAT", "ORES"))
#'
#' # clean example
#' unlink(x = dirname(file_swp), recursive = TRUE)
get_records_SWAP <- function(variable, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("text", "file", "item_exists", "case_sensitive", "quiet")
  text <- file <- item_exists <- case_sensitive <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(text) & is.null(file)) stop("either 'text' or 'file' should be specified")
  if (!is.null(text) & !is.null(file)) message("both 'text' and 'file' are specified, only 'text' is used")
  if (is.null(item_exists)) item_exists <- FALSE
  if (is.null(case_sensitive)) case_sensitive <- TRUE
  if (is.null(quiet)) quiet <- TRUE

  # --- main part of procedure ---

  # load template
  if (is.null(text)) {
    if (!quiet) message(str_c("reading file: ", path_file(file)))
    text <- read_lines(file = file, lazy = FALSE, num_threads = 1, progress = FALSE)
    if (!case_sensitive) text <- toupper(text)
  }

  # save settings
  settings <- list()
  for (s_variable in variable) {

    # get type of swap-variable
    inp <- .swp_env$inp[[s_variable]]
    if (is.null(inp)) stop(str_c("unknown variable selected, check '", s_variable, "'"))

    # store settings
    value <- get_record_SWAP(text = text, variable = s_variable, item_exists = item_exists)
    if (length(value) != 0) settings <- c(settings, value)
  }

  # --- return of procedure ---

  return(settings)
}

#' Get undefined variable(s) from SWAP-template
#'
#' @param text vector of character strings, text of SWAP-template containing undefined variables.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_which str_replace str_locate str_sub
#' @keywords internal
#' @export get_variable_SWAP
get_variable_SWAP <- function(text, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("exclude")
  exclude <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # --- main part of procedure ---

  # select all variables
  lns <- str_which(string = text, pattern = SIGN_OPEN())

  variable  <- NULL
  for (s_lns in lns) {
    done <- FALSE
    while(!done) {

      # get start and position of variable
      start <- as.numeric(regexpr(pattern = SIGN_OPEN(), text = text[s_lns]))
      if (start == -1) done <- TRUE

      if (!done) {

        # get end position of variable
        pos <- regexpr(pattern = SIGN_CLOSE(), text = text[s_lns])
        end <- as.numeric(pos) + (attr(pos,"match.length") - 1)

        # add variable
        s_variable <- str_replace_all(string = str_sub(string = text[s_lns], start = start, end = end), pattern = str_c(SIGN_OPEN(), "|", SIGN_CLOSE()), replacement = "")
        variable <- c(variable, s_variable)

        # delete variable from text
        pattern <- str_c(SIGN_OPEN(), s_variable, SIGN_CLOSE())
        text[s_lns] <- str_replace(string = text[s_lns], pattern = pattern, replacement = "")
      }
    }
  }

  # filter switch variables
  done <- FALSE
  while (!done) {

    switch_option <- str_replace(string = variable[str_sub(string = variable, start = 1, end = 8) == "#SWITCH_"], pattern = "#SWITCH_", replacement = "")[1]
    if (is.na(switch_option)) done <- TRUE

    if (!done) {
      start <- str_which(string = variable, pattern = str_c("#SWITCH_", switch_option))[1]
      end <- str_which(string = variable, pattern = str_c("/SWITCH_", switch_option))[1]
      if (is.na(end)) stop(str_c("missing end of switch '", switch_option, "' in template!!!"))

      switch <- str_sub(string = switch_option, start = 1, end = str_locate(string = switch_option, pattern = "_OPTION_")[,"start"] - 1)
      if (switch %in% exclude) {
        variable <- variable[c(-start, -end)]
      } else {
        variable <- c(if (start != 1) variable[1:(start - 1)], if (end != length(variable)) variable[(end + 1):length(variable)])
      }
    }
  }

  # filter tables variables
  table <- str_replace(string = variable[str_sub(string = variable, start = 1, end = 7) == "#TABLE_"], pattern = "#TABLE_", replacement = "")
  for (s_table in table) {

    done <- FALSE
    while (!done) {
      start <- str_which(string = variable, pattern = str_c("#TABLE_", s_table))[1]
      if (is.na(start)) {
        done <- TRUE
      } else {
        end <- str_which(string = variable, pattern = str_c("/TABLE_", s_table))[1]
        if (is.na(end)) stop(str_c("missing end of table '", s_table, "' in template!!!"))
        if (s_table %in% exclude) {
          variable <- c(if (start != 1) variable[1:(start - 1)], if (end != length(variable)) variable[(end + 1):length(variable)])
        } else {
          variable <- c(if (start != 1) variable[1:(start - 1)], s_table, if (end != length(variable)) variable[(end + 1):length(variable)])
        }
      }
    }
  }

  # set unique variable
  variable <- unique(variable)

  # exclude variable
  if (!is.null(exclude)) variable <- variable[!variable %in% exclude]

  # --- return of procedure ---

  return(variable)
}

#' Check value of SWAP-variable
#'
#' @param value value of SWAP-variable.
#' @param variable character string, name of SWAP variable.
#' @importFrom stringr str_c str_split str_split_i str_pad
#' @importFrom fs path_package
#' @importFrom lubridate as_date
#' @importFrom readr read_rds
#' @importFrom controlR is_date
#' @keywords internal
check_record_SWAP <- function(value, variable) {

  # --- main part of procedure ---

  # extract variable
  inp <- .swp_env$inp[[variable]]
  if (is.null(inp)) stop(str_c("unknown variable selected, check '", variable, "'"))

  # check if multiple variables should be checked
  var <- variable
  if (inp$format == "table") {
    column <- inp$column
    if (!inp$header) column <- str_c(var, "::", column)
    var <- column[column %in% names(value)]
  }

  # loop over variables
  for (s_var in var) {

    # extract list variable
    inp <- .swp_env$inp[[str_split_i(string = s_var, pattern = "::", i = -1)]]
    if (is.null(inp)) stop(str_c("unknown variable selected, check '", s_var, "'"))

    # set type in case of table format
    if (inp$format == "table") inp$type <- "vector"

    # check multiple settings in case of scalar variable
    if (inp$type == "scalar" && length(value[[s_var]]) > 1) stop(str_c("multiple values found for variable '", variable, "'"))

    # check minimum or maximum date
    if (inp$format == "date") {

      if (inp$unit %in% c("yyyy-mm-dd", "dd-mm")) {

        if (!is_date(value[[s_var]][1])) {
          value_temp <- str_split(string = value[[s_var]], pattern = " +", simplify = TRUE)
          value <- str_c("2000-", str_pad(string = value_temp[[s_var]][2], width = 2, pad = "0"), "-", str_pad(string = value_temp[[s_var]][1], width = 2, pad = "0"))
        }
        value[[s_var]] <- as_date(value[[s_var]])

        if (!is.na(inp$start)) {
          if (!all(value[[s_var]] >= inp$start)) {
            stop(str_c("\n", s_var, ": date '", value[[s_var]][!is.na(value[[s_var]]) & value[[s_var]] < inp$start], "' exceeds lower boundary '", inp$start, "'"))
          }
        }

        if (!is.na(inp$end)) {
          if (!all(value[[s_var]] <= inp$end)) {
            stop(str_c("\n", s_var, ": date '", value[[s_var]][!is.na(value[[s_var]]) & value[[s_var]] > inp$end], "' exceeds upper boundary '", inp$end, "'"))
          }
        }

      } else stop("unknown date format, check SWAP-variables!")
    }

    # check minimum or maximum value
    if (inp$format %in% c("float", "integer")) {

      value[[s_var]] <- as.numeric(value[[s_var]])

      if (!is.na(inp$min)) {
        if (!all(value[[s_var]][!is.na(value[[s_var]])] >= inp$min)) {
          stop(str_c("\n", s_var, ": value '", unique(value[[s_var]][value[[s_var]] < inp$min]), "' exceeds lower boundary '", inp$min, "'"))
        }
      }

      if (!is.na(inp$max)) {
        if (!all(value[[s_var]][!is.na(value[[s_var]])] <= inp$max)) {
          stop(str_c("\n", s_var, ": value '", unique(value[[s_var]][value[[s_var]] > inp$max]), "' exceeds upper boundary '", inp$max, "'"))
        }
      }
    }

    # check options switch
    if (inp$format == "switch") {

      value[[s_var]] <- as.numeric(value[[s_var]])

      check <- as.numeric(inp$option)
      if (!all(value[[s_var]] %in% check)) {
        stop(str_c("\n", variable, ": wrong switch value: '", value[[s_var]][!value[[s_var]] %in% check], "'"))
      }
    }
  }

  # --- return of procedure ---

  return(value)
}

#' Set replacement of SWAP-variable to fill template
#'
#' @param value Value (numeric, date or character string) of SWAP-variable.
#' @param variable character string, name of SWAP variable.
#' @importFrom stringr str_c str_split str_split_i str_pad str_to_lower
#' @importFrom fs path_package
#' @importFrom lubridate day month
#' @importFrom readr read_rds
#' @importFrom controlR get_digits
#' @keywords internal
#' @export set_replacement_SWAP
set_replacement_SWAP <- function(value, variable) {

  # --- main part of procedure ---

  # extract variable
  inp <- .swp_env$inp[[variable]]
  if (is.null(inp)) stop(str_c("unknown variable selected, check '", variable, "'"))

  # check if multiple variables should be checked
  orientation <- "horizontal"
  var <- variable
  if (inp$format == "table") {
    column <- inp$column
    header <- inp$header
    if (!header) column <- str_c(var, "::", column)
    var <- column[column %in% names(value)]
    orientation <- "vertical"
  }

  # loop over variables
  text <- NULL
  for (s_var in var) {

    if (s_var %in% names(value)) {

      # extract list variable
      inp <- .swp_env$inp[[str_split_i(string = s_var, pattern = "::", i = -1)]]
      if (is.null(inp)) stop(str_c("unknown variable selected, check '", s_var, "'"))

      # set type in case of table format
      if (inp$format == "table") inp$type <- "vector"

      # set digits
      if (inp$format == "float") {
        digits <- 1
        digits <- max(digits, get_digits(value = value[[s_var]]))
      }

      # set string
      if (inp$format == "date") {
        if (inp$unit == "yyyy-mm-dd") string <- as.character(value[[s_var]])
        if (inp$unit == "dd-mm") string <- str_c(str_pad(string = day(value[[s_var]]), width = 2, pad = "0"), " ", str_pad(string = month(value[[s_var]]), width = 2, pad = "0"))
      }
      if (inp$format == "string")  string <- str_to_lower(string = formatC(x = str_c("'", value[[s_var]], "'"), format = "s"))
      if (inp$format == "switch")  string <- formatC(x = value[[s_var]], format = "d")
      if (inp$format == "float")   string <- formatC(x = value[[s_var]], format = "f", digits = digits)
      if (inp$format == "integer") string <- formatC(x = value[[s_var]], format = "d")

      # combine values of vector
      if (inp$type == "scalar") {

        text <- string

      } else {

        if (orientation == "horizontal") {

          text <- str_c(string, collapse = " ")

        } else {

          if (header) string = c(s_var, string)
          width <- max(nchar(string)) + 1
          string <- formatC(x = string, format = "s", width = width)
          string <- str_replace_all(string = string, pattern = str_c(formatC(x = " ", format = "s", width = width - 2), "NA"), replacement = formatC(x = "", format = "s", width = width))
          if (!is.null(text) && length(text) != length(string)) stop(str_c("mismatch size vector, check '", s_var, "'"))
          text <- str_c(text, string)
        }
      }
    }

  }

  # --- return of procedure ---

  return(text)
}

#' Set variable(s) in SWAP-template
#'
#' @param text vector of character strings, text of SWAP-template containing undefined variables.
#' @param variable character string, name of SWAP variable.
#' @param value numeric, date or string, value of variable.
#' @importFrom stringr str_c str_replace
#' @importFrom readr read_rds
#' @keywords internal
#' @export set_variable_SWAP
set_variable_SWAP <- function(text, variable, value) {

  # extract variable
  inp <- .swp_env$inp[[variable]]
  if (is.null(inp)) stop(str_c("unknown variable selected, check '", variable, "'"))

  # --- main part of procedure ---

  # set replacement
  value <- check_record_SWAP(value = value, variable = variable)
  replacement <- set_replacement_SWAP(value = value, variable = variable)

  # set index
  lns <- seq_along(text)

  # check if multiple variables should be checked
  if (!inp$format == "table") {

    # filter tables variables
    start <- str_which(string = text, pattern = "#TABLE_")
    if (length(start) > 0) {
      end <- str_which(string = text, pattern = "/TABLE_")
      for (tbl in 1:length(start)) {
        lns <- lns[!lns %in% seq(from = start[tbl], to = end[tbl], by = 1)]
      }
    }

    text[lns] <- str_replace(string = text[lns], pattern = str_c(SIGN_OPEN(), variable, SIGN_CLOSE()), replacement = replacement)

  } else {

    # set text
    start <- str_which(string = text, pattern = str_c(SIGN_OPEN(), "#TABLE_", variable, SIGN_CLOSE()))
    end <- str_which(string = text, pattern = str_c(SIGN_OPEN(), "/TABLE_", variable, SIGN_CLOSE()))
    text <- c(if (start != 1) text[1:start - 1], replacement, if (end != length(text)) text[(end + 1):length(text)])

  }

  # delete unused options
  if (inp$format == "switch") {

    option <- as.numeric(inp$option)

    # delete unused options
    for (s_option in option) {

      done <- FALSE
      while (!done) {

        # get lines of start switch
        start <- str_which(string = text, pattern = str_c(SIGN_OPEN(), "#SWITCH_", variable, "_OPTION_", s_option, SIGN_CLOSE()))[1]
        if (is.na(start[1])) done <- TRUE

        if (!done) {

          # get lines of end switch
          end <- str_which(string = text, pattern = str_c(SIGN_OPEN(), "/SWITCH_", variable, "_OPTION_", s_option, SIGN_CLOSE()))[1]
          if (is.na(end[1])) stop(str_c("unable to delete option: '", s_option, "' of SWITCH '", variable, "'"))

          # clean or delete option from template
          if (s_option == value) {

            # clean option
            text <- c(text[1:(start - 1)], text[(start + 1):(end - 1)],if (end != length(text)) text[(end + 1):length(text)])

          } else {

            # delete option
            text <- c(text[1:(start - 1)],if (end != length(text)) text[(end + 1):length(text)])
          }
        }
      }
    }
  }

  # --- return of procedure ---

  return(text)
}

#' Set SWAP-template
#'
#' @param template character string, name of SWAP-template.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_split_i str_sub str_replace_all str_to_upper
#' @importFrom fs path_package path_file
#' @importFrom readr read_rds read_lines
#' @importFrom tibble tibble
#' @importFrom dplyr mutate if_else pull
#' @importFrom rlang .data
#' @importFrom RSQLite dbConnect SQLite dbDisconnect SQLITE_RO sqliteSetBusyHandler
#' @details Set template of SWAP based on information from text-file \code{file} or based on information from a list \code{run_info}.
#' In case information is provided by list \code{run_info}, the list should also be provided with a path to an SQL-database (\code{file_sql}).
#' First attempt is to extract information from the list \code{run_info} directly. Second attempt is to extract information from either the \code{file} or else the SQL-database.
#' Variables that should remain undefined can be provided with \code{exclude}.
#' @keywords internal
#' @export set_template_SWAP
set_template_SWAP <- function(template, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("run_info", "file", "exclude", "case_sensitive", "quiet")
  run_info <- file <- exclude <- case_sensitive <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(case_sensitive)) case_sensitive <- TRUE
  if (is.null(quiet)) quiet <- TRUE

  # check arguments
  if (is.null(run_info) && is.null(file)) stop("either 'run_info' or 'file' should be specified")

  # --- main part of procedure ---

  # initialize connection
  fl_connect <- FALSE; fl_sqlite <- FALSE

  # load template
  if (!quiet) message(str_c("reading file: ", path_file(template)))
  text_tmplt <- read_lines(file = template, lazy = FALSE, num_threads = 1, progress = FALSE)

  # get variables
  variable <- get_variable_SWAP(text = text_tmplt, exclude = exclude)

  # loop over switches
  done <- ifelse(is.null(variable), TRUE, FALSE)
  while (!done) {

    done <- TRUE

    for (s_var in variable) {

      if (!quiet) message(str_c("setting variable : ", s_var))

      # extract variable
      inp <- .swp_env$inp[[s_var]]
      if (is.null(inp)) stop(str_c("unknown variable found in template '", s_var,"'"))

      # extract table column from template
      if (inp$format == "table") {
        start  <- str_which(string = text_tmplt, pattern = str_c(SIGN_OPEN(), "#TABLE_", s_var, SIGN_CLOSE())) + 1
        end <- str_which(string = text_tmplt, pattern = str_c(SIGN_OPEN(), "/TABLE_", s_var, SIGN_CLOSE())) - 1
        if (length(start) > 1 || length(end) > 1) stop(str_c("template contains variable '", s_var, "' more than once'"))
        table_column <- get_variable_SWAP(text = text_tmplt[start:end])
        if (!all(table_column %in% inp$column)) stop(str_c("unknown column ''", str_c(table_column[!table_column %in% inp$column], collapse = "' '"), "' found in table '", s_var, "'"))
        if (!inp$header) table_column <- str_c(s_var, "::", table_column)
      }

      # load settings from run_info (optional)
      value <- list(); found <- FALSE
      if (!is.null(run_info)) {
        if (inp$format != "table") {
          if (!is.null(run_info[[s_var]])) {
            value[[s_var]] <- run_info[[s_var]]
            found <- TRUE
          }
        } else {
          value <- c(value, run_info[names(run_info) %in% table_column])
          if (all(table_column %in% names(value))) found <- TRUE
        }
      }

      # extract settings from file or sql-database
      value_ext <- list()
      if (!found) {

        if (!is.null(file) && !is.null(run_info$file_sql)) stop("in case settings in 'run_info' are missing, specify 'file' or add path 'file_sql' in list 'run_info'")

        exclude_column <- NULL
        if (inp$format == "table") {
          exclude_column <- inp$column[!inp$column %in% str_split_i(string = table_column, pattern = "::", i = -1)]
          if (any(table_column %in% names(value))) exclude_column <- c(exclude_column, table_column[table_column %in% names(value)])
        }

        if (!is.null(file)) {

          # check connection
          if (!fl_connect) {
            text_file <- read_lines(file = file, lazy = FALSE, num_threads = 1, progress = FALSE) |>
              iconv(from = "UTF-8", to = "UTF-8", sub = "")
            if (!case_sensitive) text_file <- str_to_upper(string = text_file)
            fl_connect <- TRUE
          }

          # extract settings from external file
          value_ext <- get_record_SWAP(text = text_file, variable = s_var, case_sensitive = case_sensitive, exclude_column = exclude_column)

        } else {

          # check connection
          if (!fl_connect) {
            conn <- dbConnect(RSQLite::SQLite(), dbname = run_info$file_sql, flags = RSQLite::SQLITE_RO)
            sqliteSetBusyHandler(dbObj = conn, handler = 500)
            fl_connect <- TRUE; fl_sqlite <- TRUE
          }

          # extract settings from external sql-database
          value_ext <- get_record_SQL(conn = conn, run_info = run_info, variable = s_var, exclude_column = exclude_column)

        }
      }

      # combine settings
      value <- c(value, value_ext)

      # in case of variable
      text_tmplt <- set_variable_SWAP(text = text_tmplt, variable = s_var, value = value)
    }

    # update variables
    variable <- get_variable_SWAP(text = text_tmplt, exclude = exclude)
    done <- ifelse(is.null(variable), TRUE, FALSE)
  }

  # adjust comment to minimum of 30
  text_tmplt <- tibble(string = str_replace_all(string = text_tmplt, pattern = " +!", replacement = " !")) |>
    mutate(
      pos = regexpr(text = .data$string, pattern = "!"),
      add_pos = as.integer(30 - .data$pos),
      start = if_else(.data$pos > 1 & .data$pos < 30, str_sub(string = .data$string, start = 1, end = .data$pos - 1), .data$string),
      add = if_else(.data$pos > 1 & .data$pos < 30, str_sub(string = "                              ", start = 1, end = .data$add_pos), ""),
      end = if_else(.data$pos > 1 & .data$pos < 30, str_c("!", str_sub(string = .data$string, start = .data$pos + 1, end = nchar(.data$string))), ""),
      string_new = str_c(.data$start, .data$add, .data$end)
    ) |>
    pull("string_new")

  # --- return of procedure ---

  # close connection
  if (fl_sqlite) dbDisconnect(conn = conn)

  return(text_tmplt)
}
