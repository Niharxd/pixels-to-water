#' Create SWAP-model using sqlite-database
#'
#' @param file_swp character string, name of swp-file (to create).
#' @param file_sql character string, name of sql-file.
#' @param run_id numeric, id of run (sql-datebase \code{file_sql}).
#' @param tmplt_swp character string, name of swp-template.
#' @param dir_met character string, directory with meteo-file(s).
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_replace
#' @importFrom fs path_dir file_copy file_exists path_file path_ext
#' @importFrom readr write_lines read_rds
#' @importFrom lubridate year
#' @export create_SWAP
create_SWAP <- function(file_swp, file_sql, run_id, tmplt_swp, dir_met, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("dir_ini", "dir_smu", "dir_crp", "dir_atm", "dir_irg", "dir_dra", "dir_bbc", "tmplt_irg", "tmplt_dra", "tmplt_bbc", "run_info", "exclude", "width", "quiet")
  dir_ini <- dir_smu <- dir_crp <- dir_atm <- dir_irg <- dir_dra <- dir_bbc <- tmplt_irg <- tmplt_dra <- tmplt_bbc <- run_info <- exclude <- width <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(dir_atm)) dir_atm <- dir_met
  if (is.null(quiet)) quiet <- TRUE

  # --- main part of procedure ---

  # set run information
  if (is.null(run_info)) run_info <- get_run_info_SQL(file_sql = file_sql, run_id = run_id)

  # create run-directory
  dir_run <- path_dir(file_swp)
  dir_tmp <- set_dir_run_SQL(dir_run = dir_run, run_info = run_info, create = TRUE)

  # create swp-file
  text_swp <- set_template_SWAP(template = tmplt_swp, run_info = run_info, exclude = exclude, quiet = quiet)
  file_swp <- set_ext_SWAP(file = file_swp, text = text_swp)
  if (!quiet) message(str_c("writing file: ", path_file(file_swp)))
  write_lines(x = text_swp, file = str_c(dir_tmp, "/", path_file(file_swp)), num_threads = 1)

  # extract settings
  var_swp <- c("SWINCO", "INIFIL", "SWSOPHY", "FILENAMESOPHY", "SWCROP", "CROPFIL", "SWIRFIX", "SWIRGFIL", "IRGFIL", "SWDRA", "DRFIL", "SWBBCFILE", "BBCFIL", "TSTART", "TEND", "METFIL", "SWRAIN", "RAINFIL", "CROPFIL", "CROPTYPE")
  settings <- get_records_SWAP(text = text_swp, variable = var_swp, item_exists = FALSE)

  # copy ini-file
  if (settings$SWINCO == 3) {
    if (is.null(dir_ini) && is.null(run_info$ini_run_id)) stop("in case of initialisation is based on previous simulation, either 'dir_ini' should be specified or 'ini_run_id' in 'run_info' should be present")
    if (!is.null(dir_ini)) {
      path <- str_c(dir_ini, "/", settings$INIFIL)
      new_path <- str_c(dir_tmp, "/", tolower(settings$INIFIL))
      if (!quiet) message(str_c("copy file: '", path_file(path), "' to '", path_file(new_path),"'"))
      file_copy(path = path, new_path = new_path, overwrite = TRUE)
    } else {
      ini_info <- get_run_info_SQL(file_sql = file_sql, run_id = run_info$ini_run_id)
      dir_ini <- str_replace(string = set_dir_run_SQL(dir_run = dir_run, run_info = ini_info), pattern = str_run_id(run_id = run_id, width = width), replacement = str_run_id(run_id = run_info$ini_run_id, width = width))
      file_zip <- str_c(dir_ini, ".zip")
      if (file_exists(path = file_zip)) {
        list_zip <- unzip(zipfile = file_zip, list = TRUE)$Name
        file_ini <- list_zip[str_detect(string = list_zip, pattern = ".swp")]
        unzip(zipfile = file_zip, files = file_ini, overwrite = TRUE, exdir = str_c(dir_tmp, "/ini"))
        OUTFIL <- get_record_SWAP(file = str_c(dir_tmp, "/ini/", file_ini), variable = "OUTFIL")
        unzip(zipfile = file_zip, files = str_c(OUTFIL$OUTFIL, ".end"), overwrite = TRUE, exdir = str_c(dir_tmp, "/ini"))
        path <- str_c(dir_tmp, "/ini/", OUTFIL, ".end")
      } else {
        file_ini <- str_c(dir_ini, "/", path_file(file_swp))
        OUTFIL <- get_record_SWAP(file = file_ini, variable = "OUTFIL")
        path <- str_c(path_dir(path = file_ini), OUTFIL$OUTFIL, ".end")
      }
      new_path <- str_c(dir_tmp, "/", tolower(settings$INIFIL))
      if (!quiet) message(str_c("copy file: '", path_file(path), "' to '", path_file(new_path),"'"))
      file_copy(path = path, new_path = new_path, overwrite = TRUE)
    }
  }

  # copy smu-file(s)
  if (settings$SWSOPHY == 1) {
    if (is.null(dir_smu)) stop("in case of soil physical tables, 'dir_smu' should be specified")
    path <- str_c(dir_smu, "/", settings$FILENAMESOPHY)
    new_path <- str_c(dir_tmp, "/", tolower(settings$FILENAMESOPHY))
    if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'\n"))
    file_copy(path = path, new_path = new_path, overwrite = TRUE)
  }

  # create crp-file(s) (optional)
  if (settings$SWCROP == 1) {
    if (is.null(dir_crp)) stop("in case of crop growth, 'dir_crp' should be specified")
    cropfil <- unique(settings$CROPFIL)
    for (s_cropfil in cropfil) {
      text_crp <- set_template_SWAP(template = str_c(dir_crp, "/", s_cropfil, ".crp"), run_info = run_info, exclude = exclude, quiet = quiet)
      file_crp <- set_ext_SWAP(file = str_c(dir_tmp, "/", s_cropfil, ".crp"), text = text_crp)
      if (!quiet) message(str_c("writing file: ", path_file(file_crp)))
      write_lines(x = text_crp, file = file_crp, num_threads = 1)
    }
  }

  # create irg-file (optional)
  if (settings$SWIRFIX == 1) {
    if (settings$SWIRGFIL == 1) {
      if (is.null(tmplt_irg) && is.null(dir_irg)) stop("in case of fixed irrigation, 'tmplt_irg' should be specified")
      if (!is.null(dir_irg)) tmplt_irg <- str_c(dir_irg, "/", settings$IRGFIL, ".irg")
      text <- set_template_SWAP(template = tmplt_irg, run_info = run_info, exclude = exclude, quiet = quiet)
      file_irg <- set_ext_SWAP(file = str_c(dir_tmp, "/", tolower(settings$IRGFIL), ".irg"), text = text)
      if (!quiet) message(str_c("writing file: ", path_file(file_irg)))
      write_lines(x = text, file = file_irg, num_threads = 1)
    }
  }

  # create dra-file (optional)
  if (settings$SWDRA %in% 1:2) {
    if (is.null(tmplt_dra) && is.null(dir_dra)) stop("in case of lateral drainage to surface water, 'tmplt_dra' or 'dir_dra' should be specified")
    if (!is.null(dir_dra)) tmplt_dra <- str_c(dir_dra, "/", settings$DRFIL, ".dra")
    text <- set_template_SWAP(template = tmplt_dra, run_info = run_info, exclude = exclude, quiet = quiet)
    file_dra <- set_ext_SWAP(file = str_c(dir_tmp, "/", tolower(settings$DRFIL), ".dra"), text = text)
    if (!quiet) message(str_c("writing file: ", path_file(file_dra)))
    write_lines(x = text, file = file_dra, num_threads = 1)
  }

  # create bbc-file (optional)
  if (settings$SWBBCFILE == 1) {
    if (is.null(tmplt_bbc) && is.null(dir_bbc)) stop("in case bottom boundary is specified in separate file, 'tmplt_bbc' or 'dir_bbc' should be specified")
    if (!is.null(dir_dra)) tmplt_bbc <- str_c(dir_bbc, "/", settings$BBCFIL, ".bbc")
    text <- set_template_SWAP(template = tmplt_bbc, run_info = run_info, exclude = exclude, quiet = quiet)
    file_bbc <- set_ext_SWAP(file = str_c(dir_tmp, "/", tolower(settings$BBCFIL), ".bbc"), text = text)
    if (!quiet) message(str_c("writing file: ", path_file(file_bbc)))
    write_lines(x = text, file = file_bbc, num_threads = 1)
  }

  # copy meteorology
  file_met <- settings$METFIL
  if (tolower(path_ext(file_met)) != "met") {
    file_met <- str_c(file_met, ".", str_pad(string = year(settings$TSTART):year(settings$TEND) %% 1000, width = 3, pad = "0"))
  }
  path <- str_c(dir_met, "/", file_met)
  new_path <- str_c(dir_tmp, "/", tolower(file_met))
  if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'", collapse = "\n"))
  file_copy(path = path, new_path = new_path, overwrite = TRUE)

  # copy rain
  if (!is.null(settings$SWRAIN)) {
    if (settings$SWRAIN == 3) {
      file_rain <- settings$RAINFIL
      if (tolower(path_ext(file_rain)) != "rain") {
        file_rain <- str_c(file_rain, ".", str_pad(string = year(settings$TSTART):year(settings$TEND) %% 1000, width = 3, pad = "0"))
      }
      path <- str_c(dir_met, "/", file_rain)
      new_path <- str_c(dir_tmp, "/", tolower(file_rain))
      if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'", collapse = "\n"))
      file_copy(path = path, new_path = new_path, overwrite = TRUE)
    }
  }

  # copy atm-file(s)
  if (settings$SWCROP == 1) {
    cropfil <- unique(settings$CROPFIL[settings$CROPTYPE %in% 2:3])
    for (s_cropfil in cropfil) {
      file_crp <- set_ext_SWAP(file = str_c(dir_tmp, "/", s_cropfil, ".crp"), text = text_crp)
      var_crp <- c("SWCO2", "ATMOFIL")
      settings_crp <- get_records_SWAP(file = file_crp, variable = var_crp, item_exists = FALSE)
      if (settings_crp$SWCO2 == 1) {
        path <- str_c(dir_atm, "/", settings_crp$ATMOFIL, ".co2")
        new_path <- str_c(dir_tmp, "/", tolower(settings_crp$ATMOFIL), ".co2")
        if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'"))
        file_copy(path = path, new_path = new_path, overwrite = TRUE)
      }
    }
  }
}

#' Run SWAP-model
#'
#' @param file_swp character string, name of swp-file.
#' @param command character string, name of SWAP-program.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_dir file_copy file_exists path_file
#' @importFrom controlR is_windows
#' @export run_SWAP
run_SWAP <- function(file_swp, command, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("stop", "run_info", "file_sql", "run_id" , "quiet")
  stop <- run_info <- file_sql <- run_id <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(stop)) stop <- TRUE
  if (is.null(quiet)) quiet <- TRUE

  # set start of program
  timprg_start <- Sys.time()

  # set work-directory
  dir_wrk <- getwd()

  # --- main part of procedure ---

  # set run-directory
  dir_run <- set_dir_run_SQL(dir_run = path_dir(file_swp), run_info = run_info, file_sql = file_sql, run_id = run_id)

  # copy exe SWAP
  path <- command
  new_path <- str_c(dir_run, "/", path_file(command))
  if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'"))
  file_copy(path = path, new_path = new_path, overwrite = TRUE)

  # run SWAP
  setwd(dir_run)
  if (is_windows()) {
    system2(command = path_file(command), args = path_file(file_swp), stdout = FALSE)
  } else {
    Sys.chmod(path_file(command), mode = "0777")
    system2(command = str_c("./", path_file(command)), args = path_file(file_swp), stdout = FALSE)
  }
  setwd(dir_wrk)

  # check if SWAP was successfully ended
  if (!file_exists(str_c(dir_run, "/swap.ok"))) {
    if (stop) {
      stop("!!! SWAP crashed !!!")
    } else {
      message("!!! SWAP crashed !!!")
    }
  } else {
    if (!quiet) {
      timprg_end <- Sys.time()
      timprg_clc <- as.numeric(difftime(time1 = timprg_end, time2 = timprg_start, units = "secs"))
      message(str_c("SWAP successfully ended in ", floor(timprg_clc / 60), " minutes and ", ceiling(timprg_clc %% 60), " seconds"))
    }
  }
}

#' Zip SWAP-model results
#'
#' @param file_swp character string, name of swp-file.
#' @param ... further arguments passed to or from other methods
#' @importFrom utils zip
#' @importFrom stringr str_c
#' @importFrom fs path_dir file_exists dir_ls path_file path_ext_set
#' @export zip_SWAP
#' @details
#' Use \code{glob} to filter files if needed.
#' In case OS does not recognizes 'zip' a path to zip-command can be specified using \code{command}. If specified the command will be copied to the run-directory and deleted afterwards.
zip_SWAP <- function(file_swp, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("glob", "command", "run_info", "file_sql", "run_id", "quiet")
  glob <- command <- run_info <- file_sql <- run_id <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(quiet)) quiet <- TRUE

  # --- main part of procedure ---

  # set run-directory
  dir_run <- set_dir_run_SQL(dir_run = path_dir(file_swp), run_info = run_info, file_sql = file_sql, run_id = run_id)

  # set run-directory and zip-file
  clean_dir <- FALSE
  if (str_detect(string = path_file(dir_run), pattern = "^run_")) {
    clean_dir <- TRUE
    file_zip <- str_c(dir_run, ".zip")
  } else {
    file_zip <- path_ext_set(path = str_c(dir_run, "/", path_file(file_swp)), ext = ".zip")
  }

  if (file_exists(str_c(dir_run, "/swap.ok"))) {

    # copy exe ZIP (user)
    user_zip <- ifelse(is.null(command), FALSE, TRUE)
    if (user_zip) {
      path <- command
      new_path <- str_c(dir_run, "/", path_file(command))
      if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'"))
      file_copy(path = path, new_path = new_path, overwrite = TRUE)
      command <- str_c(dir_run, "/", path_file(command))
    } else {
      command <- Sys.getenv("R_ZIPCMD", "zip")
      if (command == "") command <- "zip"
    }

    # set pattern based on OUTFIL if needed
    file_swp <- str_c(dir_run, "/", path_file(file_swp))
    if (is.null(glob)) {
      OUTFIL <- get_record_SWAP(file = file_swp, variable = "OUTFIL")
      glob <- str_c("*", OUTFIL, "*")
    }

    FILES  <- dir_ls(path = dir_run, glob = glob)
    zip(zipfile = file_zip, files = FILES, flags = "-9Xqj", zip = command)

    # clean directory
    if (user_zip) {
      return <- unlink(x = command, force = TRUE)
      if (return != 0) {
        Sys.sleep(time = 1)
        return <- unlink(x = dir_run, recursive = TRUE, force = TRUE)
        if (return != 0) warning(str_c("unable to remove '", path_file(dir_run), "'"))
      }
    }
    if (clean_dir) {
      return <- unlink(x = dir_run, recursive = TRUE, force = TRUE)
      if (return != 0) {
        Sys.sleep(time = 1)
        return <- unlink(x = dir_run, recursive = TRUE, force = TRUE)
        if (return != 0) warning(str_c("unable to remove '", path_file(dir_run), "'"))
      }
    }

  }
}

#' Copy SWAP-model
#'
#' @param file_swp character string, name of swp-file.
#' @param dir_run character string, run-directory to copy \code{file_swp} to.
#' @param quiet logical.
#' @importFrom fs path_dir file_copy path_file path_ext
#' @importFrom stringr str_pad
#' @importFrom lubridate year
#' @export copy_SWAP
copy_SWAP <- function(file_swp, dir_run, quiet = FALSE) {

  # --- initial part of procedure ---

  # set directory
  dir_wrk <- getwd()

  # --- main part of procedure ---

  # extract inp-directory
  dir_inp <- path_dir(file_swp)

  # create run-directory
  dir_create(path = dir_run)

  # copy swp-file
  path <- str_c(file_swp)
  new_path <- str_c(dir_run, "/", path_file(file_swp))
  if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'", collapse = "\n"))
  file_copy(path = path, new_path = new_path, overwrite = TRUE)

  # extract settings
  var_swp <- c("SWINCO", "INIFIL", "SWSOPHY", "FILENAMESOPHY", "SWCROP", "CROPFIL", "SWIRFIX", "SWIRGFIL", "IRGFIL", "SWDRA", "DRFIL", "SWBBCFILE", "BBCFIL", "TSTART", "TEND", "METFIL", "SWRAIN", "RAINFIL", "CROPFIL", "CROPTYPE")
  settings <- get_records_SWAP(file = file_swp, variable = var_swp, item_exists = FALSE)


  # copy ini-file
  if (settings$SWINCO == 3) {
    path <- str_c(dir_inp, "/", settings$INIFIL)
    new_path <- str_c(dir_run, "/", settings$INIFIL)
    if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'"))
    file_copy(path = path, new_path = new_path, overwrite = TRUE)
  }

  # copy smu-file(s)
  if (settings$SWSOPHY == 1) {
    path <- str_c(dir_inp, "/", settings$FILENAMESOPHY)
    new_path <- str_c(dir_run, "/", settings$FILENAMESOPHY)
    if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'"))
    file_copy(path = path, new_path = new_path, overwrite = TRUE)
  }

  # copy crp-file(s)
  if (settings$SWCROP == 1) {
    path <- str_c(dir_inp, "/", settings$CROPFIL, ".crp")
    new_path <- str_c(dir_run, "/", settings$CROPFIL, ".crp")
    if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'"))
    file_copy(path = path, new_path = new_path, overwrite = TRUE)
  }

  # copy meteorology
  file_met <- settings$METFIL
  if (tolower(path_ext(file_met)) != "met") {
    file_met <- str_c(file_met, ".", str_pad(string = year(settings$TSTART):year(settings$TEND) %% 1000, width = 3, pad = "0"))
  }
  path <- str_c(dir_inp, "/", file_met)
  new_path <- str_c(dir_run, "/", file_met)
  if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'", collapse = "\n"))
  file_copy(path = path, new_path = new_path, overwrite = TRUE)

  # copy rain
  if (settings$SWRAIN == 3) {
    file_rain <- settings$RAINFIL
    if (tolower(path_ext(file_rain)) != "rain") {
      file_rain <- str_c(file_rain, ".", str_pad(string = year(settings$TSTART):year(settings$TEND) %% 1000, width = 3, pad = "0"))
    }
    path <- str_c(dir_inp, "/", file_rain)
    new_path <- str_c(dir_run, "/", file_rain)
    if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'", collapse = "\n"))
    file_copy(path = path, new_path = new_path, overwrite = TRUE)
  }

  # copy atm-file(s)
  cropfil  <- unique(settings$CROPFIL[settings$CROPTYPE %in% 2:3])
  for (s_cropfil in cropfil) {
    file_crp <- str_c(dir_run, "/", s_cropfil, ".crp")
    var_crp <- c("SWCO2", "ATMOFIL")
    settings_crp <- get_records_SWAP(file = file_crp, variable = var_crp, item_exists = FALSE)
    if (settings_crp$SWCO2 == 1) {
      path <- str_c(dir_inp, "/", settings_crp$ATMOFIL, ".co2")
      new_path <- str_c(dir_run, "/", settings_crp$ATMOFIL, ".co2")
      if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'", collapse = "\n"))
      file_copy(path = path, new_path = new_path, overwrite = TRUE)
    }
  }

  # copy dra-file (optional)
  if (settings$SWDRA %in% 1:2) {
    path <- str_c(dir_inp, "/", settings$DRFIL, ".dra")
    new_path <- str_c(dir_run, "/", settings$DRFIL, ".dra")
    if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'", collapse = "\n"))
    file_copy(path = path, new_path = new_path, overwrite = TRUE)
  }

  # copy bbc-file (optional)
  if (settings$SWBBCFILE == 1) {
    path <- str_c(dir_inp, "/", settings$BBCFIL, ".bbc")
    new_path <- str_c(dir_run, "/", settings$BBCFIL, ".bbc")
    if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'", collapse = "\n"))
    file_copy(path = path, new_path = new_path, overwrite = TRUE)
  }

  # copy irg-file (optional)
  if (settings$SWIRFIX == 1) {
    if (settings$SWIRGFIL == 1) {
      path <- str_c(dir_inp, "/", settings$IRGFIL, ".irg")
      new_path <- str_c(dir_run, "/", settings$IRGFIL, ".irg")
      if (!quiet) message(str_c("copy file: '", path_file(path), "' to '",path_file(new_path),"'", collapse = "\n"))
      file_copy(path = path, new_path = new_path, overwrite = TRUE)
    }
  }
}

#' Set extension of swap-file
#'
#' @param file character string, name of swp-file.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_ext_set
#' @importFrom readr read_lines
#' @export set_ext_SWAP
#' @keywords internal
#' @details
#' Change extension of swap-file to '.tmplt' if variables exists that still need to be specified.
set_ext_SWAP <- function(file, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("text")
  text <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # --- main part of procedure ---

  # load swap-file
  if (is.null(text)) text <- read_lines(file = file, lazy = FALSE, num_threads = 1, progress = FALSE)

  # change extent to .tmplt if variables exists that still need to be specified
  variable <- get_variable_SWAP(text = text)
  if (length(variable) > 0) {
    file <- path_ext_set(path = file, ext = "tmplt")
  }

  # --- return of procedure ---

  return(file)

}

