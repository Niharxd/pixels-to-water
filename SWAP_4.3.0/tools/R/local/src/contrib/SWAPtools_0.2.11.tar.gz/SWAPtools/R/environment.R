#' Internal environment of SWAPtools
#'
#' This environment is used to store meta-information of SWAP variables.
#'
#' @importFrom stringr str_c
#' @importFrom fs path_package
#' @importFrom readr read_rds
#' @keywords internal
.swp_env <- NULL

.onLoad <- function(libname, pkgname) {
  .swp_env <<- new.env(parent = emptyenv())
  .swp_env$inp <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_input.rds"))
  .swp_env$out <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_output.rds"))
  .swp_env$shortlist <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_shortlist.rds"))
  .swp_env$replace <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_rename.rds"))
  .swp_env$digits <- 2
  .swp_env$sign_open <- "\\{\\{"
  .swp_env$sign_close <- "\\}\\}"
}

#' Detect if SWAP variable contains TZ-info
#'
#' @param variable character string of SWAP variable.
#' @importFrom stringr str_detect
#' @keywords internal
#' @export detect_tz_info
#' @examples
#' # detect if TZ-info is available
#'
#' variable <- "H[-20.0;-30.0]"
#' detect_tz_info(variable)
#'
#' variable <- "WC[2023-01-01;2023-01-02]"
#' detect_tz_info(variable)
#'
#' variable <- "H"
#' detect_tz_info(variable)
detect_tz_info <- function(variable) {

  # --- main part of procedure ---

  # detect depth information
  detect <- str_detect(string = variable, pattern = "\\[|\\]")

  # --- return of procedure ---

  return(detect)
}

#' Delete TZ-info from SWAP variable
#'
#' @param variable character string of SWAP variable.
#' @importFrom stringr str_which str_locate str_sub
#' @keywords internal
#' @export delete_tz_info
#' @examples
#' # delete TZ-info from SWAP variable
#'
#' variable <- "H[-20.0;-30.0]"
#' delete_tz_info(variable)
#'
#' variable <- "WC[2023-01-01;2023-01-02]"
#' delete_tz_info(variable)
delete_tz_info <- function(variable) {

  # --- main part of procedure ---

  # delete depth information
  #for (rec in str_which(string = variable, pattern = "\\[")) {
  #  done <- FALSE
  #  while (!done) {
  #    start <- str_locate(string = variable[rec], pattern = "\\[")[, "start"]
  #    if (!is.na(start)) {
  #      end <- str_locate(string = variable[rec], pattern = "\\]")[, "start"]
  #      variable[rec] <- str_c(str_sub(string = variable[rec], start = 1, end = start - 1), ifelse(end == nchar(variable[rec]), "", str_sub(string = variable[rec], start = end + 1, end = nchar(variable[rec]))))
  #    } else {
  #      done <- TRUE
  #    }
  #  }
  #}

  # delete tz-info information
  if (detect_tz_info(variable = variable)) {
    start <- str_locate(string = variable, pattern = "\\[")[, "start"]
    end <- str_locate(string = variable, pattern = "\\]")[, "start"]
    variable <- str_sub(string = variable, start = 1, end = start - 1)
  }

  # --- return of procedure ---

  return(variable)
}

#' Extract TZ-info from SWAP variable
#'
#' @param variable character string of SWAP variable.
#' @importFrom stringr str_which str_locate_all str_squish str_sub
#' @keywords internal
#' @export get_tz_info
#' @examples
#' # return TZ-info from SWAP variable
#'
#' variable <- "H[-20.0;-30.0]"
#' get_tz_info(variable)
#'
#' variable <- "WC[2023-01-01;2023-01-02]"
#' get_tz_info(variable)
get_tz_info <- function(variable) {

  # --- main part of procedure ---

  #tz_info <- rep(x = NA_character_, times = length(variable))
  #
  ## get tz information
  #for (i_rec in str_which(string = variable, pattern = "\\[")) {
  #  locate <- str_locate_all(string = variable[i_rec], pattern = "\\[|\\]")[[1]][,"start"]
  #  tz_info[i_rec] <- str_squish(string = str_sub(string = variable[i_rec], start = locate[1] + 1, end = locate[2] - 1))
  #}

  tz_info <- NULL

  # get tz information
  if (detect_tz_info(variable = variable)) {
    locate <- str_locate_all(string = variable, pattern = "\\[|\\]")[[1]][,"start"]
    tz_info <- str_squish(string = str_sub(string = variable, start = locate[1] + 1, end = locate[2] - 1))
    tz_info <- str_squish(string = str_split(string = tz_info, pattern = ";", simplify = TRUE)[1,])
  }

  # --- return of procedure ---

  return(tz_info)
}

#' Adjust TZ-info from SWAP variable
#'
#' @param variable vector character string of SWAP variable.
#' @importFrom stringr str_c
#' @importFrom dplyr filter pull slice_head slice_tail
#' @importFrom rlang .data
#' @importFrom controlR is_numeric
#' @keywords internal
#' @export adjust_tz_info
adjust_tz_info <- function(variable) {

  # --- main part of the procedure ---

  new_var <- NULL
  for (i_rec in seq_along(variable)) {

    # extract tz-info
    name <- delete_tz_info(variable = variable[i_rec])
    info <- get_tz_info(variable = variable[i_rec])

    # check if scalar or vector data
    if (is.null(.swp_env$out[[name]]$quantity)) {

      if (!name %in% names(.swp_env$shortlist$alias)) stop(str_c("unknown quantity for variable '", name, "'"))

      add_var <- name

    } else {

      if (.swp_env$out[[name]]$quantity == "scalar") {

        add_var <- name

      } else {

        # extract discretization from swp-file
        db_cmp <- DISCR()

        # in case only vector is given
        if (is.null(info)) {
          if (!all(TZ_Z1_Z2() == 0.0)) db_cmp <- db_cmp |> filter(.data$bottom < TZ_Z1_Z2()[1], .data$top > TZ_Z1_Z2()[2])
          if (.swp_env$out[[name]]$type_tz_info == "center") {
            info <- formatC(x = db_cmp |> pull("depth"), format = "f", digits = DIGITS())
          } else {
            if (.swp_env$out[[name]]$type_tz_info != "top") stop(str_c("unknown type of TZ_INFO specified for variable '", name, "'"))
            info <- formatC(x = c(db_cmp |> pull("top"), db_cmp |> slice_tail(n = 1) |> pull("bottom")), format = "f", digits = DIGITS())
          }
          add_var <- str_c(name, "[", info, "]")

        } else {

          # check depth
          if (all(is_numeric(info))) {

            # check depth
            info <- as.numeric(info)

            # loop over records
            db_cmp <- db_cmp |> mutate(select = 0)
            for (i_inf in seq_along(info)) {

              # adjust depth info
              if (info[i_inf] <= 0) {
                db_cmp <- db_cmp |> mutate(select = if_else(.data$bottom < info[i_inf] & .data$top >= info[i_inf], 1, .data$select))
              } else {
                db_cmp <- db_cmp |> mutate(select = if_else(.data$node >= info[i_inf] & lag(x = .data$node, default = 0) < info[i_inf], 1, .data$select))
              }
            }

            if (.swp_env$out[[name]]$type_tz_info == "center") {
              info <- formatC(x = db_cmp |> filter(.data$select == 1) |> pull("depth"), format = "f", digits = DIGITS())
            } else {
              if (.swp_env$out[[name]]$type_tz_info != "top") stop(str_c("unknown type of TZ_INFO specified for variable '", name, "'"))
              info <- formatC(x = c(db_cmp |> filter(.data$select == 1) |> slice_head(n = 1) |> pull("top"), db_cmp |> filter(.data$select == 1) |> slice_tail(n = 1) |> pull("bottom")), format = "f", digits = DIGITS())
            }
            add_var <- str_c(name, "[", info, "]")

          } else {

            # check depth-range
            if (any(str_detect(string = info, pattern = ":"))) {
              if (length(info) >= 2) warning("multiple depth TZ-info not yet implemented, only first depth is used!")
              info <- str_split(string = info[1], pattern = ":", simplify = TRUE)[1,]
              if (all(is_numeric(info))) {

                range <- as.numeric(info)

                # adjust range settings (in case of subregion)
                if (all(range <= 0)) {
                  db_cmp <- db_cmp |> filter(.data$bottom < range[1], .data$top > range[2])
                } else {
                  db_cmp <- db_cmp |> filter(.data$node <= range[2], .data$node >= range[1])
                }
                if (.swp_env$out[[name]]$type_tz_info == "top_bottom") {
                  info <- str_c(formatC(x = c(db_cmp |> slice_head(n = 1) |> pull("top"), db_cmp |> slice_tail(n = 1) |> pull("bottom")), format = "f", digits = DIGITS()), collapse = ":")
                  add_var <- str_c(name, "[", info, "]")
                } else {
                  if (.swp_env$out[[name]]$type_tz_info == "center") {
                    info <- formatC(x = db_cmp |> pull("depth"), format = "f", digits = DIGITS())
                  } else {
                    if (.swp_env$out[[name]]$type_tz_info != "top") stop(str_c("unknown type of TZ_INFO specified for variable '", name, "'"))
                    info <- formatC(x = c(db_cmp |> pull("top"), db_cmp |> slice_tail(n = 1)|> pull("bottom")), format = "f", digits = DIGITS())
                  }
                  add_var <- str_c(name, "[", info, "]")
                }
              }
            }
          }
        }
      }
    }
    new_var <- c(new_var, add_var)
  }

  # --- return of procedure ---

  return(new_var)
}

#' Store general information from SWAP simulation
#'
#' @param file_swp character string, name of swp-file.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_split str_squish str_locate_all str_subset str_detect str_c str_to_upper
#' @importFrom lubridate as_datetime
#' @importFrom tibble tibble
#' @importFrom dplyr mutate select filter if_else lag
#' @importFrom rlang .data env_has env_bind
#' @importFrom controlR is_numeric is_windows
#' @keywords internal
bind_swap_settings <- function(file_swp, ...) {

  # check if environment already contains general information
  if (env_has(.swp_env, "OUTFIL")) return (FALSE)

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- "quiet"
  quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param) > 0) stop(str_c("unused parameter: ", str_c(unused_param, collapse = ', ')))

  # check used arguments
  if (is.null(quiet)) quiet <- TRUE

  # --- main part of procedure ---

  # extract settings from SWAP simulation
  variable <- c("TSTART", "TEND", "OUTFIL", "SWCSV", "INLIST_CSV", "NPRINTDAY", "TZ_Z1_Z2", "SWDISCRVERT", "DZNEW", "ISOILLAY", "HSUBLAY", "NCOMP", "OSAT", "ORES", "ALFA", "NPAR", "SWCROP", "CROPSTART", "CROPEND", "CROPFIL", "CROPTYPE")
  settings <- get_records_SWAP(file = file_swp, variable = variable, case_sensitive = !is_windows(), quiet = quiet)

  if (settings$SWCSV != 1) stop("no csv-output generated; use SWCSV = 1")

  # fill environment
  mssg <- env_bind(.swp_env, TSTART = as_datetime(settings$TSTART), TEND = as_datetime(settings$TEND + 1),
                   NPRINTDAY = settings$NPRINTDAY, OUTFIL = settings$OUTFIL, TZ_Z1_Z2 = settings$TZ_Z1_Z2)

  # -- reconstruct discretization --

  db_discr <- NULL
  for (i_rec in seq_along(settings$HSUBLAY)) {
    db_tmp <- tibble(layer = rep(x = settings$ISOILLAY[i_rec], times = settings$NCOMP[i_rec]), hcomp = rep(x = settings$HSUBLAY[i_rec] / settings$NCOMP[i_rec], times = settings$NCOMP[i_rec]))
    db_discr <- rbind(db_discr, db_tmp)
  }
  db_discr <- db_discr |>
    mutate(
      node = seq_along(.data$layer),
      bottom = -cumsum(.data$hcomp)
    )

  # set top and bottom of each compartment
  if (settings$SWDISCRVERT == 0) {

    db_discr <- db_discr |>
      mutate(
        top = lag(.data$bottom, default = 0),
        depth = (0.5 * .data$top + 0.5 * .data$bottom)
      ) |>
      select("layer", "node", "top", "bottom", "depth")

  } else {

    db_discr <- tibble(
      bottom = -cumsum(settings$DZNEW),
      top = lag(.data$bottom, default = 0),
      depth = (0.5 * .data$top + 0.5 * .data$bottom),
      layer = db_discr$layer[match(x = .data$bottom, table = db_discr$bottom)],
      node = db_discr$node[match(x = .data$bottom, table = db_discr$bottom)]
    ) |>
      select("layer", "node", "top", "bottom", "depth")

  }

  # fill environment
  mssg <- env_bind(.swp_env, DISCR = db_discr)

  # -- MvG param --

  db_mvg <- tibble(layer = seq_along(settings$OSAT), OSAT = settings$OSAT, ORES = settings$ORES, ALFA = settings$ALFA, NPAR = settings$NPAR)

  # fill environment
  mssg <- env_bind(.swp_env, MVG = db_mvg)

  # -- crop rotation --

  db_croprotation <- NULL
  db_dmrest <- NULL
  if (settings$SWCROP == 1) {
    db_croprotation <- tibble(i_crp = seq_along(settings$CROPSTART), CROPSTART = as_datetime(settings$CROPSTART), CROPEND = as_datetime(settings$CROPEND + 1), CROPFIL = settings$CROPFIL, CROPTYPE = settings$CROPTYPE)

    var_crp <- c("SWWOFOST", "DMRESTMOW", "DMRESTGRZ", "DMRESTDEW")
    CROPFIL <- db_croprotation$CROPFIL |> unique()
    for (s_CROPFIL in CROPFIL) {
      file_crp <- str_c(path_dir(path = file_swp), "/", str_to_lower(s_CROPFIL), ".crp")
      if (!all(fs::file_exists(path = file_crp))) stop(str_c("file '", path_file(path = file_crp), "' does not exists!"))
      settings_crp <- get_records_SWAP(file = file_crp, variable = var_crp, case_sensitive = !is_windows(), quiet = quiet)

      # default
      settings_crp$SWWOFOST <- ifelse(is.null(settings_crp$SWWOFOST), -99, settings_crp$SWWOFOST)
      settings_crp$DMRESTMOW <- ifelse(is.null(settings_crp$DMRESTMOW), 9999.0, settings_crp$DMRESTMOW)
      settings_crp$DMRESTGRZ <- ifelse(is.null(settings_crp$DMRESTGRZ), 9999.0, settings_crp$DMRESTGRZ)
      settings_crp$DMRESTDEW <- ifelse(is.null(settings_crp$DMRESTDEW), 9999.0, settings_crp$DMRESTDEW)
      #
      db_tmp <- tibble(CROPFIL = s_CROPFIL, SWWOFOST = settings_crp$SWWOFOST, DMRESTMOW = settings_crp$DMRESTMOW, DMRESTGRZ = settings_crp$DMRESTGRZ, DMRESTDEW = settings_crp$DMRESTDEW) |>
        mutate(DMREST = if_else(.data$SWWOFOST == 3, min(.data$DMRESTMOW, .data$DMRESTGRZ, .data$DMRESTDEW), 0.0)) |>
        select("CROPFIL", "SWWOFOST", "DMREST")

      db_dmrest <- rbind(db_dmrest, db_tmp)
    }
  }

  # fill environment
  mssg <- env_bind(.swp_env, CROPROTATION = db_croprotation, DMREST = db_dmrest)

  # -- reconstruct inlist --

  inlist <- str_to_upper(str_squish(string = str_split(string = settings$INLIST_CSV, pattern = ",", simplify = TRUE)[1,]))

  # - replace multiple depth by single depth -

  for (string in str_subset(string = inlist, pattern = ";")) {
    name <- delete_tz_info(variable = string)
    info <- get_tz_info(variable = string)
    inlist <- c(inlist, str_c(name, "[", info, "]"))
  }
  inlist <- inlist[!str_detect(string = inlist, pattern = ";")]

  # - adjust tz-info -

  inlist <- adjust_tz_info(inlist)

  # - replace alias -

  # check usage alias
  inlist_alias <- NULL
  for (i_rec in seq_along(inlist)) {
    if (delete_tz_info(inlist[i_rec]) %in% names(.swp_env$shortlist$alias)) inlist_alias <- c(inlist_alias, inlist[i_rec])
  }

  if (length(inlist_alias) > 0) {

    # get dependency settings
    var_swp <- var_dra <- var_bbc <- var_crp <- NULL
    for (variable in .swp_env$shortlist$filter$dependency) {
      if (.swp_env$inp[[variable]]$extension == "swp") var_swp <- c(var_swp, variable)
      if (.swp_env$inp[[variable]]$extension == "dra") var_dra <- c(var_dra, variable)
      if (.swp_env$inp[[variable]]$extension == "bbc") var_bbc <- c(var_bbc, variable)
      if (.swp_env$inp[[variable]]$extension == "crp") var_crp <- c(var_crp, variable)
    }

    # extract settings from swp-file
    var_swp <- unique(c(var_swp, "SWCROP", "SWDRA", "DRFIL", "SWBBCFILE", "BBCFIL", "SWBOTB", "CROPFIL"))
    filter <- get_records_SWAP(file = file_swp, variable = var_swp, case_sensitive = !is_windows(), item_exists = FALSE, quiet = quiet)

    # bottom boundary conditions
    if (filter$SWBBCFILE != 0) {
      file_bbc <- str_c(path_dir(file_swp), "/", str_to_lower(filter$BBCFIL), ".bbc")
      if (!fs::file_exists(path = file_bbc)) stop("file '", path_file(file_bbc), "' does not exists!")
      filter <- c(filter, get_record_SWAP(file = file_bbc, variable = var_bbc))
    }

    # drainage conditions
    if (filter$SWDRA > 0) {
      file_dra <- str_c(path_dir(path = file_swp), "/", filter$DRFIL, ".dra")
      if (!fs::file_exists(path = file_dra)) stop("file '", path_file(file_dra), "' does not exists!")
      filter <- c(filter, get_records_SWAP(file = file_dra, variable = var_dra, case_sensitive = !is_windows(), item_exists = FALSE, quiet = quiet))
    }

    # crop settings
    if (filter$SWCROP == 1) {
      CROPFIL <- db_croprotation$CROPFIL |> unique()
      for (s_CROPFIL in CROPFIL) {
        file_crp <- str_c(path_dir(path = file_swp), "/", str_to_lower(s_CROPFIL), ".crp")
        if (!all(fs::file_exists(path = file_crp))) stop(str_c("file '", path_file(path = file_crp), "' does not exists!"))
        filter_crp <- get_records_SWAP(file = file_crp, variable = var_crp, case_sensitive = !is_windows(), item_exists = FALSE, quiet = quiet)
        for (var in var_crp) {
          if (!is.null(filter_crp[[var]])) {
            if (!is.null(filter_crp[[var]])) {
              filter[[var]] <- filter_crp[[var]]
            } else {
              filter[[var]] <- c(filter[[var]], filter_crp[[var]])
            }
          }
        }
      }
    }

    # assign variables
    for (name in names(filter)) assign(x = name, value = filter[[name]])

    # exclude variables from shortlist
    exclude <- NULL
    for (i_eval in 1:.swp_env$shortlist$filter$n_eval) {
      if (all(.swp_env$shortlist$filter[[str_c("eval_", i_eval)]]$dependency %in% names(filter))) {
        expression <- .swp_env$shortlist$filter[[str_c("eval_", i_eval)]]$expression
        if (eval(parse(text = expression))) exclude <- c(exclude, .swp_env$shortlist$filter[[str_c("eval_", i_eval)]]$exclude)
      }
    }

    # replace all alias
    for (alias in inlist_alias) {

      # variables to add
      add_var <- .swp_env$shortlist$alias[[delete_tz_info(alias)]]
      if (!is.null(exclude)) add_var <- add_var[!add_var %in% exclude]

      # replace alias
      inlist <- inlist[!inlist %in% alias]
      info <- get_tz_info(alias)
      inlist <- unique(c(inlist, str_c(add_var, ifelse(is.null(info), "", str_c("[", info, "]")))))

    }

  }

  # fill environment
  mssg <- env_bind(.swp_env, INLIST = inlist)

  # --- return of procedure ---

  return (TRUE)

}

#' Clear general information from SWAP simulation
#'
#' @importFrom rlang env_has env_unbind
#' @keywords internal
unbind_swap_settings <- function() {

  # check if environment already contains general information
  if (!env_has(.swp_env, "OUTFIL")) return()

  # --- main part of procedure ---

  # reset environment with general info
  env_unbind(
    env = .swp_env,
    nms = c("TSTART", "TEND", "NPRINTDAY", "OUTFIL", "TZ_Z1_Z2", "INLIST", "DISCR", "MVG", "CROPROTATION", "DMREST")
  )

}

#' Return number of digits
#'
#' @keywords internal
DIGITS <- function() {
  return(.swp_env$digits)
}

#' Return 'sign_open'
#'
#' @keywords internal
SIGN_OPEN <- function() {
  return(.swp_env$sign_open)
}

#' Return 'sign_close'
#'
#' @keywords internal
SIGN_CLOSE <- function() {
  return(.swp_env$sign_close)
}

#' Return 'TSTART'
#'
#' @keywords internal
TSTART <- function() {
  return(.swp_env$TSTART)
}

#' Return 'TEND'
#'
#' @keywords internal
TEND <- function() {
  return(.swp_env$TEND)
}

#' Return 'NPRINTDAY'
#'
#' @keywords internal
NPRINTDAY <- function() {
  return(.swp_env$NPRINTDAY)
}

#' Return 'OUTFIL'
#'
#' @keywords internal
OUTFIL <- function() {
  return(.swp_env$OUTFIL)
}

#' Return 'TZ_Z1_Z2'
#'
#' @keywords internal
TZ_Z1_Z2 <- function() {
  return(.swp_env$TZ_Z1_Z2)
}

#' Return 'INLIST'
#'
#' @keywords internal
INLIST <- function() {
  return(.swp_env$INLIST)
}

#' Return 'DISCR'
#'
#' @keywords internal
DISCR <- function() {
  return(.swp_env$DISCR)
}

#' Return 'Mualem - Van Genuchten parameters'
#'
#' @keywords internal
MVG <- function() {
  return(.swp_env$MVG)
}

#' Return croprotation
#'
#' @keywords internal
CROPROTATION <- function() {
  return(.swp_env$CROPROTATION)
}

#' Return harvest settings
#'
#' @keywords internal
DMREST <- function() {
  return(.swp_env$DMREST)
}
