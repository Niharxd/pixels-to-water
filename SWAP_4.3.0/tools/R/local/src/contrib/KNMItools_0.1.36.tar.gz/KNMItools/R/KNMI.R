#' Get meteo stations from \href{https://www.knmi.nl/home}{KNMI}
#'
#' @param ... further arguments passed to or from other methods
#' @importFrom dplyr filter
#' @importFrom rlang .data
#' @details A tibble with all KNMI-stations.
#' By default all automatic weather stations are returned (\code{type} = 'weather'). For stations with daily precipitation, specify \code{type} = 'precipitation'.
#' A selection of stations can be made, either by name using \code{station_name} or by number \code{station_id}.
#' @export get_station_KNMI
get_station_KNMI <- function(...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("station_name", "station_id", "type", "error", "quiet")
  station_name <- station_id <- type <- error <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(type)) type <- "weather"
  if (is.null(error)) error <- TRUE
  if (is.null(quiet)) quiet <- TRUE

  # --- main part of procedure ---

  # check filter
  if (!type %in% c("weather", "precipitation")) stop("'type' should be 'weather' or 'precipitation'")
  if (!is.null(station_name) && !is.null(station_id)) stop("filter should be based either on 'station_name' or 'station_id', not both")

  # filter type station
  db_stn <- .knmi_env$knmi_stations |>
    filter(.data$TYPE == type)

  # filter based on name of station
  if (!is.null(station_name)) {

    station_name <- str_to_upper(string = station_name)

    # check selection
    if (!all(station_name %in% db_stn$STATION_NAME)) {
      mssg <- str_c("unknown station(s) selected: \n", str_c("'", station_name[!station_name %in% db_stn$STATION_NAME], "'", collapse = " "))
      if (error) stop(mssg)
      if (!quiet) warning(mssg)
    }

    db_stn <- db_stn |>
      filter(.data$STATION_NAME %in% station_name)
  }

  # filter based on id of station
  if (!is.null(station_id)) {

    # check selection
    if (!all(station_id %in% db_stn$STATION_ID)) {
      mssg <- str_c("unknown station(s) selected: \n", str_c("'", station_id[!station_id %in% db_stn$STATION_ID], "'", collapse = " "))
      if (error) stop(mssg)
      if (!quiet) warning(mssg)
    }

    db_stn <- db_stn |>
      filter(.data$STATION_ID %in% station_id)
  }

  # --- return of procedure ---

  return(db_stn)
}

#' Download observations from \href{https://www.knmi.nl/home}{KNMI} meteo station
#'
#' @param dir_out character string, name of directory
#' @param station character string, name(s) of meteo stations
#' @param variable character string, name(s) of observed variables
#' @param tstart date, start of period
#' @param tend date, end of period
#' @param ... further arguments passed to or from other methods
#' @importFrom utils unzip
#' @importFrom stringr str_c str_to_upper str_pad
#' @importFrom fs dir_create dir_delete file_temp
#' @importFrom readr read_csv write_csv
#' @importFrom rlang :=
#' @importFrom dplyr left_join mutate rename select filter if_else all_of
#' @importFrom tibble as_tibble tibble
#' @importFrom curl new_handle handle_setform
#' @importFrom lubridate as_date
#' @importFrom controlR download_data is_date
#' @details Download of meteorological data (KNMI).
#' Missing data can be replaced by specifying alternative stations with the option \code{replace}.
#' The sequence of the alternative stations specified determines the order of replacing missing values.
#' As default daily data is downloaded, optionally hourly data can be downloaded using \code{topt} = 'hour'.
#' @export download_meteo_KNMI
#' @examples
#' # download meteo from KNMI (do not run!)
#' #download_meteo_KNMI(dir_out = "../temp_knmi",
#' # station = "de Bilt", variable = "RH", tstart = "1980-01-01", tend = "1980-12-31")
download_meteo_KNMI <- function(dir_out, station, variable, tstart, tend, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- c("topt", "replace", "opt_variable")
  for (name in opt_param) assign(name, NULL)

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(topt)) topt <- "day"

  # --- main part of procedure ---

  # check topt
  if (!topt %in% c("day", "hour")) stop("'topt' should either be 'day' or 'hour'")

  # set url
  url_base <- "https://www.daggegevens.knmi.nl/klimatologie"
  url <- str_c(url_base, ifelse(topt == "day", "/daggegevens", "/uurgegevens"))

  # check date
  if (!is_date(tstart)) stop("unknown format for 'tstart', use 'YYYY-MM-DD'")
  if (!is_date(tend)) stop("unknown format for 'tend', use 'YYYY-MM-DD'")
  tstart <- as_date(tstart)
  tend <- as_date(tend)

  # check selected stations
  station <- str_to_upper(string = station)
  if (!is.null(replace)) replace <- str_to_upper(string = replace)
  station_KNMI <- get_station_KNMI(station_name = c(station, replace))

  # check selected variables
  variable <- unique(str_to_upper(variable))
  option <- .knmi_env$knmi_variable[[str_c("opt_", topt)]]
  if (!all(variable %in% option)) {
    stop(str_c("unknown variable selected: '", str_c(variable[!variable %in% option], collapse = "' '"), "'"))
  }

  # create empty data frame
  if (topt == "day") {
    db_empty <- tibble(date = seq(from = tstart, to = tend, by = 1), time = "00:00:00")
  } else {
    db_empty <- as_tibble(expand.grid(time = str_c(str_pad(string = 0:23, width = 2, pad = "0"),":00:00"), date = seq(from = tstart, to = tend, by = 1)))
  }

  # create directory
  dir_tmp <- str_c(file_temp(),"/meteo")
  dir_create(path = dir_tmp)

  # limit download to a maximum number of records
  mx_year <- ifelse(topt == "day", 50, 5)
  n_year <- (year(tend) - year(tstart) + 1)
  n_period <- ceiling(n_year / mx_year)

  # loop over queries
  db_all <- NULL

  # loop over periods
  for (i_per in 1:n_period) {

    # set temporary period
    tstart_tmp <- max(tstart, as_date(str_c(year(tstart) + (i_per - 1) * mx_year, "-01-01")))
    tend_tmp <- min(tend, as_date(str_c(year(tstart) + (i_per) * mx_year - 1, "-12-31"))) - ifelse(topt == "day", 0, 1)

    # set date_id
    start <- str_c(format(x = tstart_tmp, "%Y%m%d"), ifelse(topt == "hour", "01", ""))
    end <- str_c(format(x = tend_tmp, "%Y%m%d"), ifelse(topt == "hour", "24", ""))

    # loop over stations
    for (i_stn in seq_along(station_KNMI$STATION_NAME)) {

      stns <- station_KNMI$STATION_ID[i_stn]

      # download data from KNMI
      handle <- new_handle()
      handle_setform(handle, stns = stns, vars = str_c(variable, collapse = ":"), start = start, end = end)
      file_tmp <- str_c(dir_tmp, "/KNMI_", format(Sys.time(), "%Y%m%d%H%M%S"), ".txt")
      download_data(file = file_tmp, url = url, handle = handle, min_size = 100)

      # load data
      if (topt == "day") {
        col_names <- c("stn_id", "YYYYMMDD", variable)
        col_types <- str_c("cc", str_c(rep(x = "d", times = length(variable)), collapse = ""))
      } else {
        col_names <- c("stn_id", "YYYYMMDD", "HH", variable)
        col_types <- str_c("cci", str_c(rep(x = "d", times = length(variable)), collapse = ""))
      }
      db_tmp <- read_csv(file = file_tmp, col_names = col_names, col_types = col_types, comment = "#", progress = FALSE, lazy = FALSE, skip = 4)
      db_all <- rbind(db_all, db_tmp)
    }
  }

  # add date information
  if (!"HH" %in% names(db_all)) db_all <- db_all |> mutate(HH = 1)
  db_all <- db_all |> mutate(
      date = as_date(.data$YYYYMMDD),
      time = str_c(str_pad(string = .data$HH - 1, width = 2, pad = 0), ":00:00")
    ) |>
  select("date", "time", "stn_id", all_of(variable))

  # loop over variable
  for (var in variable) {

    # apply expression
    expression <- .knmi_env$knmi_variable[[var]]$expression
    if (!is.null(expression)) {
      db_all <- db_all |> mutate(!!var := !!parse_expr(expression))
    }

    # apply factor
    factor <- .knmi_env$knmi_variable[[var]]$factor
    if (!is.null(factor)) {
      db_all[, var] <- db_all[, var] * factor
    }
  }

  # set data for replacement
  db_alt <- NULL
  if (!is.null(replace)) {
    first <- TRUE
    for (s_replace in replace) {
      stn <- station_KNMI |> filter(.data$STATION_NAME == s_replace) |> pull("STATION_ID")
      db_alt <- db_empty |> mutate(stn_id = stn)
      db_alt <- left_join(x = db_alt, y = db_all[db_all$stn_id == stn, ], by = join_by("date", "time", "stn_id")) |>
        select("date", "time", "stn_id", all_of(variable))
      if (first) {
        first <- FALSE
        db_stn <- db_alt
      } else {
        db_stn <- replace_missing_data(db_stn = db_stn, db_alt = db_alt, quiet = TRUE)
      }
    }
    db_alt <- db_stn
  }

  # set period
  start <- str_c(format(x = tstart, "%Y%m%d"), ifelse(topt == "hour", "01", ""))
  end <- str_c(format(x = tend, "%Y%m%d"), ifelse(topt == "hour", "24", ""))

  # loop over stations
  for (s_station in station) {

    # create data with all available observations
    stn <- station_KNMI |> filter(.data$STATION_NAME == s_station) |> pull("STATION_ID")
    db_stn <- db_empty |> mutate(stn_id = stn)
    db_stn <- left_join(x = db_stn, y = db_all[db_all$stn_id == stn, ], by = join_by("date", "time", "stn_id")) |>
      select("date", "time", "stn_id", all_of(variable))

    # check missing values
    db_stn <- replace_missing_data(db_stn = db_stn, db_alt = db_alt, quiet = FALSE)

    # write file
    dir_create(dir_out)
    file <- str_c(dir_out, "/KNMI_", stn, "_", start, "-", end, ".csv")
    write_csv(x = db_stn, file = file, progress = FALSE, quote = "none", num_threads = 1)
  }

  # clean directory
  dir_delete(path = dir_tmp)
}

#' Download observations from \href{https://www.knmi.nl/home}{KNMI} precipitation station
#'
#' @param dir_out character string, name of directory
#' @param station character string, name(s) of precipitation stations
#' @param tstart date, start of period
#' @param tend date, end of period
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_pad str_to_upper str_sub
#' @importFrom fs dir_create dir_delete
#' @importFrom readr read_csv write_csv
#' @importFrom curl new_handle handle_setform
#' @importFrom dplyr left_join mutate rename select filter if_else pull
#' @importFrom rlang .data
#' @importFrom lubridate as_date
#' @importFrom controlR download_data is_date
#' @export download_precipitation_KNMI
#' @examples
#' # download precipitation from KNMI (do not run!)
#' #download_precipitation_KNMI(dir_out = "../temp_knmi",
#' # station = "de-Bilt", tstart = "1980-01-01", tend = "1980-12-31")
download_precipitation_KNMI <- function(dir_out, station, tstart, tend, ...) {

  # --- initial part of procedure ---

  # set optional arguments
  opt_param <- "replace"
  for (name in opt_param) assign(name, NULL)

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # --- main part of procedure ---

  # set url
  url_base <- "https://cdn.knmi.nl/knmi/map/page/klimatologie/gegevens/monv_reeksen"

  # check date
  if (!is_date(tstart)) stop("unknown format for 'tstart', use 'YYYY-MM-DD'")
  if (!is_date(tend)) stop("unknown format for 'tend', use 'YYYY-MM-DD'")
  tstart <- as_date(tstart)
  tend <- as_date(tend)

  # check selected stations
  station <- str_to_upper(string = station)
  if (!is.null(replace)) replace <- str_to_upper(string = replace)
  station_KNMI <- get_station_KNMI(type = "precipitation", station_name = c(station, replace))

  # set period
  start <- format(x = tstart, "%Y%m%d")
  end <- format(x = tend, "%Y%m%d")

  # create empty data frame
  db_empty <- tibble(date = seq(from = tstart, to = tend, by = 1), time = "08:00:00")

  # create directory
  dir_tmp <- str_c(file_temp(),"/meteo/", format(Sys.time(), "%Y%m%d%H%M%S"))
  dir_create(path = dir_tmp)

  # download data from KNMI
  for (i_stn in seq_along(station_KNMI$STATION_NAME)) {
    stn_nm <- station_KNMI$STATION_NAME[i_stn]
    stn_id <- station_KNMI$STATION_ID[i_stn]
    file_zip <- str_c(dir_tmp, "/KNMI_", stn_id, ".zip")
    url <- str_c(url_base, "/neerslaggeg_", stn_nm, "_", str_pad(string = stn_id, width = 3, pad = "0"), ".zip")
    download_data(file = file_zip, url = url, handle = new_handle())
  }

  # load data
  db_all <- NULL
  for (i_stn in seq_along(station_KNMI$STATION_NAME)) {

    stn_nm <- station_KNMI$STATION_NAME[i_stn]
    stn_id <- station_KNMI$STATION_ID[i_stn]

    # unzip data
    file_zip <- str_c(dir_tmp, "/KNMI_", stn_id, ".zip")
    unzip(zipfile = file_zip, overwrite = TRUE, exdir = dir_tmp)

    # load data and add date information
    file_tmp <- str_c(dir_tmp, "/neerslaggeg_", stn_nm, "_", str_pad(string = stn_id, width = 3, pad = "0"), ".txt")
    col_names <- c("stn_id", "YYYYMMDD", "RD", "dummy_1", "dummy_2")
    db_tmp <- read_csv(file = file_tmp, col_names = col_names, col_types = "cid--", skip = 24, progress = FALSE, lazy = FALSE, num_threads = 1) |>
      mutate(
        date = as_date(str_c(str_sub(string = .data$YYYYMMDD, start = 1, end = 4), "-", str_sub(string = .data$YYYYMMDD, start = 5, end = 6), "-", str_sub(string = .data$YYYYMMDD, start = 7, end = 8))),
        time = "08:00:00"
      ) |>
      select("date", "time", "stn_id", "RD") |>
      filter(.data$date >= tstart, .data$date <= tend)
    db_all <- rbind(db_all, db_tmp)
  }

  # apply factor
  factor <- .knmi_env$knmi_variable$RD$factor
  if (!is.null(factor)) {
    db_all$RD <- db_all$RD * factor
  }

  # set data for replacement
  db_alt <- NULL
  if (!is.null(replace)) {
    first <- TRUE
    for (s_replace in replace) {
      stn <- station_KNMI |> filter(.data$STATION_NAME == s_replace) |> pull("STATION_ID")
      db_alt <- db_empty |> mutate(stn_id = stn)
      db_alt <- left_join(x = db_alt, y = db_all[db_all$stn_id == stn, ], by = join_by("date", "time", "stn_id")) |>
        select("date", "time", "stn_id", "RD")
      if (first) {
        first <- FALSE
        db_stn <- db_alt
      } else {
        db_stn <- replace_missing_data(db_stn = db_stn, db_alt = db_alt, quiet = TRUE)
      }
    }
    db_alt <- db_stn
  }

  # loop over stations
  for (s_station in station) {

    # create data with all available observations
    stn <- station_KNMI |> filter(.data$STATION_NAME == s_station) |> pull("STATION_ID")
    db_stn <- db_empty |> mutate(stn_id = stn)
    db_stn <- left_join(x = db_stn, y = db_all[db_all$stn_id == stn, ], by = join_by("date", "time", "stn_id")) |>
      select("date", "time", "stn_id", "RD")

    # check missing values
    db_stn <- replace_missing_data(db_stn = db_stn, db_alt = db_alt, quiet = FALSE)

    # write file
    dir_create(dir_out)
    file <- str_c(dir_out, "/KNMI_", str_pad(string = stn, width = 3, pad = "0"), "_", start, "-", end, "_prec.csv")
    write_csv(x = db_stn, file = file, progress = FALSE, quote = "none", num_threads = 1)
  }

  # clean directory
  dir_delete(path = dir_tmp)
}

#' Replace missing observations
#'
#' @param db_stn tibble with observations
#' @param db_alt tibble with observations to replace missing data in \code{db_stn}
#' @importFrom dplyr slice pull
#' @keywords internal
replace_missing_data <- function(db_stn, db_alt, quiet) {

  # --- main part of procedure ---

  # extract variables
  variable <- names(db_stn)[!names(db_stn) %in% c("date", "time", "stn_id")]

  # extract station
  stn_id <- db_stn |> slice(1) |> pull("stn_id")
  if (!is.null(db_alt)) replace_id <- db_alt |> slice(1) |> pull("stn_id")

  # check missing values
  found <- FALSE
  for (s_variable in variable) {
    index <- is.na(db_stn[, c(s_variable)])
    n_row <- nrow(db_stn[index, ])
    if (n_row != 0) {
      if (!found && !quiet) message(str_c("\nmissing observations found for ", stn_id,":"))
      found <- TRUE
      if (is.null(db_alt)) {
        if (!quiet) message(str_c(" - ", n_row, " observation(s) missing for variable '", s_variable, "'"))
      } else {
        db_stn[index, s_variable] <- db_alt[index, s_variable]
        db_stn[index, "stn_id"] <- db_alt[index, "stn_id"]
        n_fill <- n_row - nrow(db_stn[is.na(db_stn[, s_variable]), ])
        if (!quiet) message(str_c(" - ", n_row, " observation(s) missing for variable '", s_variable, "'; ", n_fill, " observation(s) replaced"))
      }
    }
  }
  if (found && !quiet) message("")

  # --- return of procedure ---

  return(db_stn)
}
