#' Internal environment of SWAPtools
#'
#' This environment is used to store meta-information of SWAP variables.
#'
#' @importFrom stringr str_c
#' @importFrom fs path_package
#' @importFrom readr read_rds
#' @keywords internal
.knmi_env <- NULL

.onLoad <- function(libname, pkgname) {
  .knmi_env <<- new.env(parent = emptyenv())
  .knmi_env$knmi_stations <- read_rds(file = str_c(path_package(package = "KNMItools"), "/rds/knmi_stations.rds"))
  .knmi_env$knmi_variable <- read_rds(file = str_c(path_package(package = "KNMItools"), "/rds/knmi_variable.rds"))
  .knmi_env$openmeteo_rename <- read_rds(file = str_c(path_package(package = "KNMItools"), "/rds/openmeteo_rename.rds"))
  .knmi_env$openmeteo_variable <- read_rds(file = str_c(path_package(package = "KNMItools"), "/rds/openmeteo_variable.rds"))
  .knmi_env$agera5_variable <- read_rds(file = str_c(path_package(package = "KNMItools"), "/rds/agera5_variable.rds"))
}


