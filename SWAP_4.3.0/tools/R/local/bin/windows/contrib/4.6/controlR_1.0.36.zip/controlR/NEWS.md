# controlR 1.0.36 (2026-04-01)

* vector return file_exists

# controlR 1.0.35 (2026-03-26)

* optional return of default value (add 'default' in get_record or get_switch)

# controlR 1.0.34 (2026-03-12)

* option case_sensitive implemented (default is set to TRUE if not Windows)

# controlR 1.0.33 (2026-03-11)

* default item_exists set to FALSE in case of detect_record
* implementation of get_switch (option 'Yes' or 'No'; return TRUE of FALSE)

# controlR 1.0.32 (2026-02-19)

* improved function file_exists

# controlR 1.0.31 (2026-02-10)

* create_label and unit_expression are deprecated

# controlR 1.0.30 (2025-12-22)

* align y-label (get_my_theme)

# controlR 1.0.29 (2025-10-30)

* size replaced by linewidth (get_my_theme)

# controlR 1.0.28 (2025-08-30)

* optional split of records by comma (get_record)

# controlR 1.0.27 (2025-06-05)

* added unit kgdm (create_label)

# controlR 1.0.26 (2024-03-08)

* multiple patterns in itemstring resolved using str_split_fixed (get_record)

# controlR 1.0.25 (2024-02-14)

* num_threads = 1 (readr)
* detect record in controlfile (detect_record)
* yearday deprecated

# controlR 1.0.24 (2023-05-26)

* check if string can be converted to date improved (is_date)
* check if string can be converted to datetime added (is_datetime)
* uppercase (get_table)

# controlR 1.0.23 (2023-04-18)

* convert info to character (set_variable)

# controlR 1.0.22 (2022-12-16)

* function get_records and get_dirs included
* example set_variable included

# controlR 1.0.21 (2022-12-16)

* function set_variable included

# controlR 1.0.20 (2022-11-21)

* curl brackets for unit

# controlR 1.0.19 (2022-11-01)

* build R-4.2.1

# controlR 1.0.18 (2022-07-26)

* progress set to FALSE

# controlR 1.0.17 (2022-05-18)

* minor adjustment in create_label ('in' was not allowed in label)

# controlR 1.0.16 (2022-05-09)

* minor adjustment in create_label

# controlR 1.0.15 (2022-04-25)

* revision of create_label_graph

# controlR 1.0.14 (2021-11-03)

* eenheden toegevoegd (LINGRA)

# controlR 1.0.13 (2021-08-16)

* check windows besturingssysteem
* naamgeving functies meer in lijn met R dialect
* download functie toegevoegd
* get_digits functie toegevoegd

# controlR 1.0.12 (2021-02-15)

* opschonen argumenten

# controlR 1.0.11 (2020-10-22)

* file_exists niet meer afhankelijk van fs
* eenheden toegevoegd
* update R-paketten

# controlR 1.0.10 (2020-04-25)

* schrijf string als integer weg indien mogelijk

# controlR 1.0.9 (2020-04-15)

* sta tekst toe in str_seq en seq_str
* verzameling van variabelen (get_variable)

# controlR 1.0.8 (2020-03-30)

* basename vervangen door path_file
* negeer spaties binnen aanhalingstekens (get_table)

# controlR 1.0.7 (2020-03-13)

* ggplot functionaliteiten

# controlR 1.0.6 (2020-03-06)

* waarschuwing controle date-check verholpen
* berekening van dagnummer (dayyear) en hydrologisch jaar (hydryear)

# controlR 1.0.5 (2020-02-28)

* optioneel of directory is gespecificeerd in controlfile

# controlR 1.0.4 (2019-12-20)

* verbetering inlezen van numeriek reeks

# controlR 1.0.3 (2019-12-09)

* date-check mag vier vormen aannemen: %Y-%m-%d, %d-%m-%Y, %Y-%b-%d of %d-%b-%Y 

# controlR 1.0.2 (2019-12-02)

* inlezen van numerieke reeks

# controlR 1.0.1 (2019-11-08)

* tabs worden bij het inlezen van de controlfile vervangen
* een keyword mag zowel met als zonder quotes worden gespecificeerd

# controlR 1.0.0 (2019-10-20)

* eerste versie van de controlR beschikbaar op https://waterwijzerlandbouw.wur.nl/index.html
