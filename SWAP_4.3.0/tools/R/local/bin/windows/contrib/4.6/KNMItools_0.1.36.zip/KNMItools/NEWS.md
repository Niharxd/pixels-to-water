# KNMItools 0.1.36 (2026-04-22)

* download data from open-meteo

# KNMItools 0.1.35 (2026-01-20)

* rlang .data
* usage of R environment

# KNMItools 0.1.34 (2025-07-25)

* rename functions analyse (analyse_meteo_KNMI) 

# KNMItools 0.1.33 (2025-04-07)

* update van download_precipitation_KNMI (update website KNMI) 

# KNMItools 0.1.32 (2024-11-05)

* Vlissingen toegevoegd aan lijst met neerslagstations

# KNMItools 0.1.31 (2024-10-25)

* lazy is FALSE (analyse_meteo)

# KNMItools 0.1.30 (2024-03-27)

* download per station

# KNMItools 0.1.29 (2024-02-15)

* yearday niet langer beschikbaar; vervangen door yday (lubridate)

# KNMItools 0.1.28 (2023-12-20)

* voorkom dubbele records

# KNMItools 0.1.27 (2023-12-02)

* opvulling ontbrekende observaties incl. eigen station

# KNMItools 0.1.26 (2023-11-25)

* download KNMI-data via nieuwe procedure
* opvulling ontbrekende observaties via sequentie alternatieve stations

# KNMItools 0.1.25 (2023-11-20)

* read_csv; progress = FALSE

# KNMItools 0.1.24 (2023-09-25)

* optie num_threads = 1 (write_lines; write_csv)

# KNMItools 0.1.23 (2023-03-08)

* controle op unieke naamgeving stations (download_precipitation_KNMI)

# KNMItools 0.1.22 (2022-12-12)

* toevoegen fictieve data indien geen data beschikbaar is (analyse_meteo)

# KNMItools 0.1.21 (2022-11-08)

* all_of niet toepassen in geval van rlang berekening (download_meteo_AgERA5)

# KNMItools 0.1.20 (2022-11-01)

* build R-4.2.1

# KNMItools 0.1.19 (2022-10-20)

* all_of niet toepassen in geval van rlang berekening (download_meteo_KNMI)

# KNMItools 0.1.18 (2022-10-03)

* update analyse_precipitation_KNMI

# KNMItools 0.1.17 (2022-04-25)

* update controlR

# KNMItools 0.1.16 (2022-04-25)

* vernieuwde versie van create_label_graph

# KNMItools 0.1.15 (2022-04-12)

* code neerslagstation nu met 3 cijfers weergegeven in url

# KNMItools 0.1.14 (2022-03-11)

* meteogegevens AgERA5 en neerslaggegevens CHIRPS (alleen indien toegang tot WUR netwerk)

# KNMItools 0.1.13 (2021-11-16)

* verandering van header meteo-files

# KNMItools 0.1.12 (2021-10-21)

* vergelijking neerslag met meerdere weerstations tegelijk

# KNMItools 0.1.11 (2021-08-16)

* check besturingssysteem bij gebruik van read_csv (readr)
* download_KNMI is vervangen door download_data (controlR)

# KNMItools 0.1.10 (2021-08-12)

* voor voor tijdelijke folder file_temp (fs)

# KNMItools 0.1.9 (2021-07-08)

* check ontbrekende meteogegevens in vervangend station

# KNMItools 0.1.8 (2021-05-18)

* controle station keuze

# KNMItools 0.1.7 (2021-04-14)

* vergelijking neerslag (double-mass curve)

# KNMItools 0.1.6 (2021-03-10)

* download van KNMI data werkt tijdelijk niet in verband met overstap op nieuw systeem
* nu verholpen door de oude zip-bestanden te downloaden

# KNMItools 0.1.5 (2021-02-15)

* berekening actuele vochtspanning optioneel op basis van gemiddelde luchvochtigheid
* duplicatie bij opvulling met hetzelfde station

# KNMItools 0.1.4 (2020-10-22)

* toevoegen van deframe na update tibble

# KNMItools 0.1.3 (2020-10-06)

* update R-paketten

# KNMItools 0.1.2 (2020-03-13)

* analyse beschikbaarheid van meetgegevens
* ontbrekende meteogegevens opvullen met ander station

# KNMItools 0.1.1 (2020-03-12)

* berekening van de referentieverdamping (FAO 56: vergelijking 6)

# KNMItools 0.1.0 (2020-02-27)

* eerste versie van de KNMItools
