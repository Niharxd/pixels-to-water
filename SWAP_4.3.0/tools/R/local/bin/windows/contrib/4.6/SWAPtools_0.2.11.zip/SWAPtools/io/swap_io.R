setwd("c:/Users/mulde027/Software/R/Packages/SWAPtools/inst/io")

library(fs)
library(stringr)
library(readr)
library(dplyr)

# ---- INPUT ----

db <- read_csv(file = "swap_input.csv", col_types = "ccccccccDDddccc", progress = FALSE, num_threads = 1)

input <- list()
for (i_rec in seq_along(db$variable)) {
  lst <- list(
    extension = db$extension[i_rec],
    label = db$label[i_rec],
    type = db$type[i_rec],
    format = db$format[i_rec]
  )

  if (!is.na(db$deprecated[i_rec])) lst$deprecated <- db$deprecated[i_rec]
  if (!is.na(db$unit[i_rec])) lst$unit <- db$unit[i_rec]
  if (!is.na(db$default[i_rec])) lst$default <- str_split(string = db$default[i_rec], pattern = ";", simplify = TRUE)[1,]

  if (lst$format == "date") {
    if (any(c(is.na(db$start[i_rec]), is.na(db$end[i_rec])))) stop(str_c("check 'limits' of '", db$variable[i_rec], "'"))
    lst$start <- db$start[i_rec]
    lst$end <- db$end[i_rec]
  }

  if (lst$format %in% c("float", "integer")) {
    if (any(c(is.na(db$min[i_rec]), is.na(db$max[i_rec])))) stop(str_c("check 'limits' of '", db$variable[i_rec], "'"))
    lst$min <- db$min[i_rec]
    lst$max <- db$max[i_rec]
  }

  if (lst$format == "switch") {
    if (is.na(db$option[i_rec])) stop(str_c("check 'options' of '", db$variable[i_rec], "'"))
    options <- str_split(string = db$option[i_rec], pattern = ";", simplify = TRUE)[1,]
    opts <- list()
    for (i_opt in seq_along(options)) {
      label <- str_split(string = options[i_opt], pattern = "==", simplify = TRUE)[1,1]
      switch <- str_split(string = options[i_opt], pattern = "==", simplify = TRUE)[1,2]
      opts[[label]] <- switch
    }
    lst$option <- opts
  }

  if (lst$type == "vector") {
    if (is.na(db$index[i_rec])) stop(str_c("check index of '", db$variable[i_rec], "'"))
    lst$index <- db$index[i_rec]
    if (!db$order[i_rec] %in% c("increasing", "decreasing")) stop(str_c("check 'order' of '", db$variable[i_rec], "'"))
    lst$order <- db$order[i_rec]
  }

  name <- db$variable[i_rec]
  if (name %in% names(input)) stop(str_c("Variable '", name, "' already exists"))
  input[[name]] <- lst
}

# add table variables

db_tbl <- read_csv(file = "swap_input_table.csv", col_types = "ccccclcc", progress = FALSE, num_threads = 1)

for (i_rec in seq_along(db_tbl$variable)) {
  tbl <- list(
    extension = db_tbl$extension[i_rec],
    label = db_tbl$label[i_rec],
    format = "table",
    header = db_tbl$header[i_rec],
    index = db_tbl$index[i_rec],
    order = db_tbl$order[i_rec],
    column = str_split(string = db_tbl$column[i_rec], pattern = ";", simplify = TRUE)[1,]
  )

  if (!is.na(db_tbl$deprecated[i_rec])) tbl$deprecated <- db_tbl$deprecated[i_rec]

  name <- db_tbl$variable[i_rec]

  # check if all columns are available
  for (variable in tbl$column) {
    if (!variable %in% names(input)) stop(str_c("Unknown column ('", variable, "')selected in table '", , "'"))
  }

  if (name %in% names(input)) stop(str_c("Table '", name, "' already exists"))
  input[[name]] <- tbl
}

write_rds(x = input, file = "swap_input.rds")

# ---- OUTPUT ----

db <- read_csv(file = "swap_output.csv", col_types = "cccdcccccccccccccccldc", progress = FALSE, num_threads = 1)

var_lst <- list()
for (i_rec in seq_along(db$variable)) {

  name <- str_replace(string = db$variable[i_rec], pattern = "\\[\\.\\.\\.\\]", replacement = "")
  quantity <- ifelse(str_detect(string = db$variable[i_rec], pattern = "\\[\\.\\.\\.\\]"), "vector", "scalar")

  var <- list(
    variable = db$variable[i_rec],
    module = db$module[i_rec],
    quantity = quantity,
    type = db$type[i_rec],
    graph_type = db$graph_type[i_rec],
    description = db$description[i_rec],
    label_EN = db$label_EN[i_rec],
    unit_EN = ifelse(db$unit_EN[i_rec] == "-", "'-'", ifelse(db$unit_EN[i_rec] == "%", "'%'", db$unit_EN[i_rec])),
    label_NL = ifelse(is.na(db$label_NL[i_rec]), db$label_EN[i_rec], db$label_NL[i_rec]),
    unit_NL = ifelse(is.na(db$unit_NL[i_rec]), ifelse(db$unit_EN[i_rec] == "-", "'-'", ifelse(db$unit_EN[i_rec] == "%", "'%'", db$unit_EN[i_rec])), ifelse(db$unit_NL[i_rec] == "-", "'-'", ifelse(db$unit_NL[i_rec] == "%", "'%'", db$unit_NL[i_rec]))),
    colour = str_squish(string = str_split(string = db$colour[i_rec], pattern = ";", simplify = TRUE)[1,])
  )

  # optional settings
  if (quantity == "vector") {
    if (!db$type_tz_info[i_rec] %in% c("top", "center", "top_bottom")) stop("illegal type of TZ_INFO provided!")
    var$type_tz_info <- db$type_tz_info[i_rec]
  }
  if (!is.na(db$deprecated[i_rec])) var$deprecated <- db$deprecated[i_rec]
  if (!is.na(db$palette[i_rec])) {

    if (!db$palette[i_rec] %in% c("viridis", "cividis", "warmcool", "parula")) stop("unknown palette selected")
    var$palette <- db$palette[i_rec]
    var$palette_flip <- db$palette_flip[i_rec]
  }
  if (!is.na(db$factor[i_rec])) var$factor <- db$factor[i_rec]
  var$n_expr <- 0
  if (!is.na(db$expression[i_rec])) {
    expression <- str_split(db$expression[i_rec], pattern = ";", simplify = TRUE)[1, ]
    db_expr <- NULL
    for (i_expr in seq_along(expression)) {
      string <- str_split(expression[i_expr], pattern = "=", n = 2, simplify = TRUE)[1,]
      db_tmp <- tibble(variable = string[1], expr = string[2])
      db_expr <- rbind(db_expr, db_tmp)
    }
    var$n_expr <- nrow(db_expr)
    var$expr <- db_expr
  }
  if (!is.na(db$dependency[i_rec])) {
    var$dependency <- str_squish(string = str_split(string = db$dependency[i_rec], pattern = ";", simplify = TRUE)[1,])
  } else {
    var$dependency <- name
  }
  if (!is.na(db$optional[i_rec])) var$optional <- str_squish(string = str_split(string = db$optional[i_rec], pattern = ";", simplify = TRUE)[1,])
  if (!is.na(db$levels[i_rec])) var$levels <- str_squish(string = str_split(string = db$levels[i_rec], pattern = ";", simplify = TRUE)[1,])
  if (!is.na(db$labels_EN[i_rec])) var$labels_EN <- str_squish(string = str_split(string = db$labels_EN[i_rec], pattern = ";", simplify = TRUE)[1,])
  if (!is.na(db$labels_NL[i_rec])) var$labels_NL <- str_squish(string = str_split(string = db$labels_NL[i_rec], pattern = ";", simplify = TRUE)[1,])
  if (!is.na(db$pF[i_rec])) var$pF <- db$pF[i_rec]

  if (var$n_expr > 0 && is.null(var$levels)) stop(str_c("Specify 'Levels' in case of expression!"))
  if (!is.null(var$levels)) {
    if (length(var$levels) != 1) {
    if (length(var$levels) != length(var$labels_EN)) stop(str_c("Labels_EN of variable '", name, "' don't match with number of levels!"))
    if (length(var$levels) != length(var$labels_NL)) stop(str_c("Labels_NL of variable '", name, "' don't match with number of levels!"))
    if (length(var$levels) != length(var$colour)) stop(str_c("Colour of variable '", name, "' don't match with number of levels!"))
    }
  }

  if (name %in% names(var_lst)) stop(str_c("Variable '", name, "' already in list!"))
  var_lst[[name]] <- var
}

write_rds(x = var_lst, file = "swap_output.rds")

# ---- RENAME ----

db <- read_csv(file = "swap_rename.csv", col_types = "cc", progress = FALSE, num_threads = 1)
write_rds(x = db, file = "swap_rename.rds")

# ---- SHORTLIST ----

shortlist <- list()

db <- read_csv(file = "shortlist.csv", col_types = "cc", progress = FALSE, num_threads = 1)

alias <- list()
for (i_rec in seq_along(db$alias)) {
  alias[[db$alias[i_rec]]] <- str_split(string = db$variable[i_rec], pattern = ";", simplify = TRUE)[1,]
}

shortlist$alias <- alias

# filter settings shortlist
db <- read_csv(file = "shortlist_filter.csv", col_types = "ccc", progress = FALSE, num_threads = 1)

filter <- list()
filter$n_eval <- nrow(db)
filter$dependency <- NA_character_
for (i_rec in seq_along(db$evaluation)) {
  if (all(is.na(filter$dependency))) {
    filter$dependency <- db$dependency[i_rec]
  } else {
    filter$dependency <- unique(c(filter$dependency, str_split(string = db$dependency[i_rec], pattern = ";", simplify = TRUE)))
  }
  eval <- list(
    dependency = str_split(string = db$dependency[i_rec], pattern = ";", simplify = TRUE),
    expression = db$evaluation[[i_rec]],
    exclude = str_split(string = db$exclude[[i_rec]], pattern = ";", simplify = TRUE)[1,]
  )
  filter[[str_c("eval_", i_rec)]] <- eval
}

shortlist$filter <- filter

write_rds(x = shortlist, file = "swap_shortlist.rds")

