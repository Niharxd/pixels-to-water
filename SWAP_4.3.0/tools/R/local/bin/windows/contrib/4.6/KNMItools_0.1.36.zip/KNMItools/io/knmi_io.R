setwd("c:/Users/mulde027/Software/R/Packages/KNMItools/inst/io")

library(stringr)
library(tibble)
library(readr)

# --- STATIONS ---

file_csv <- "knmi_stations.csv"
db_station <- read_csv(file = file_csv, col_types = "cccdddd", num_threads = 1, progress = FALSE)
write_rds(x = db_station, file = "knmi_stations.rds")

# --- VARIABLES ---

file_csv <- "knmi_variable.csv"
db <- read_csv(file = file_csv, col_types = "cccccdccc", num_threads = 1, progress = FALSE)

db_variable <- list(opt_day = NA_character_, opt_hour = NA_character_, opt_prec = NA_character_)
for (i_rec in seq_along(db$variable)) {
  db_var <- list(
    label = str_c("bold(", db$label[i_rec], ")~(", db$unit[i_rec], ")"),
    factor = db$factor[i_rec],
    aggregate = db$aggregate[i_rec],
    colour = db$colour[i_rec]
  )

  if (!is.na(db$expression[i_rec])) db_var$expression = db$expression[i_rec]

  name <- db$variable[i_rec]

  if (db$type[i_rec] == "weather") {
    interval <- str_split(string = db$interval[i_rec], pattern = ";", simplify = TRUE)[1,]
    if ("day" %in% interval) {
      if (is.na(db_variable$opt_day[1])) {
        db_variable$opt_day <- name
      } else {
        db_variable$opt_day <- c(db_variable$opt_day, name)
      }
    }
    if ("hour" %in% interval) {
      if (is.na(db_variable$opt_hour[1])) {
        db_variable$opt_hour <- name
      } else {
        db_variable$opt_hour <- c(db_variable$opt_hour, name)
      }
    }
  }
  if (db$type[i_rec] == "precipitation") {
    if (is.na(db_variable$opt_prec[1])) {
      db_variable$opt_prec <- name
    } else {
      db_variable$opt_prec <- c(db_variable$opt_prec, name)
    }
  }

  db_variable[[name]] <- db_var
}

write_rds(x = db_variable, file = "knmi_variable.rds")


file_csv <- "agera5_variable.csv"
db <- read_csv(file = file_csv, col_types = "cccdcc", num_threads = 1, progress = FALSE)

db_variable <- list(opt = NA_character_)
for (i_rec in seq_along(db$variable)) {
  db_var <- list(
    label = str_c("bold(", db$label[i_rec], ")~(", db$unit[i_rec], ")"),
    factor = db$factor[i_rec],
    aggregate = db$aggregate[i_rec],
    colour = db$colour[i_rec]
  )

  name <- db$variable[i_rec]

  if (is.na(db_variable$opt[1])) {
    db_variable$opt <- name
  } else {
    db_variable$opt <- c(db_variable$opt, name)
  }

  db_variable[[name]] <- db_var
}

write_rds(x = db_variable, file = "agera5_variable.rds")



file_csv <- "openmeteo_variable.csv"
db <- read_csv(file = file_csv, col_types = "cccdccc", num_threads = 1, progress = FALSE)

db_variable <- list(opt = NA_character_)
for (i_rec in seq_along(db$variable)) {
  db_var <- list(
    label = str_c("bold(", db$label[i_rec], ")~(", db$unit[i_rec], ")"),
    factor = db$factor[i_rec],
    aggregate = db$aggregate[i_rec],
    colour = db$colour[i_rec]
  )

  if (!is.na(db$expression[i_rec])) db_var$expression = db$expression[i_rec]

  name <- db$variable[i_rec]

  if (is.na(db_variable$opt[1])) {
    db_variable$opt <- name
  } else {
    db_variable$opt <- c(db_variable$opt, name)
  }

  db_variable[[name]] <- db_var
}

write_rds(x = db_variable, file = "openmeteo_variable.rds")

file_csv <- "openmeteo_rename.csv"
db <- read_csv(file = file_csv, col_types = "cc", progress = FALSE, num_threads = 1)
write_rds(x = db, file = "openmeteo_rename.rds")

