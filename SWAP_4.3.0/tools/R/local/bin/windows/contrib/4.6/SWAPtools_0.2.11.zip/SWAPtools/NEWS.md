# SWAPtools 0.2.11 (2026-05-18)

* runon variables

# SWAPtools 0.2.10 (2026-05-06)

* create meteorological data based on controlfile (create_meteo_SWAP, create_precipitation_SWAP)

# SWAPtools 0.2.9 (2026-05-04)

* bug solved in aggregation of data in case level of aggregation exceeds the cropping period (get_plot)

# SWAPtools 0.2.8 (2026-05-01)

* optional creation of meta-information (plot_SWAP; default: FALSE)

# SWAPtools 0.2.7 (2026-04-22)

* update of KNMItools; meteorological data from open-meteo

# SWAPtools 0.2.6 (2026-04-15)

* tz_info for vector variables (distinguish between top_bottom, top, center)

# SWAPtools 0.2.5 (2026-04-10)

* plot NA in case no roots present
* format column of output data (plot_SWAP)

# SWAPtools 0.2.4 (2026-04-08)

* case_sensitive in case of LINUX

# SWAPtools 0.2.3 (2026-03-19)

* extract_run_id improved

# SWAPtools 0.2.2 (2026-03-17)

* warning if GHG descends below GLG
* label Rpearson presented as r instead of R2

# SWAPtools 0.2.1 (2026-03-16)

* update of get_gt (option 2018)

# SWAPtools 0.2.0 (2026-01-20)

* complete new setup for handling model input and output
* input: optional usage of tables
* output: all plot functions removed and replaced by plot_SWAP and get_plot
* all variables are managed in cvs-files (input, output, shortlist, rename)
* update of KNMItools

# SWAPtools 0.1.169 (2025-12-16)

* backward compatible management tables (update swap-variables)

# SWAPtools 0.1.168 (2025-11-20)

* min_year added to plot_gwlevel

# SWAPtools 0.1.167 (2025-11-05)

* extract only key_id (get_run_info_SQL)

# SWAPtools 0.1.166 (2025-11-05)

* checks on EXCEL-database

# SWAPtools 0.1.165 (2025-10-30)

* run_id to string (str_run_id)

# SWAPtools 0.1.164 (2025-10-29)

* reset crop development (plot_cropdev)

# SWAPtools 0.1.163 (2025-10-28)

* shift one day in joining remaining yield of grass (plot_cropdev)

# SWAPtools 0.1.162 (2025-08-21)

* update swap-variables belonging to SWDISLAY

# SWAPtools 0.1.161 (2025-07-25)

* analyse available meteorological data (plot_meteo)

# SWAPtools 0.1.160 (2025-07-23)

* optional usage of humidity and windfactor

# SWAPtools 0.1.159 (2025-07-15)

* exclude variables while creating template

# SWAPtools 0.1.158 (2025-07-10)

* update of SWAP-variables (SWABS)

# SWAPtools 0.1.157 (2025-06-27)

* plot_return implemented for crop development plotting functions

# SWAPtools 0.1.156 (2025-06-24)

* file_delete and dir_delete replaced by unlink to prevent error

# SWAPtools 0.1.155 (2025-06-23)

* variable names changed of LOSSMOWTB and LOSSGRZTB

# SWAPtools 0.1.154 (2025-06-18)

* determination actual vapour pressure by average relative humidity (optional; create_meteo_SWAP)

# SWAPtools 0.1.153 (2025-06-11)

* determination daily average windspeed (create_meteo_SWAP)

# SWAPtools 0.1.152 (2025-06-05)

* added unit kgdm in plot
* output of predictions (plot_cropdev and plot_grass)

# SWAPtools 0.1.151 (2025-06-02)

* update of alias names

# SWAPtools 0.1.150 (2025-06-02)

* yield plotted from CROPSTART until CROPEND (plot_yield) 

# SWAPtools 0.1.149 (2025-05-28)

* check usage of HRV and HRV+ in case of old SWAP version
* update of example including ponding evaporation

# SWAPtools 0.1.148 (2025-05-16)

* ponding evaporation introduced (SWAP version 4.2.232)

# SWAPtools 0.1.147 (2025-05-01)

* option sum of squared errors 'sse' added (get_modelperformance)

# SWAPtools 0.1.146 (2025-04-22)

* zip SWAP results (command set to 'zip' by default)

# SWAPtools 0.1.145 (2025-04-16)

* start comment at position 30 (set_template)

# SWAPtools 0.1.144 (2025-04-15)

* plotting of available soil water (ASW) and available storage (ASTO)
* filename observations with depth-range 

# SWAPtools 0.1.143 (2025-03-25)

* shift one timestep (create_precipitation_SWAP)
* update of KNMItools

# SWAPtools 0.1.142 (2025-03-25)

* return list of groundwater characteristics including hg3, lg3 and gvg (get_gxg)
* update SWAP-variables (ALTH)

# SWAPtools 0.1.141 (2025-03-18)

* return list of groundwater characteristics (get_gxg)

# SWAPtools 0.1.140 (2025-03-16)

* implementation of datetime_start and datetime_end

# SWAPtools 0.1.139 (2025-03-13)

* plotting in case of NPRINTDAY > 1
* shift datetime in case of barplot

# SWAPtools 0.1.138 (2025-02-24)

* bug in plot variable bar-plot (plot_variable)

# SWAPtools 0.1.137 (2025-02-05)

* plot variable at multiple depths (plot_variable)
* minor bug create_precipitation

# SWAPtools 0.1.136 (2025-01-28)

* check filter QBOTTOM in case of SWBOTB=6 (extract_variable_inlist)
* update SWAP-variables (SWOXYGEN=2; GFP100)

# SWAPtools 0.1.135 (2025-01-15)

* filter NODATA in plotting (plot_variable and plot_gwlevel)
* update SWAP-variables (SWOXYGEN=2; CAMPBELL)

# SWAPtools 0.1.134 (2024-11-25)

* STRESSOR-variables added to SWAP-variables

# SWAPtools 0.1.133 (2024-10-25)

* assume NPRINTDAY = 1 as default (read_csv_SWAP)

# SWAPtools 0.1.132 (2024-09-30)

* add range observations in plot (plot_variable, plot_cropdev, plot_gwlevel)

# SWAPtools 0.1.131 (2024-08-29)

* add data in case of plot_yield

# SWAPtools 0.1.130 (2024-08-26)

* update plot_cropdev in case of grass

# SWAPtools 0.1.129 (2024-08-09)

* update SWAP variables

# SWAPtools 0.1.128 (2024-07-23)

* update SWAP input and output variables (new implementation of WOFOST and GRASS)
* update functions plot_cropdev and plot_yield

# SWAPtools 0.1.127 (2024-06-29)

* update SWAP output variables (new implementation of WOFOST)

# SWAPtools 0.1.126 (2024-06-24)

* using all_of in case of rename (add_observed)

# SWAPtools 0.1.125 (2024-05-07)

* argument description (get_plot_period)
* usage of annotate (plot_gwlevel)

# SWAPtools 0.1.124 (2024-04-23)

* stop in case of more than one value is found in database while single value is needed
* prevent database to lock

# SWAPtools 0.1.123 (2024-04-10)

* fixed irrigation template (tmplt_irg)

# SWAPtools 0.1.122 (2024-04-05)

* update swap-variables (SWKMEAN; option 7 and 8)
* add wwl-variables (SWIND, DVSHARV and HHARV)

# SWAPtools 0.1.121 (2024-03-28)

* hourly precipitation from weather station

# SWAPtools 0.1.120 (2024-02-20)

* optional usage of key-id in path file_swp
* update swap-variables (SSDI; SWDMI2RD)

# SWAPtools 0.1.119 (2024-02-15)

* text or file as input for get_run_id_CTRL
* dependency KNMItools 0.1.29

# SWAPtools 0.1.118 (2024-02-14)

* num_threads = 1 (readr)

# SWAPtools 0.1.117 (2024-02-07)

* update swap-variables (detailed meteo)

# SWAPtools 0.1.116 (2024-02-05)

* update of header meteo-files

# SWAPtools 0.1.115 (2024-02-02)

* update swap-variables (numerical solution)

# SWAPtools 0.1.114 (2024-01-31)

* check if SWAP csv-output is still ',' separated (scan_csv_SWAP)

# SWAPtools 0.1.113 (2024-01-24)

* check SWRAIN only in case of daily meteo; update swap-variables (ELAS)

# SWAPtools 0.1.112 (2023-12-11)

* update swap-variables (SWDISCRVERT=1 and SWINTER=3)

# SWAPtools 0.1.111 (2023-11-23)

* update output-variables

# SWAPtools 0.1.110 (2023-11-23)

* update of KNMItools
* update of meteorological conditions; average daytime windspeed (option: daytime_windspeed)

# SWAPtools 0.1.109 (2023-11-17)

* update of swap-output variables (GRAS2007)
* update of SWAP-templates (SWGC)

# SWAPtools 0.1.108 (2023-10-26)

* optional return of plot (plot_*)

# SWAPtools 0.1.107 (2023-10-11)

* allow spaces between multiple timesteps (extract_tz_info)

# SWAPtools 0.1.106 (2023-09-25)

* download hourly meteorological data (create_meteo_SWAP)

# SWAPtools 0.1.105 (2023-08-19)

* TZ-info function (check_tz_info; delete_tz_info; extract_tz_info)
* generate optional overview of meteorological conditions (create_meteo_SWAP, create_meteo_AgERA5)

# SWAPtools 0.1.104 (2023-08-02)

* update of plot_solbal

# SWAPtools 0.1.103 (2023-07-20)

* update of swap-output variables (SSNOW)

# SWAPtools 0.1.102 (2023-06-22)

* update of swap-output variables (GRAS2007)

# SWAPtools 0.1.101 (2023-06-07)

* update of swap-output variables (net rain)
* optional graph_type (plot_variable)
* get_gxg based on date or datetime

# SWAPtools 0.1.100 (2023-06-06)

* extract switch SWBOTB in case of usage file_bbc (extract_variable_inlist)
* return NA in case of none variation (get_model_performance; rmse)
* performance 'index of agreement' added (get_model_performance)

# SWAPtools 0.1.99 (2023-06-02)

* plot solute balance (plot_solbal)

# SWAPtools 0.1.98 (2023-05-31)

* convert date to datetime (plot_xxx and get_gxg)
* read date as datetime (T; read_csv_SWAP) 
* scan header while loading observations (add_observed)

# SWAPtools 0.1.97 (2023-05-26)

* file_delete replaced by unlink (zip_SWAP)
* case-sensitive selecting cropfil (plot_xxx)

# SWAPtools 0.1.96 (2023-05-23)

* inlist in case of multiple depth (extract_variable_inlist)
* update of swap-variables (macropores)
* update of SWAP-templates (macropores)

# SWAPtools 0.1.95 (2023-05-19)

* rename plot_profile into plot_soilprofile
* plotting tz_variable (plot_profile)
* update of swap-variables (macropores)
* update of SWAP-templates (macropores)

# SWAPtools 0.1.94 (2023-05-09)

* update of swap-variables
* update of SWAP-templates

# SWAPtools 0.1.93 (2023-04-24)

* extent met2 replaced by met (create_meteo_SWAP)

# SWAPtools 0.1.92 (2023-04-19)

* replaced write_lines by writeLines
* replaced write_csv by write.table

# SWAPtools 0.1.91 (2023-04-19)

* num_threads op 1 bij wegschrijven middels readr-package

# SWAPtools 0.1.90 (2023-04-11)

* update of swap-variables
* update of SWAP-templates

# SWAPtools 0.1.89 (2023-04-06)

* colour check for plotting of watbal and subreg
* update of swap-variables
* update of SWAP-templates

# SWAPtools 0.1.88 (2023-03-29)

* potential transpiration minus reduction by stressors (plot_tred)
* replacing aes_string by aes
* specify argument multiple = "all" in case of inner_join
* lintr check

# SWAPtools 0.1.87 (2023-03-22)

* update SWAP-variables (microscopic root water uptake)
* update CROP-templates

# SWAPtools 0.1.86 (2023-03-21)

* delete zip-program (zip_SWAP)

# SWAPtools 0.1.85 (2023-03-17)

* optional zip-command (zip_SWAP)

# SWAPtools 0.1.84 (2023-02-15)

* calculation of pressure head based on water content (get_h_MvG)

# SWAPtools 0.1.83 (2023-02-14)

* bug-fix for variables with date DD-MM
* usage of str_pad instead of formatC

# SWAPtools 0.1.82 (2023-01-27)

* update CROP-templates

# SWAPtools 0.1.81 (2022-12-29)

* get run_id based on information provided in controlfile (get_run_id_CTRL)

# SWAPtools 0.1.80 (2022-12-29)

* filter run_id based on list and/or arguments (filter_run_id_SQL)

# SWAPtools 0.1.79 (2022-12-29)

* extract key_id from sql-database (get_key_id_SQL)

# SWAPtools 0.1.78 (2022-12-22)

* first transform unit before calculation of model performance

# SWAPtools 0.1.77 (2022-12-22)

* create label of model performance (get_modelperformance_label)
* update of plot_variable, plot_gwlevel, plot_cropdev and plot_grass using get_modelperformance_label

# SWAPtools 0.1.76 (2022-12-21)

* multiple observations at one day (add_observed)

# SWAPtools 0.1.75 (2022-12-16)

* update SWAP-variables (SEQGRAZMOW)

# SWAPtools 0.1.74 (2022-12-12)

* remove all_of in case of mutation
* minor bug in label actual evapotranspiration (plot_etact)

# SWAPtools 0.1.73 (2022-11-09)

* remove case_sensitive (read_csv_SWAP)

# SWAPtools 0.1.72 (2022-09-29)

* build R-4.2.1

# SWAPtools 0.1.71 (2022-09-29)

* convert template to UTF-8 (set_template_SWAP)

# SWAPtools 0.1.70 (2022-09-15)

* plotting modelperformance also based on range observed values

# SWAPtools 0.1.69 (2022-09-07)

* bug in plotting modelperformance resolved

# SWAPtools 0.1.68 (2022-09-01)

* update SWAP-variables (basic drainage)

# SWAPtools 0.1.67 (2022-09-01)

* check if swap-variable is available as a vector or as a array (get_value_SWAP)
* update SWAP-variables (CROPMODULE)

# SWAPtools 0.1.66 (2022-09-01)

* update SWAP-variables (MISCELLANEOUS)

# SWAPtools 0.1.65 (2022-08-30)

* kleine wijzigingen in plot_profile

# SWAPtools 0.1.64 (2022-08-21)

* update SWAP-variables (SFU)

# SWAPtools 0.1.63 (2022-07-22)

* meteogegevens AgERA5 en neerslaggegevens CHIRPS (alleen indien toegang tot WUR netwerk)

# SWAPtools 0.1.62 (2022-07-22)

* minor bug in label actual evapotranspiration (plot_etact)

# SWAPtools 0.1.61 (2022-06-22)

* update templates

# SWAPtools 0.1.60 (2022-06-10)

* minor bug in get_modelperformance in case of usage index

# SWAPtools 0.1.59 (2022-06-09)

* minor bug in label actual evapotranspiration (swap_output.rds)

# SWAPtools 0.1.58 (2022-06-08)

* str_trim in case of spaces (inlist)

# SWAPtools 0.1.57 (2022-05-11)

* add plots for drainage (plot_drainage)

# SWAPtools 0.1.56 (2022-05-09)

* add plots for reduction root water uptake and development grass (plot_rrwu; plot_grass)
* update controlR and KNMItools

# SWAPtools 0.1.55 (2022-05-08)

* general plotting of SWAP results

# SWAPtools 0.1.54 (2022-04-25)

* plot soil-profiles
* hide internal functions in Help Pages
* revision of get_gxg and create_label_graph

# SWAPtools 0.1.53 (2022-04-17)

* update of SWAP variables (DPL_A0 and DPL_A1)

# SWAPtools 0.1.52 (2022-04-12)

* update of SWAP variables (SWDROUGHT = 3)
* update of KNMItools (version: 0.1.15)

# SWAPtools 0.1.51 (2022-01-20)

* update of SWAP variables (swcsv_tz)

# SWAPtools 0.1.50 (2022-01-04)

* set template with customized swap-variables (create_SWAP)

# SWAPtools 0.1.49 (2021-12-30)

* automatically extract column depth if available (read_csv_SWAP) 

# SWAPtools 0.1.48 (2021-12-27)

* extract date with format DD MM from template (get_value_SWAP)
* check date with format DD MM from template (check_value_SWAP)
* optional specification of dir_atm (create_SWAP) 

# SWAPtools 0.1.47 (2021-11-17)

* extract single column array-variable (get_value_SWAP)

# SWAPtools 0.1.46 (20210-11-08)

* update of SWAP variables (LINGRA)
* extract vector-variable without index (get_value_SQL)
* filter table-variables (set_variable_SWAP)
* only load columns with SWAP data from Excel (create_database_SWAP)
* extract SWAP version from csv-output

# SWAPtools 0.1.45 (2021-10-11)

* string-variabelen naar kleine letters
* opvragen variabelen in template zonder header
* controle op naam worksheet

# SWAPtools 0.1.44 (2021-09-02)

* bug in wegschrijven van meta-informatie meteo-bestanden
* set progress to FALSE in case of reading file

# SWAPtools 0.1.43 (2021-08-23)

* sorteren run_id (get_run_id_SQL)

# SWAPtools 0.1.42 (2021-08-16)

* update van readr en controlR
* toevoegen van meta-informatie aan header meteo-bestanden

# SWAPtools 0.1.41 (2021-07-22)

* decreasing order in case variable is function of depth (get_value_SQL)

# SWAPtools 0.1.40 (2021-07-01)

* update of SWAP variables (lingra)

# SWAPtools 0.1.39 (2021-06-08)

* optionele argumenten create_swap

# SWAPtools 0.1.38 (2021-05-25)

* unzip modelresultaten

# SWAPtools 0.1.37 (2021-05-18)

* bepaling van watervolume op basis van drukhoogte of pF waarde

# SWAPtools 0.1.36 (2021-05-05)

* filter run_id op basis van specificatie argumenten
* new output from SWAP version 4.1.81

# SWAPtools 0.1.35 (2021-04-30)

* update of SWAP variables (aeratecrit)

# SWAPtools 0.1.34 (2021-03-16)

* opvragen van meerdere SWAP variabelen tegelijk (get_settings_SWAP)

# SWAPtools 0.1.33 (2021-03-11)

* update of SWAP variables (swcompensate)

# SWAPtools 0.1.32 (2021-02-02)

* uitbreiding SWAP uitvoer variabelen
* wegschrijven gemiddelde berekende waarde (get_performance)

# SWAPtools 0.1.31 (2020-10-29)

* melding naar het scherm bij aanmaken sql-database
* verbeterde afhandeling foutmeldingen bij aanmaken sql-database
* inlezen van vap-file uitvoer

# SWAPtools 0.1.30 (2020-10-22)

* update R-paketten

# SWAPtools 0.1.29 (2020-09-29)

* update of SWAP variables (swgerm)

# SWAPtools 0.1.28 (2020-09-24)

* update of SWAP variables (vernrtb)

# SWAPtools 0.1.27 (2020-07-29)

* update of SWAP variables (swtsum)

# SWAPtools 0.1.26 (2020-07-22)

* add observations to sqlite-database

# SWAPtools 0.1.25 (2020-07-21)

* flags specified when approaching sqlite-database (dbConnect)

# SWAPtools 0.1.24 (2020-06-30)

* read date with timestamp (read_csv_SWAP)

# SWAPtools 0.1.23 (2020-05-29)

* get non-unique index value (get_value_SQL)
* add space between columns (set_tabel_SWAP)
* update of SWAP variables (tillage)

# SWAPtools 0.1.22 (2020-05-07)

* update of SWAP variables (tillage)

# SWAPtools 0.1.21 (2020-04-30)

* update of SWAP variables (CN-method)

# SWAPtools 0.1.20 (2020-03-17)

* update of SWAP variables
* handling NA values in table (Bi-modal Mualem - Van Genuchten)

# SWAPtools 0.1.19 (2020-03-13)

* ggplot functionality moved to controlR
* option to replace missing values in meteo download

# SWAPtools 0.1.18 (2020-03-10)

* Bi-modal Mualem - Van Genuchten added to SWAP variables
* Delete table-column containing missing values

# SWAPtools 0.1.17 (2020-03-02)

* calculation of actual vapour pressure moved to KNMItools

# SWAPtools 0.1.16 (2020-03-02)

* Bi-modal Mualem - Van Genuchten added to SWAP variables

# SWAPtools 0.1.15 (2020-03-02)

* lowercase (TTUTILL on LINUX)
* export of function get_run_info_SQL

# SWAPtools 0.1.14 (2020-02-27)

* added Mualem van Genuchten functionalities
* tools for downloading KNMI data moved to package KNMItools

# SWAPtools 0.1.13 (2020-01-23)

* initialisation of SWAP (INIFIL)
* links to website of SWAP, KNMI and FAO added in documentation

# SWAPtools 0.1.12 (2020-01-17)

* check case-sensitive (set_template and get_value_SWAP)

# SWAPtools 0.1.11 (2020-01-14)

* check if SWAP variable exists (set_template)
* upper boundary for HBOT5 changed

# SWAPtools 0.1.10 (2020-01-10)

* allow multiple date formats (get_value_SWAP)
* set_template and get_value_SWAP case-insensitive 

# SWAPtools 0.1.9 (2020-01-08)

* unit of groundwaterlevel characteristics changed in get_gt (now based on get_gxg)

# SWAPtools 0.1.8 (2020-01-03)

* calculation of model performance
* bug in calculation of GHG

# SWAPtools 0.1.7 (2019-12-23)

* calculation of GxG
* zip SWAP results based on OUTFIL by default

# SWAPtools 0.1.6 (2019-12-10)

* check SQL-query run_info

# SWAPtools 0.1.5 (2019-12-07)

* extract SWAP variable from sql-database based on index, stop in case of failure 

# SWAPtools 0.1.4 (2019-12-02)

* possibility to continue with R-script after SWAP crash

# SWAPtools 0.1.3 (2019-11-27)

* extract SWAP variable from sql-database based on index 

# SWAPtools 0.1.2 (2019-10-24)

* bug in date check on table-variables solved (create_database_SWAP)
* meterological data in a single file
* function created for reading output with specified variables (read_csv_SWAP)

# SWAPtools 0.1.1 (2019-10-24)

* get_value_SQL: convert date-variables to date-class

# SWAPtools 0.1.0 (2019-10-20)

* first version of SWAPtools available at: https://waterwijzerlandbouw.wur.nl/index.html
