module MOD_params
! File VersionID:
!   $Id: params.fi 277 2016-01-28 20:48:55Z kroes006 $
! ----------------------------------------------------------------------
      real(8), parameter   :: nihil  = 1.0d-10
      real(8), parameter   :: tiny   = 1.0d-3
      real(8), parameter   :: small  = 1.0d-6
      real(8), parameter   :: vlarge = 1.0d12
end module MOD_params
