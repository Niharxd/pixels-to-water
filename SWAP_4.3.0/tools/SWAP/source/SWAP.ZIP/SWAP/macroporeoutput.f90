! File VersionID:
!   $Id: macroporeoutput.f90 341 2017-09-29 18:12:25Z kroes006 $
! ----------------------------------------------------------------------
      subroutine MacroPoreOutput(task) 
! ----------------------------------------------------------------------
!     Date               : Aug 2004   
!     Purpose            : open and write macropore output files 
! ----------------------------------------------------------------------
      use MOD_swap_base, only: project, pathwork, iun_min,iun_max
      use MOD_grid,      only: numnod, dz
      use variables,     only: flbaloutput
      use MOD_macropore, only: numdm, ppdmcp, vlmpstcp, vlmpstdm1, vlmpstdm2, swbma, bma

      implicit none
!    global
      integer, intent(in) :: task
!    local
      integer getun, ic, id, mpgeom, i
      real(8) cumdz
      character(len=300) filnam
      character(len=181) filtext
      character(len=1)   comma
      character(len=202) fmt
      character(len=2)   fmt1
! ----------------------------------------------------------------------
      comma = ','

      select case (task)
      case (1)
! --  write geometry of macropores
!      open(unit=3,file='MacroGeom.csv',status='unknown')
      filnam = trim(pathwork)//'MacroGeom.Csv'
      mpgeom = getun (iun_min,iun_max)
      call fopens(mpgeom,filnam,'new','del')
      filtext = 'Macropore geometry: Pp = proportion (-); Vls = '         &
      //'volume static macropores(cm3/cm2). Bot.depth = bottom detpth'  &
      //' compartment (cm).'
      call writehead (mpgeom,1,filnam,filtext,project)
! --  geometry of macropores
      fmt(1:19) = 'Compartm.,Bot.depth'
      do i=1,NumDm
         write(fmt1(1:2),'(i2.2)')i
         fmt(1:i*8+19) = fmt(1:(i-1)*8+19) // ', PpDm'//fmt1
      end do
      fmt(1:NumDm*8+43) = fmt(1:NumDm*8+19)// ', VlsTot,  VlsMB,  VlsIC'
      write(mpgeom,'(a)') trim(fmt)
      cumdz = 0.0d0
      do ic= 1, NumNod
         cumdz = cumdz + dz(ic)
         write(mpgeom,'(I4,a1,F8.4,23(a1,e12.4))')                       &
                        ic,comma,cumdz,(comma,PpDmCp(id,ic),id=1,NumDM),&
                        comma,VlMpStCp(ic),comma,VlMpStDm1(ic),         &
                        comma,VlMpStDm2(ic)
      end do
      close(mpgeom)

! --- output of generated shrinkage characteristics
      call outshrinkchar ()

! --  bma file (macropore output): balance terms macropore water per period
      if (swbma == 1) call outbma(task)

      return

      case (2)

! === write actual data ===============================
! --  bma file (macropore output)
      if (swbma == 1 .AND. flbaloutput) call outbma(task)

      return

      case (3)

! === close output files ================================
      if (swbma == 1) close (bma)

      case default
         call swap_error ('MacroporeOutput', 'Illegal value for TASK')
      end select

      return
      end 

!=======================================================================
      SUBROUTINE OUTBMA(task)
! ----------------------------------------------------------------------
!     date               : 05/8/02
!     purpose            : write macropore balances to outnam.bma file
!     functions called   : -
!     file usage         : 
! ---------------------------------------------------------------------
      use MOD_swap_base, only: project,pathwork, iun_min,iun_max
      use MOD_grid,      only: numnod, dz, z
      use variables,     only: outfil, ioutdat, outdat, tstart, t1900
      use MOD_macropore, only: bma, wasrdm1ini, wasrdm2ini, wasrdm1,wasrdm2, ictopmp, cqmpintopvrtdm1, cqmpintopvrtdm2, cqmpintoplatdm1, cqmpintoplatdm2, cqmpinmtxsatdm1, cqmpinmtxsatdm2, &
                               cqmpinintsatdm1, cqmpinintsatdm2, cqmpoutmtxunsdm1, cqmpoutmtxunsdm2, cqmpoutmtxsatdm1, cqmpoutmtxsatdm2, cqmpoutdrrap

      implicit none

!     global
      integer,          intent(in)     :: task   
      
!    local
      integer   getun
      real(8)   SumInDm1, SumInDm2, SumOutDm1, SumOutDm2
      character(len=300) filnam
      character(len=11)  datbegin,datend
      character(len=80)  filtext
! ----------------------------------------------------------------------
      select case (task)
      case (1)
! --- open output file
      filnam = trim(pathwork)//trim(outfil)//'.bma'
      bma = getun (iun_min,iun_max)
      call fopens(bma,filnam,'new','del')
      filtext='overview of macropore water balance components (cm)'
      call writehead (bma,1,filnam,filtext,project)

      return

      case (2)
! --- begin date of balance period
      if (ioutdat == 2) then
        call dtdpst ('year-month-day',tstart,datbegin)
      else
        call dtdpst ('year-month-day',outdat(ioutdat-2)+1.1d0,datbegin)
      end if

! --- end date of sub-run
      call dtdpst ('year-month-day',t1900+0.1d0,datend)

!c --- write output record
      write (bma,20) datbegin,datend
      write (bma,22) (-z(numnod) + 0.5d0*dz(numnod))
      write (bma,40)      
      write (bma,41) WaSrDm1Ini, WaSrDm2Ini, WaSrDm1Ini + WaSrDm2Ini,   &
                     WaSrDm1, WaSrDm2, WaSrDm1 + WaSrDm2
      if (IcTopMp == 1) then
         write (bma,42) CQMpInTopVrtDm1, CQMpInTopVrtDm2,               &
                     CQMpInTopVrtDm1 + CQMpInTopVrtDm2, CQMpInTopLatDm1,&
                     CQMpInTopLatDm2, CQMpInTopLatDm1 + CQMpInTopLatDm2
      else
         write (bma,421) CQMpInTopVrtDm1, CQMpInTopVrtDm2,              &
                     CQMpInTopVrtDm1 + CQMpInTopVrtDm2
      end if
!   correct CQMpInMtxDm1 and 2 with CQMpInTopVrtDm1 and 2
      if (IcTopMp > 1) then
         CQMpInMtxSatDm1 = CQMpInMtxSatDm1 - CQMpInTopVrtDm1
         CQMpInMtxSatDm2 = CQMpInMtxSatDm2 - CQMpInTopVrtDm2
      end if
      write (bma,43) CQMpInIntSatDm1, CQMpInIntSatDm2, CQMpInIntSatDm1 +&
                     CQMpInIntSatDm2, CQMpOutMtxUnsDm1,CQMpOutMtxUnsDm2,&
                     CQMpOutMtxUnsDm1 + CQMpOutMtxUnsDm2,               &
                     CQMpInMtxSatDm1, CQMpInMtxSatDm2,                  &
                     CQMpInMtxSatDm1 + CQMpInMtxSatDm2,                 &
                     CQMpOutMtxSatDm1,CQMpOutMtxSatDm2,                 &
                     CQMpOutMtxSatDm1 + CQMpOutMtxSatDm2
      write (bma,44) CQMpOutDrRap, CQMpOutDrRap


!      if (nrlevs >= 1) then 
!        write (bma,55)
!        do ilev=1,nrlevs
!          write (bma,56) ilev, cqdrainin(ilev), ilev, cqdrainout(ilev)
!        end do
!      end if
!      write (bma,61) cqbotup,cqbotdo
!      write (bma,62) ssnow,volact 
      SumInDm1= WaSrDm1Ini + CQMpInTopVrtDm1 + CQMpInTopLatDm1 +        &
                CQMpInIntSatDm1 + CQMpInMtxSatDm1 
      SumInDm2= WaSrDm2Ini + CQMpInTopVrtDm2 + CQMpInTopLatDm2 +        &
                CQMpInIntSatDm2 + CQMpInMtxSatDm2
!      if (IcTopMp > 1) then
!         SumInDm1= SumInDm1 - CQMpInTopVrtDm1
!         SumInDm2= SumInDm2 - CQMpInTopVrtDm2
!      end if

      SumOutDm1= WaSrDm1 + CQMpOutMtxSatDm1 + CQMpOutMtxUnsDm1 +        &
                 CQMpOutDrRap
      SumOutDm2= WaSrDm2 + CQMpOutMtxSatDm2 + CQMpOutMtxUnsDm2
! --- sum
      write (bma,45) SumInDm1, SumInDm2, SumInDm1 + SumInDm2,           &
                     SumOutDm1, SumOutDm2, SumOutDm1 + SumOutDm2
      write (bma,46) WaSrDm1-WaSrDm1Ini, WaSrDm2-WaSrDm2Ini,            &
                     WaSrDm1-WaSrDm1Ini + WaSrDm2-WaSrDm2Ini
      write (bma,47) SumOutDm1-SumInDm1, SumOutDm2-SumInDm2,            &
                     SumOutDm1-SumInDm1 + SumOutDm2-SumInDm2

 20   format(/'Period',t20,':',t23,a11,' until  ',a11)
 22   format('Depth soil profile',t20,':',f8.2,' cm')
 40   format(48('='),'+',50('='),/,'INPUT',t22,'MAIN     INTERN.  TOTAL'&
      ,t49,'|',t52,'OUTPUT',t73,'MAIN     INTERN.  TOTAL',/,t22,        &
      'BYPASS   CATCHM.  MACROP.',t49,'|',t73,                          &
      'BYPASS   CATCHM.  MACROP.',/,48('='),'+',50('='))
 41   format('Initially Present',t19,3f9.2,t49,'|',t52,'Finally present'&
      ,t70,3f9.2,/,t49,'|')
 42   format('Inflow top:',t49,'|',/,'- direct precipit.',t19,3f9.2,    &
             t49,'|',/,'- overland flow',t19,3f9.2,t49,'|')
421   format('Inflow top:',t49,'|',/,'- from saturated',t19,3f9.2,      &
             t49,'|',/,'  matrix layer on top ',t49,'|',/)
 43   format('Exfiltration matrix:',t49,'|',t52,'Infiltration matrix:',/&
      ,'- interflow',t20,f8.2,2f9.2,t49,'|',t52,'- unsaturated',        &
      t71,f8.2,2f9.2,/,'- saturated',t20,f8.2,2f9.2,t49,'|',t52,        &
      '- saturated',t71,f8.2,2f9.2)
 44   format(t49,'|',t52,'Rapid drainage',t70,f9.2,9x,f9.2,/,           &
      48('='),'+',50('='))
 45   format('Sum',t19,3f9.2,t49,'|',t52,'Sum',t70,3f9.2,/,48('='),'+', &
      50('='))
 46   format('Storage Change',t19,3f9.2)
 47   format('Balance Deviation',t19,3f9.2,/,99('='),/)
  
      case default
         call swap_error ('outbma', 'Illegal value for TASK')
      end select

      return
      end

! ----------------------------------------------------------------------
      subroutine outshrinkchar ()
! ----------------------------------------------------------------------
!     date               : April 2008
!     purpose            : Output of shrinkage characteristics as generated 
!                          on basis of input parameters
! ---------------------------------------------------------------------
! --- global
      use MOD_swap_base, only: project, pathwork, iun_min,iun_max
      use MOD_grid,      only: numlay
      use variables,     only: thetsl
      use MOD_macropore, only: swsoilshr, SHRINK

      implicit none 

! --- local variables ------------------
      character(len=300) filnam
      character(len=80)  filtext
      character(len=1)   comma
      integer   getun,shr,lay,i
      real(8)   MoisR, Thet, VlSolidRel, VoidR, VRhlp
! ---------------------------------------------------------------------
      comma = ',' 

! === open output file =================================================
      filnam = trim(pathwork)//'SoilShrinkChar.csv'
      shr = getun (iun_min,iun_max)
      call fopens(shr,filnam,'new','del')
      filtext = 'soil shrinkage characteristics'
      call writehead (shr,1,filnam,filtext,project)

! --- write header
      write(shr,'(a)') 'layer,Moist Ratio (-),Void Ratio (-)'

! --- generate and write shrink characteristics for each soil layer
      do lay = 1,numlay
         if (SwSoilShr(lay) /= 0) then
            VlSolidRel= 1.d0 - Thetsl(lay)
            MoisR = 0.d0            
            do i = 1, 101
               Thet =  MoisR * (1.d0-Thetsl(lay))
               VRhlp = SHRINK(lay, thet)
               VoidR = (Thetsl(lay) - VRhlp) / VlSolidRel
               write (shr,22) lay, comma, MoisR, comma, VoidR
 22            format(i10,2(a,f9.4))
!
               MoisR = MoisR + Thetsl(lay) / (1.d0-Thetsl(lay)) / 100.d0
            end do
         end if
      end do

! --- close soil shrinkage characteristics file
      close (shr)

      return
      end


