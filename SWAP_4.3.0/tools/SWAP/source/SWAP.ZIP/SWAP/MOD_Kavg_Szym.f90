module MOD_Kavg_Szym

use MOD_grid, only: numnod, dz, layer

! local variables
integer, save :: iLogh81
integer, save :: numh
real(8), dimension(:), allocatable, save :: hvalues
real(8), dimension(:,:,:), allocatable, save :: K_Szym

private

public :: sub_Kavg_Szym 

   contains

   ! ---------------------------------------------------------------------    
   
   subroutine sub_Kavg_Szym(iTask, iboundary, htop, hbot, K_avg_Szym)

      implicit none

      ! global
      integer, intent(in)                          :: iTask, iboundary
      real(8), intent(in)                          :: htop, hbot
      real(8), intent(out)                         :: K_avg_Szym

      ! local
      integer                                      :: iprof

      ! ------------------------------------------------------------------
      
      select case(iTask)
   
      case(1)

         iprof = 1 ! during test phase
         call Kavg_Szym_read_table(iprof, numnod, dz, layer)

      case(2)

         K_avg_Szym = bilinear(iboundary+1, htop, hbot)

      case default

         call swap_error('Kavg_Szym', 'Illegal iTask value')

      end select

   end subroutine sub_Kavg_Szym

   ! ---------------------------------------------------------------------
   
   function bilinear(ib, x0, y0)

      ! source: Numerical Recipes, Eq. (3.6.3)-(3.6.5)

      implicit none

      ! global
      integer, intent(in) :: ib
      real(8), intent(in) :: x0, y0
      real(8) :: bilinear

      ! local
      integer :: j1, j2, j11, j21
      real(8) :: t, u, t1, u1

      ! ------------------------------------------------------------------
      
      if (iLogh81 == 1) then
         if (x0 > 0.0d0) then
            j1 = 1
         else if (x0 > -1.0d0) then
            j1 = 1 + floor(-10.0d0 * x0)
         else 
            j1 = 11 + floor(10.0d0*log10(-x0))
         end if
         if (y0 > 0.0d0) then
            j2 = 1
         else if (y0 > -1.0d0) then
            j2 = 1 + floor(-10.0d0 * y0)
         else 
            j2 = 11 + floor(10.0d0*log10(-y0))
         end if
      else
         call locate(hvalues, numh, x0, j1)
         call locate(hvalues, numh, y0, j2)
      end if

      if (j1 == 0) j1 = 1; if (j1 >= numh) j1 = numh - 1
      if (j2 == 0) j2 = 1; if (j2 >= numh) j2 = numh - 1

      ! bi-linear interpolation
      j11 = j1 + 1
      j21 = j2 + 1
      t   = (x0 - hvalues(j1)) / (hvalues(j11) - hvalues(j1))
      u   = (y0 - hvalues(j2)) / (hvalues(j21) - hvalues(j2))
      u1  = 1.0d0 - u
      t1  = 1.0d0 - t
      bilinear = t1 * u1 * K_Szym(ib, j1,  j2)  + &
           t  * u1 * K_Szym(ib, j11, j2)  + &
           t  * u  * K_Szym(ib, j11, j21) + &
           t1 * u  * K_Szym(ib, j1,  j21)

   end function bilinear

   ! ---------------------------------------------------------------------
      
   subroutine locate(xx,n,x,j)
      
      implicit none
      ! global
      integer, intent(in)  :: n
      integer, intent(out) :: j
      real(8), intent(in)  :: x, xx(n)
      ! local
      integer              :: jl, jm, ju

      ! ------------------------------------------------------------------
      
      jl = 0
      ju = n + 1
10    if (ju - jl > 1)then
        jm = (ju+jl) / 2
        if ((xx(n) >= xx(1)) .eqv. (x >= xx(jm)))then
          jl = jm
        else
          ju = jm
        end if
      goto 10
      end if
      
      if (x <= xx(1)) then
        j = 1
      else if (x >= xx(n)) then
        j = n - 1
      else
        j = jl
      end if

      return

   end subroutine locate
   
   ! ---------------------------------------------------------------------

   subroutine Kavg_Szym_read_table(iprof, numnod, dz, layer)
      
      ! ------------------------------------------------------------------
      
      implicit none

      ! global

      integer, intent(in) :: iprof, numnod
      integer, dimension(numnod), intent(in) :: layer
      real(8), dimension(numnod), intent(in) :: dz

      ! local

      integer :: i, i1, i2, iProfile, NumSoFy, NumComp
      integer, dimension(:), allocatable :: iSoFy_in
      real(8), dimension(:), allocatable :: dzs
      character(len=4) :: cprof, cnumnod
      character(len=80) :: inputfile
      
      ! ------------------------------------------------------------------

      write(cprof,   '(i4.4)') iprof
      write(cnumnod, '(i4.4)') numnod
      inputfile = 'Kavg_Szymkiewicz_' // cprof // "_" // cnumnod // '.unf'

      open(unit=3, file=inputfile, status='unknown', form='unformatted')
      read(3) iProfile, NumSoFy, numcomp, numh, iLogh81

      allocate(iSoFy_in(numcomp))
      allocate(dzs(numcomp))
      read(3) (iSoFy_in(i), i = 1, numcomp)
      read(3) (dzs(i),      i = 1, numcomp)

      allocate(hvalues(numh))
      read(3) (hvalues(i),  i = 1, numh)

      allocate(K_Szym(numcomp+1,numh,numh))
      read(3) (((K_Szym(i,i1,i2), i2 = 1, numh), i1 = 1, numh), i = 1, numcomp+1)
      close(unit=3)

      ! checks
      if (numcomp /= numnod) call swap_error('Kavg_Szym_read_table', 'NumComp /= numnod')
      if (iProfile /= iprof) call swap_error('Kavg_Szym_read_table', 'iProfile /= iprof')
      if (NumSoFy /= layer(numnod)) call swap_error('Kavg_Szym_read_table', 'NumSoFy /= layer(numnod)')
      do i = 1, numnod
         if (dabs(dz(i) - dzs(i)) > 1.0d-6) call swap_error('Kavg_Szym_read_table', 'dz(i) /= dzs(i)')
         if (layer(i) /= iSoFy_in(i)) call swap_error('Kavg_Szym_read_table', 'layer(i) /= iSoFy_in(i)')
      end do
      deallocate(iSoFy_in)
      deallocate(dzs)

   end subroutine Kavg_Szym_read_table

end module MOD_Kavg_Szym
