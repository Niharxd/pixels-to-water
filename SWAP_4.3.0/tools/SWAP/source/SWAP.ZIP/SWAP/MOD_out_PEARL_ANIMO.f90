module MOD_out_PEARL_ANIMO

   use MOD_swap_base,         only: project, pathwork, swrain
   use MOD_SoilTemperature,   only: tsoil

   use MOD_grid,              only: numnod, dz, numlay, botcom, nod1lay
   use MOD_meteo,             only: meteo_rec, etr, hum, tmn, tmx, wet, win
   use atmosphere_interface,  only: tav, rad
   use plant_interface,       only: cf, lai, vcover, rd, sicact
   use MOD_snow,              only: Ssnow
   use MOD_drain,             only: nrlevs
   use MOD_swap_mp,           only: WalevDm1,VlMpDm1,WaSrDm1,VlMpDm2,WaSrDm2,IQInTopVrtDm1,IQInTopLatDm1,IQInTopVrtDm2,IQInTopLatDm2,IcTopMp,swmbf,WaUnMpDm1Cp,WaUnMpDm2Cp
   use variables,             only: outfil,outper,period,pond,gwl,thetas,swafo,swaun,tstart,tend,t1900,CritDevMasBal!,wbalance
   use SWAP_csv_output,       only: swdiscrvert,numnodnew,dznew
   
   ! additional for ConvertDiscrVert
   use MOD_integral,          only: inqrot, inq, iruno, irunon, iintc,igSnow,isnrai,iSubl,igird,inird,inqdra,iepd,ievap,igrai,inrai,ipeva,iptra,iqssdi,iqdra, &
                                    iqrot, iqbdo, iqbup
   use MOD_MvG,               only: cofgen
   use MOD_swap_mp,           only: vlmpstdm1, vlmpstdm2, dipocp, iqexcmtxdm1cp, iqexcmtxdm2cp,iavfrmpwlwtdm1, iavfrmpwlwtdm2, iqoutdrrapcp, frarmtrx, iqtopmpdm1cp, iqtopmpdm2cp,iqmpoutdrrap
   use variables,             only: h, theta, volact, ipondbeg, ithetabeg, issnowbeg, ivolbeg, isicbeg
   ! additional for CheckMassbal
   use MOD_swap_mp,           only: IWaSrDm1Beg,IWaSrDm2Beg,iWaUnDm1CpBeg,iWaUnDm2CpBeg
   use variables,             only: DayCum,t
   
   implicit none
   
! local
   integer                                :: ftype, lay, node, level
   integer                                :: aun, afo                   ! unit numbers for output files
   ! some time information
   integer                                :: bruny, eruny, brund, erund
   integer, dimension(6)                  :: datea
   real(4)                                :: fsec
   real(8)                                :: timjan1
   real(8)                                :: wbalance, dstor
   ! several SWAP state and rate variables will be computed for a new discretization (numnodnew, dznew) of the soil profile
   integer, dimension(:),   allocatable, save   :: botcomNew
   real(8), dimension(:),   allocatable, save   :: hNew
   real(8), dimension(:),   allocatable, save   :: thetaNew
   real(8), dimension(:),   allocatable, save   :: inqNew
   real(8), dimension(:,:), allocatable, save   :: inqdraNew
   real(8), dimension(:),   allocatable, save   :: inqrotNew
   real(8), dimension(:),   allocatable, save   :: TsoilNew
   real(8), dimension(:),   allocatable, save   :: tsoili         ! local copy of tsoil
   ! idem, 'new' macropore variables
   real(8), dimension(:),   allocatable, save   :: DiPoCpNew
   real(8), dimension(:),   allocatable, save   :: IAvFrMpWlWtDm1New, IAvFrMpWlWtDm2New
   real(8), dimension(:),   allocatable, save   :: IQExcMtxDm1CpNew, IQExcMtxDm2CpNew
   real(8), dimension(:),   allocatable, save   :: IQTopMpDm1CpNew, IQTopMpDm2CpNew
   real(8), dimension(:),   allocatable, save   :: IQOutDrRapCpNew
   real(8), dimension(:),   allocatable, save   :: WaUnMpDm1CpNew, IWaUnDm1CpBegNew
   real(8), dimension(:),   allocatable, save   :: WaUnMpDm2CpNew, IWaUnDm2CpBegNew
   real(8), dimension(:),   allocatable, save   :: IThetaBegNew
   real(8), dimension(:),   allocatable, save   :: VlMpStDm1New, VlMpStDm2New
   real(8)                                :: TopQprecDm1, TopQsoilDm1, TopQprecDm2, TopQsoilDm2
   ! temporary dummy
   real(8), dimension(:),   allocatable   :: dval
   
   character(len=80)                      :: filtext
   character(len=300)                     :: filnam
   character(len=4)                       :: afoext, aunext
   logical                                :: FlOpenFileDev        ! flag indicating whether (.TRUE.) or not (.FALSE.) the file "xxxxx.dwb.csv" is open
!  save local variables
   save      brund, aun, afo, FlOpenFileDev

   !private
   !public :: out_PEARL_ANIMO

contains

   subroutine out_PEARL_ANIMO (task)
   implicit none
   ! global
   integer, intent(in) :: task

   if (task == 1) then

      call dtdpar (tstart, datea, fsec)
      bruny    = datea(1)
      datea(2) = 1
      datea(3) = 1
      fsec     = 0.0
      call dtardp (datea, fsec, timjan1)
      brund = nint (tstart - timjan1 + 1.0d0)
      call dtdpar (tend, datea, fsec)
      eruny    = datea(1)
      datea(2) = 1
      datea(3) = 1
      fsec     = 0.0
      call dtardp (datea, fsec, timjan1)
      erund = nint (tend - timjan1 + 1.0d0)

      if (SwDiscrVert == 0) numnodNew = numnod

      if (allocated(botcomNew))         deallocate(botcomNew);         allocate(botcomNew(1:numlay));                  botcomNew = 0
      if (allocated(dval))              deallocate(dval);              allocate(dval(1:numlay));                       dval = 0.d0
      if (allocated(tsoili))            deallocate(tsoili);            allocate(tsoili(0:numnod));                     tsoili = 0.d0
      if (allocated(TsoilNew))          deallocate(TsoilNew);          allocate(TsoilNew(0:numnodnew));                TsoilNew = 0.d0
      if (allocated(hNew))              deallocate(hNew);              allocate(hNew(1:numnodnew));                    hNew = 0.d0
      if (allocated(inqNew))            deallocate(inqNew);            allocate(inqNew(1:(numnodnew+1)));              inqNew = 0.d0
      if (allocated(thetaNew))          deallocate(thetaNew);          allocate(thetaNew(1:numnodnew));                thetaNew = 0.d0
      if (allocated(inqrotNew))         deallocate(inqrotNew);         allocate(inqrotNew(1:numnodnew));               inqrotNew = 0.d0
      if (allocated(DiPoCpNew))         deallocate(DiPoCpNew);         allocate(DiPoCpNew(1:numnodnew));               DiPoCpNew = 0.d0
      if (allocated(IAvFrMpWlWtDm1New)) deallocate(IAvFrMpWlWtDm1New); allocate(IAvFrMpWlWtDm1New(1:numnodnew));       IAvFrMpWlWtDm1New = 0.d0
      if (allocated(IAvFrMpWlWtDm2New)) deallocate(IAvFrMpWlWtDm2New); allocate(IAvFrMpWlWtDm2New(1:numnodnew));       IAvFrMpWlWtDm2New = 0.d0
      if (allocated(IQExcMtxDm1CpNew))  deallocate(IQExcMtxDm1CpNew);  allocate(IQExcMtxDm1CpNew(1:numnodnew));        IQExcMtxDm1CpNew = 0.d0
      if (allocated(IQExcMtxDm2CpNew))  deallocate(IQExcMtxDm2CpNew);  allocate(IQExcMtxDm2CpNew(1:numnodnew));        IQExcMtxDm2CpNew = 0.d0
      if (allocated(IQTopMpDm1CpNew))   deallocate(IQTopMpDm1CpNew);   allocate(IQTopMpDm1CpNew(1:numnodnew+1));       IQTopMpDm1CpNew = 0.d0
      if (allocated(IQTopMpDm2CpNew))   deallocate(IQTopMpDm2CpNew);   allocate(IQTopMpDm2CpNew(1:numnodnew+1));       IQTopMpDm2CpNew = 0.d0
      if (allocated(IQOutDrRapCpNew))   deallocate(IQOutDrRapCpNew);   allocate(IQOutDrRapCpNew(1:numnodnew));         IQOutDrRapCpNew = 0.d0
      if (allocated(IThetaBegNew))      deallocate(IThetaBegNew);      allocate(IThetaBegNew(1:numnodnew));            IThetaBegNew = 0.d0
      if (allocated(VlMpStDm1New))      deallocate(VlMpStDm1New);      allocate(VlMpStDm1New(1:numnodnew));            VlMpStDm1New = 0.d0
      if (allocated(VlMpStDm2New))      deallocate(VlMpStDm2New);      allocate(VlMpStDm2New(1:numnodnew));            VlMpStDm2New = 0.d0
      if (allocated(WaUnMpDm1CpNew))    deallocate(WaUnMpDm1CpNew);    allocate(WaUnMpDm1CpNew(1:numnodnew));          WaUnMpDm1CpNew = 0.d0
      if (allocated(IWaUnDm1CpBegNew))  deallocate(IWaUnDm1CpBegNew);  allocate(IWaUnDm1CpBegNew(1:numnodnew));        IWaUnDm1CpBegNew = 0.d0
      if (allocated(WaUnMpDm2CpNew))    deallocate(WaUnMpDm2CpNew);    allocate(WaUnMpDm2CpNew(1:numnodnew));          WaUnMpDm2CpNew = 0.d0
      if (allocated(IWaUnDm2CpBegNew))  deallocate(IWaUnDm2CpBegNew);  allocate(IWaUnDm2CpBegNew(1:numnodnew));        IWaUnDm2CpBegNew = 0.d0
      if (allocated(inqdraNew))         deallocate(inqdraNew);         allocate(inqdraNew(max(nrlevs,1),1:numnodnew)); inqdraNew = 0.d0

   end if

   if (task == 4) then
      if (swafo > 0) close (afo)
      if (swaun > 0) close (aun)
      return
   end if
   
   dstor        = (volact + pond + ssnow + sicact + wasrdm1 + wasrdm2) -                     & 
                  (ivolbeg + ipondbeg + issnowbeg + isicbeg + iwasrdm1beg + iwasrdm2beg)
   wbalance     = (igrai+isnrai+igsnow+igird+irunon + iqssdi + iqbup) - dstor -              &
                  (iintc+iruno+iqrot+iepd+ievap+isubl+iqdra+iQMpOutDrRap+iqbdo)

   if (swafo > 0) call out_afo(task)
   if (swaun > 0) call out_aun(task)

   end subroutine out_PEARL_ANIMO

   subroutine out_afo (task)
! ----------------------------------------------------------------------------------------------------
!     Date               : 29-oct-2022; update 01-11-2022
!     Purpose            : ANIMO/PEARL output: formatted hydrological data
! ----------------------------------------------------------------------------------------------------
! ----------------------------------------------------------------------
   use MOD_swap_base, only: swmacro, iun_min, iun_max
   use MOD_MvG, only: watcon
   implicit none
   ! global
   integer, intent(in) :: task
   ! local: functions
   integer :: getun
   integer, save :: swop
   real(8) :: out_wet

   select case (task)
   case (1)

! === initial output ====================================================

! -   verify reduced grid for output
      if (SwDiscrvert == 1) call checkDiscrVert()

! -   set switch Swop
      Swop = 1

! -   BFO and CFO file for PEARL
      if (swafo >= 2 .AND. swmacro == 1) Swop = 2

! -   convert vertical discretization: initial values
      tsoili(1:numnod) = tsoil(1:numnod)

      call convertdiscrvert(1,swop)

! -   open file
      if (swafo == 1) then
         afoext = '.afo'
      else if (swafo == 2) then
         afoext = '.bfo'
      else if (swafo == 3) then
         afoext = '.cfo'
      end if
      filnam = trim(pathwork)//trim(outfil)//afoext
      afo = getun (iun_min, iun_max)
      call fopens(afo,filnam,'new','del')

! ---   write initial part
      if (swafo >= 2) then
         ftype = 1
         if (swafo == 2) then
            filtext = 'formatted hydrological data; BFO version'
         else if (swafo == 3) then
            filtext = 'formatted hydrological data; CFO version'
         end if
         call writehead(afo,ftype,filnam,filtext,project)
      end if

      if (swafo == 1) then
         write (afo,'(2(1x,i8),3(1x,f8.0),1x,i8)') bruny, eruny, real(brund-1), real(erund), real(period)
      else if (swafo >= 2) then
         write (afo,'(1x,i8)') swop
         write (afo,'(2(1x,i8),3(1x,f8.0),1x,i8)') bruny, eruny, real(brund-1), real(erund)
      end if

      write (afo,'(5(1x,i8))') numnodNew, numlay, nrlevs
      write (afo,'(5(1x,i8))') (botcomNew(lay), lay=1,numlay)
!  -    ThetaS should be known for new soil layers; this works but is not very nice
      write (afo,'(8(1x,f10.6))') (real(thetas(botcom(lay))), lay=1,numlay)

      do lay = 1, numlay
         dval(lay) = watcon(nod1lay(lay), -100.d0)
      end do
      write (afo,'(8(1x,f10.6))') (real(dval(lay)), lay=1,numlay)

      do lay = 1,numlay
         dval(lay) = watcon(nod1lay(lay), -15849.0d0)
      end do
      write (afo,'(8(1x,f10.6))') (real(dval(lay)), lay=1,numlay)

      write (afo,'(8(1x,f10.6))') (0.01*real(dzNew(node)), node=1,numnodNew)

      if (swafo >= 2 .AND. swop == 2) then
         write (afo,'(8(1x,f10.6))') (0.01*real(VlMpStDm1New(node)), node=1,numnodNew)
         write (afo,'(8(1x,f10.6))') (0.01*real(VlMpStDm2New(node)), node=1,numnodNew)
         write (afo,'(8(1x,f10.6))') (0.01*real(DiPoCpNew(node)),    node=1,numnodNew)
      end if

      write (afo,'(8(1x,f10.6))') (real(thetaNew(node)), node=1,numnodNew)
      write (afo,'(8(1x,f10.6))') -0.01*real(gwl), 0.01*real(pond)

      if (swafo >= 2) then
         write (afo,'(8(1x,f10.6))') 0.01*real(Ssnow)
         write (afo,'(8(1x,f10.6))') (real(tsoilNew(node)), node = 1,numnodNew)
      end if

      if (swafo >= 2 .AND. swop == 2) then
         write (afo,'(8(1x,f10.6))') -0.01*real(WaLevDm1), 0.01*real(VlMpDm1), 0.01*real(WaSrDm1), 0.01*real(VlMpDm2), 0.01*real(WaSrDm2)
         if (swmbf == 2) then
            write (afo,'(8(1x,f10.6))') (0.01*real(WaUnMpDm1CpNew(node)), node=1,numnodNew)
         end if
      end if

      FlOpenFileDev = .FALSE.

   case (2)

! === output during simulation ===============================================

      if (swrain == 2) then
         out_wet = wet(meteo_rec)
      else
         out_wet = -1.0d0
      end if
       
! -     convert vertical discretization: dynamic part
      tsoili(1:numnod) = tsoil(1:numnod)

      call ConvertDiscrVert(2,swop)

      if (swafo == 1) then
          write (afo,'(1x,f6.0,7(1x,f9.6),3(1x,f7.4))') real(t1900-tstart),     &
          0.01*real((igrai+igird)/outper),                              &
          0.01*real(iintc/outper),                                      &
          0.01*real((ievap+iepd)/outper),                               &
          0.0,                                                          &
          0.01*real(ipeva/outper),0.01*real(iptra/outper),              &
          0.01*real(iruno/outper),                                      &
          -0.01*real(gwl),0.01*real(pond)
      else if (swafo >= 2) then
!          write (afo,*) real(t), real(outper),
          write (afo,'(1(1x,f12.6),12(1x,f9.6),4(1x,f9.4))')            &
              (brund*1.0d0-1.0d0+(t1900-tstart)), real(outper),         &
              0.01*real((igrai+isnrai)/outper),                         &
              0.01*real(igsnow/outper),                                 &
              0.01*real(igird/outper),                                  &
              0.01*real( (iintc-(igird-inird))/outper ),                &
              0.01*real( (igird-inird)/outper ),                        &
              0.01*real(isubl/outper),                                  &
              0.01*real((ievap+iepd)/outper),                           &
              0.0,                                                      &
              0.01*real(ipeva/outper),                                  &
              0.01*real(iptra/outper),                                  &
              0.01*real(irunon/outper),                                 &
              0.01*real(iruno/outper),                                  &
              -0.01*real(gwl), 0.01*real(pond),                         &
              0.01*real(ssnow), 0.01*real(wbalance)
      end if
      write (afo,'(8(1x,e10.3e2))') (real(hNew(node)),                  node=1,numnodNew)
      write (afo,'(10(1x,f9.6))')   (real(thetaNew(node)),              node=1,numnodNew)
      write (afo,'(10(1x,f9.6))')   (0.01*real(inqrotNew(node)/outper), node=1,numnodNew)
      write (afo,'(10(1x,f9.6))')   (-0.01*real(inqNew(node)/outper),   node=1,numnodNew+1)
      if (nrlevs > 0) then
         do level = 1,nrlevs
            write (afo,'(10(1x,f9.6))') (0.01*real(inqdraNew(level,node)/outper), node=1,numnodNew)
         end do
      end if
      if (swafo >= 2) then
!ckro-20141112   exponential relation between soil cover and lai
         write (afo,'(4(1x,f10.4))') real(vcover), real(lai), abs(real(0.01d0*rd)), real(cf)
! -   CFO file for PEARL
         if (swafo == 2) then
            write (afo,'(1x,f7.2)') real(tav)
         else if (swafo == 3) then
! -   if swafo = 3, CFO file with extra output concerning meteo:
!     RAD(kJ.m-2), Tmin(grC), Tmax(grC), HUM(kPA), WIND(m.s-1), ETref (m.d-1), WET (d) and missing values voor WET: -1.0 if SWRAIN =/= 2
            write (afo,'(3x,f8.1,f9.2,2(2x,f9.2),f9.2,3x,2(3x,f8.5))') real(rad), real(tmn), real(tmx), real(hum), real(win), real(etr)*0.001, real(out_wet)
         end if
         write (afo,'(8(1x,f10.6))') (real(tsoilNew(node)), node=1,numnodNew)
      end if

      if (swafo >= 2 .AND. swop == 2) then

         if (IcTopMp /= 1) then              ! adaptation for GEM; covering lay on top of macropores:
            TopQsoilDm1 = IQInTopVrtDm1      ! request to put inflow into macropores from covering top layer
            TopQprecDm1 = 0.0d0              ! in variables IQInTopLatDm1 and IQInTopLatDm2 (the fluxes that contain pesticides in PEARL);
            TopQsoilDm2 = IQInTopVrtDm2      ! for calculations of macropore fluxes this inflow is in variables
            TopQprecDm2 = 0.0d0              ! IQInTopVrtDm1 and IQInTopVrtDm2
         else
            TopQprecDm1 = IQInTopVrtDm1
            TopQsoilDm1 = IQInTopLatDm1
            TopQprecDm2 = IQInTopVrtDm2
            TopQsoilDm2 = IQInTopLatDm2
         end if

         write (afo,'(8(1x,f10.6))') -0.01*real(WaLevDm1), 0.01*real(VlMpDm1), 0.01*real(WaSrDm1), 0.01*real(TopQprecDm1/outper), 0.01*real(TopQsoilDm1/outper)
         write (afo,'(8(1x,f10.6))') (0.01*real(IQExcMtxDm1CpNew(node)/outper), node=1,numnodNew)
         write (afo,'(8(1x,f10.6))') (0.01*real(IQOutDrRapCpNew(node)/outper), node=1,numnodNew)
         if (swmbf == 2) then
            write (afo,'(8(1x,f10.6))') (0.01*real(IQTopMpDm1CpNew(node)/outper), node=1,numnodNew) 
            write (afo,'(8(1x,f10.6))') (0.01*real(WaUnMpDm1CpNew(node)), node=1,numnodNew)
         end if
         write (afo,'(8(1x,f10.6))') (real(IAvFrMpWlWtDm1New(node)/outper), node=1,numnodNew)
         write (afo,'(8(1x,f10.6))') 0.01*real(VlMpDm2), 0.01*real(WaSrDm2), 0.01*real(TopQprecDm2/outper), 0.01*real(TopQsoilDm2/outper)
         write (afo,'(8(1x,f10.6))') (0.01*real(IQExcMtxDm2CpNew(node)/outper), node=1,numnodNew)
         write (afo,'(8(1x,f10.6))') (real(IAvFrMpWlWtDm2New(node)/outper), node=1,numnodNew)
      end if

      if (swafo >= 2 .AND. CritDevMasBal > 1.d-30) then
! --- Checking of mass balances of sub systems per period OutPer
         call checkmassbal (flopenfiledev)
      end if

   case default
      call swap_error ('outafo', 'Illegal value for Task')
   end select

   return
   end subroutine out_afo

! ----------------------------------------------------------------------
   subroutine out_aun (task)
! ----------------------------------------------------------------------
!     Date               : 29-jan-2003; update 01-11-2022
!     Purpose            : ANIMO/PEARL output: unformatted hydrological data
! ---------------------------------------------------------------------
   use MOD_swap_base, only: swmacro, iun_min, iun_max
   use MOD_MvG, only: watcon
   implicit none
   ! global
   integer, intent(in) :: task
   ! local: functions
   integer :: getun
   integer, save :: swop

! ----------------------------------------------------------------------

   select case (task)
   case (1)

! === output initial condition ==========================================

! -   verify reduced grid for output
      if (SwDiscrvert == 1) then
         call checkDiscrVert()
      end if

! -   set switch Swop
      Swop = 1
      if (Swaun == 2 .AND. swmacro == 1) Swop = 2

! -     convert vertical discretization: initial values
      tsoili(1:numnod) = tsoil(1:numnod)

      call convertdiscrvert(1,swop)

! -   open file
      if (swaun == 1) then
        aunext = '.aun'
      else if (swaun == 2) then
        aunext = '.bun'
      end if
      filnam = trim(pathwork)//trim(outfil)//aunext
      aun = getun (iun_min, iun_max)
      open(unit = aun, file = filnam, status = 'unknown', form = 'unformatted')
      
! --- write initial part
      if (swaun == 2) then
          ftype = 2
          filtext = 'unformatted hydrological data'
          call writehead(aun,ftype,filnam,filtext,project)
      end if
      
      if (swaun == 1) then
        write (aun) bruny,eruny, real(brund-1),real(erund),real(period)
      else if (swaun == 2) then
        write (aun) swop
        write (aun) bruny,eruny,real(brund-1),real(erund)
      end if

      write (aun) numnodNew,numlay,nrlevs
      write (aun) (botcomNew(lay),lay=1,numlay)
!  -  ThetaS should be known for new soil layers; this works but is not very nice
      write (aun) (real(thetas(botcom(lay))), lay=1,numlay)

      do lay = 1, numlay
         dval(lay) = watcon(nod1lay(lay),-100.d0)
      end do
      write (aun) (real(dval(lay)),lay=1,numlay)

      do lay = 1,numlay
         dval(lay) = watcon(nod1lay(lay),-15849.0d0)
      end do
      write (aun) (real(dval(lay)),lay=1,numlay)

      write (aun) (0.01*real(dzNew(node)), node=1,numnodNew)

      if (swaun == 2 .AND. swop == 2) then
        write (aun) (0.01*real(VlMpStDm1New(node)), node=1,numnodNew)
        write (aun) (0.01*real(VlMpStDm2New(node)), node=1,numnodNew)
        write (aun) (0.01*real(DiPoCpNew(node)),    node=1,numnodNew)
      end if

      write (aun) (real(thetaNew(node)), node=1,numnodNew)
      write (aun) -0.01*real(gwl),0.01*real(pond)

      if (swaun == 2) then
        write (aun) 0.01*real(Ssnow)
        write (aun) (real(tsoilNew(node)), node = 1,numnodNew)
      end if

      if (swaun == 2 .AND. swop == 2) then
        write (aun) -0.01*real(WaLevDm1), 0.01*real(VlMpDm1), 0.01*real(WaSrDm1), 0.01*real(VlMpDm2), 0.01*real(WaSrDm2)
        if (swmbf == 2) then
           write (aun) (0.01*real(WaUnMpDm1CpNew(node)), node=1,numnodNew)
        end if
      end if

      FlOpenFileDev = .FALSE.

   case (2)

! === output during simulation ===============================================

! -   convert vertical discretization: dynamic part
      tsoili(1:numnod) = tsoil(1:numnod)

      call convertdiscrvert(2,swop)

      if (swaun == 1) then
        write (aun) real(t1900-tstart),                                 &
          0.01*real((igrai+igird)/outper),                              &
          0.01*real(iintc/outper),                                      &
          0.01*real((ievap+iepd)/outper),                               &
          0.0,                                                          &
          0.01*real(ipeva/outper),                                      &
          0.01*real(iptra/outper),                                      &
          0.01*real(iruno/outper),                                      &
         -0.01*real(gwl),0.01*real(pond)
      else if (swaun == 2) then
        write (aun) real(brund*1.0d0-1.0d0+(t1900-tstart)), real(outper),&
              0.01*real((igrai+isnrai)/outper),                         &
              0.01*real(igsnow/outper),                                 &
              0.01*real(igird/outper),                                  &
              0.01*real( (iintc-(igird-inird))/outper ),                &
              0.01*real( (igird-inird)/outper ),                        &
              0.01*real(isubl/outper),                                  &
              0.01*real((ievap+iepd)/outper),                           &
              0.0,                                                      &
              0.01*real(ipeva/outper),                                  &
              0.01*real(iptra/outper),                                  &
              0.01*real(irunon/outper),                                 &
              0.01*real(iruno/outper),                                  &
              -0.01*real(gwl), 0.01*real(pond),                         &
              0.01*real(ssnow), 0.01*real(wbalance)
      end if
      write (aun) (real(hNew(node)), node=1,numnodNew)
      write (aun) (real(thetaNew(node)), node=1,numnodNew)
      write (aun) (0.01*real(inqrotNew(node)/outper), node=1,numnodNew)
      write (aun) (-0.01*real(inqNew(node)/outper), node=1,numnodNew+1)
      if (nrlevs > 0) then
        do level = 1, nrlevs
          write (aun) (0.01*real(inqdraNew(level,node)/outper), node=1,numnodNew)
        end do
      end if
      if (swaun == 2) then
        write (aun) real(vcover),real(lai),abs(real(0.01d0*rd)),real(cf)
        write (aun) real(tav)
        write (aun) (real(tsoilNew(node)),node = 1,numnodNew)
      end if
      if (swaun == 2 .AND. swop == 2) then
        write (aun) -0.01*real(WaLevDm1), 0.01*real(VlMpDm1), 0.01*real(WaSrDm1), 0.01*real(IQInTopVrtDm1/outper), 0.01*real(IQInTopLatDm1/outper)
        write (aun) (0.01*real(IQExcMtxDm1CpNew(node)/outper), node=1,numnodNew)
        write (aun) (0.01*real(IQOutDrRapCpNew(node)/outper), node=1,numnodNew)
        if (swmbf == 2) then
            write (aun) (0.01*real(IQTopMpDm1CpNew(node)/outper), node=1,numnodNew) 
            write (aun) (0.01*real(WaUnMpDm1CpNew(node)), node=1,numnodNew)
        end if
        write (aun) (real(IAvFrMpWlWtDm1New(node)/outper), node=1,numnodNew)
        write (aun) 0.01*real(VlMpDm2), 0.01*real(WaSrDm2), 0.01*real(IQInTopVrtDm2/outper), 0.01*real(IQInTopLatDm2/outper)
        write (aun) (0.01*real(IQExcMtxDm2CpNew(node)/outper), node=1,numnodNew)
        write (aun) (real(IAvFrMpWlWtDm2New(node)/outper), node=1,numnodNew)
      end if

      ! check of mass balances of sub systems per period OutPer
      if ((swaun >= 1 .OR. swafo == 1) .AND. swafo < 2 .AND. CritDevMasBal > 1.d-30) then
        call checkmassbal (flopenfiledev)
      end if

   case default
      call swap_error ('outaun', 'Illegal value for Task')
   end select

   return
   end subroutine out_aun

! ----------------------------------------------------------------------
   subroutine checkDiscrVert()
!     date               : 20081105; update 01-11-2022
!     purpose            : verify reduced vertical discretization
!     global formal parameters  : (i = input, o = output)
!     numnod       ! Number of nodes or compartments....................... i
!     numnodnew    ! Number of desired nodes for soil water quality models..i
!     dz(macp)     ! Compartment thickness (L) ............................ i
!     dznew(macp)  ! Desired dz for soil water quality models (L) ......... i
! ----------------------------------------------------------------------
      implicit none

! global

! local
      integer                             :: inew,iold,iotmp
      real(8)                             :: cumdzOld,cumdzNew
      real(8), dimension(:), allocatable  :: cumdzN
      character(len=100)                  :: message
! local parameters
      real(8), parameter                  :: small = 0.0001d0

! ----------------------------------------------------------------------
! --  boundary of new compartments must equal boundaries of old compartmts
!     or: new size is sum of old sizes
      allocate(cumdzN(numnodNew)); cumdzN = 0.0d0
      iotmp = 0
      do inew = 1, numnodNew
         do iold = 1, numnod
            if (iold > iotmp .AND. cumdzN(inew) < dzNew(inew)) then
               cumdzN(inew) = cumdzN(inew) + dz(iold)
               iotmp = iold
            end if
         end do
      end do
      do inew = 1, numnodNew
         if (abs(dzNew(inew)-cumdzN(inew)) > small) then
            write(message,'(a,i5)') 'New discretization has error in size of new compartment ', inew
            call swap_error ('checkdiscrvert',message)
         end if
      end do

! --  cumulative thickness
      cumdzOld = sum(dz(1:numnod))
      cumdzNew = sum(dznew(1:numnodnew))
      if (abs(cumdzNew-cumdzOld) > small) then
         write(message,'(a,f10.5)') 'New discretization is wrong, total length differs > ', small
         call swap_error ('checkdiscrvert',message)
      end if

      deallocate(cumdzN)
      return
   end subroutine checkDiscrVert

! ----------------------------------------------------------------------
   subroutine ConvertDiscrVert(part,swop)

!***********************************************************************
!*    Routine: ConvertDiscrVert()
!*    Purpose: converts vertical descritization 
!*    Usage:   Call ConvertDiscrVert(......)
!*    Author(s):   
!*    Version:   
!*    Date/history: update 01-11-2022
!*    See also:
!     Arguments:
!     I/O Data_type Name         Meaning
!      I     I4     SwDiscrVert  
!      I     I4     part         
!      I     I4     Swop  
!      I     I4     nrlevs       
!      I     I4     numlay       
!      I     I4     botcom(maho) 
!      I     I4     numnod       
!      I     R8     dz(macp)     
!      I     R8     theta(macp)  
!      I     R8     inq(macp)    
!      I     R8     inqrot(macp) 
!      I     R8     inqdra(macp) 
!      I     R8     Tsoili(0:macp)  
!      I     I4     numnodNew       
!      I     R8     dzNew(macp) 
!      I     R8     DiPoCp(macp)
!      I     R8     IAvFrMpWlWtDm1(macp)
!      I     R8     IAvFrMpWlWtDm2(macp)
!      I     R8     IQExcMtxDm1Cp(macp)
!      I     R8     IQExcMtxDm2Cp(macp)
!      I     R8     IQOutDrRapCp(macp)
!      I     R8     IQTopMpDm1Cp(macp)
!      I     R8     WaUnMpDm1Cp(macp)
!      I     R8     VlMpStDm1
!      I     R8     VlMpStDm2
!      O     I4     botcomNew(maho) 
!      O     R8     thetaNew(macp)  
!      O     R8     inqNew(macp)    
!      O     R8     inqrotNew(macp) 
!      O     R8     inqdraNew(macp) 
!      O     R8     TsoilNew(0:macp) 
!      O     R8     DiPoCpNew(macp)
!      O     R8     IAvFrMpWlWtDm1New(macp)
!      O     R8     IAvFrMpWlWtDm2New(macp)
!      O     R8     IQExcMtxDm1CpNew(macp)
!      O     R8     IQExcMtxDm2CpNew(macp)
!      O     R8     IQOutDrRapCpNew(macp)
!      O     R8     IQTopMpDm1CpNew(macp)
!      O     R8     WaUnMpDm1CpNew(macp)
!      O     R8     VlMpStDm1New(macp)
!      O     R8     VlMpStDm2New(macp)
!***********************************************************************
      use MOD_arrays, only: macp, mcof
      use MOD_MvG,    only: prhead
!---- Declarations
      IMPLICIT NONE
!     global
      integer, intent(in)                          :: part, Swop

!    local
      integer                                      :: lay,node,nodeN,i,level
      integer, dimension(:,:), allocatable         :: nodeNew
      real(8), dimension(:,:), allocatable         :: CofgenNew
      real(8), dimension(:),   allocatable         :: disnodNew
      real(8), dimension(:),   allocatable         :: zNew
      real(8), dimension(:),   allocatable         :: thetadummie
      real(8)                                      :: total
      character(len=80)                            :: Message,ModuleName

      SAVE

! --- error in call of part
      if (part < 1 .OR. part > 2) then
        write(message,*) 'fatal error in variabel PART '
        call swap_error (modulename, message)
      end if

      if (.NOT. allocated(nodeNew))     allocate(nodeNew(numnodnew, 2)) 
      if (.NOT. allocated(CofgenNew))   allocate(CofgenNew(mcof, macp)) 
      if (.NOT. allocated(disnodNew))   allocate(disnodNew(numnodnew+1)) 
      if (.NOT. allocated(zNew))        allocate(zNew(numnodnew)) 
      if (.NOT. allocated(thetadummie)) allocate(thetadummie(numnodnew))

! --- always convert to maintain identic writing

      if (SwDiscrVert == 0) then
! --    Simply copy
        numnodNew = numnod
        do lay = 1, numlay
          botcomNew(lay) = botcom(lay)
        end do
        do node = 1, numnodNew
          dzNew(node)        = dz(node)
          hNew(node)         = h(node)
          thetaNew(node)     = theta(node)
          IThetaBegNew(node) = IThetaBeg(node)
          inqNew(node)       = inq(node)
          inqrotNew(node)    = inqrot(node)
          do level=1,nrlevs
            inqdraNew(level,node) = inqdra(level,node)
          end do
!
          if (swop == 2) then
             VlMpStDm1New(node) = VlMpStDm1(node)
             VlMpStDm2New(node) = VlMpStDm2(node)
             DiPoCpNew(node) = DiPoCp(node)
             IQExcMtxDm1CpNew(node) = IQExcMtxDm1Cp(node)
             IQOutDrRapCpNew(node) = IQOutDrRapCp(node)
             IAvFrMpWlWtDm1New(node) = IAvFrMpWlWtDm1(node)
             IQExcMtxDm2CpNew(node) = IQExcMtxDm2Cp(node)
             IAvFrMpWlWtDm2New(node) = IavFrMpWlWtDm2(node)
             ThetaNew(node) = FrArMtrx(node)*Theta(node)
             IThetaBegNew(node) = FrArMtrx(node)*IThetaBeg(node)
             if (swmbf == 2) then
                IQTopMpDm1CpNew(node) = IQTopMpDm1Cp(node)
                WaUnMpDm1CpNew(node) = WaUnMpDm1Cp(node)
                IWaUnDm1CpBegNew(node) = IWaUnDm1CpBeg(node)
                IQTopMpDm2CpNew(node) = IQTopMpDm2Cp(node)
                WaUnMpDm2CpNew(node) = WaUnMpDm2Cp(node)
                IWaUnDm2CpBegNew(node) = IWaUnDm2CpBeg(node)
             end if
          end if
        end do
        do node = 0, numnodNew
           TsoilNew(node) = Tsoili(node)
        end do
        inqNew(numnodNew+1) = inq(numnod+1)

      else if (SwDiscrVert == 1) then
! ---   initial part (part 1)
        if (part == 1) then

!         calculate zNew = depth at bottom of new compartment
          Total = 0.0d0
          do node = 1, numnodNew
            Total      = Total + dzNew(node)
            zNew(node) = Total
          end do
!         Fill array NodeNew(Numnod,1) = top old compartment and NodeNew(Numnod,2) = bottom old comp. in new comp. NodeN
          NodeN = 1
          Node  = 1
          Total = 0.0d0
          do while (node <= numnod) 
            Total = Total + dz(node) 
            if (ABS(zNew(NodeN)-Total) < 1.0D-6) then
              NodeNew(NodeN,2) = Node
              NodeN            = NodeN+1
            end if
            node = node+1
          end do
          NodeNew(1,1) = 1
          do node = 2, numnodNew
            NodeNew(Node,1) = NodeNew(Node-1,2)+1
          end do
!         botcomNew
          do lay = 1, numlay
            do node = 1, numnodNew
              if (NodeNew(Node,2) == botcom(lay)) then
                botcomNew(lay) = node
              else
                continue
              end if
            end do
          end do

!         for hNew: position of nodal points and distances between them
          zNew(1)      = -0.5d0*dzNew(1)
          disnodNew(1) = -zNew(1)
          do node = 2, numnodNew
            zNew(node)      = zNew(node-1)-0.5d0*(dzNew(node-1)+dzNew(node))
            disnodNew(node) = zNew(node-1)-zNew(node)
          end do
!  
        end if

! ---   In both part 1 and 2: convert theta to thetaNew based on weighed average
        do node = 1, NumNodNew
          Total = 0.0d0
          do i = NodeNew(node,1), NodeNew(node,2)   
            Total = Total + dz(i)
          end do
          thetaNew(node) = 0.0d0
          IThetaBegNew(node) = 0.d0
          thetadummie(node)  = 0.d0
          do i = NodeNew(node,1), NodeNew(node,2)
            if (Swop /= 2) then
               thetaNew(node)     = thetaNew(node) + theta(i) * dz(i)/Total
               IThetaBegNew(node) = IThetaBegNew(node) + IThetaBeg(i) * dz(i)/Total
               thetadummie(node)  = thetaNew(node)
            else
               thetaNew(node)     = thetaNew(node) + FrArMtrx(i)*theta(i) * dz(i)/Total
               IThetaBegNew(node) = IThetaBegNew(node) + FrArMtrx(i) * IThetaBeg(i)*dz(i)/Total
               thetadummie(node)  = thetadummie(node) + theta(i) * dz(i)/Total
            end if
          end do
        end do
! ---   convert Tsoili to TSoilNew based on weighed average
        do node = 1, NumNodNew
          Total = 0.0d0
          do i = NodeNew(node,1), NodeNew(node,2)   
            Total = Total+dz(i)
          end do
          TsoilNew(node) = 0.0d0
          do i = NodeNew(node,1), NodeNew(node,2)
            TsoilNew(node) = TsoilNew(node)+Tsoili(i)*dz(i)/Total
          end do               
        end do

        if (swop == 2) then
! ---   convert VlMpStDm to VlMpStDmNew based on integration
           do node = 1, NumNodNew
             VlMpStDm1New(node) = 0.0d0
             VlMpStDm2New(node) = 0.0d0
             do i = NodeNew(node,1), NodeNew(node,2)
               VlMpStDm1New(node) = VlMpStDm1New(node) + VlMpStDm1(i)
               VlMpStDm2New(node) = VlMpStDm2New(node) + VlMpStDm2(i)
             end do               
           end do
! ---   convert DiPoCp to DiPoCpNew based on weighed average
           do node = 1, NumNodNew
             Total = 0.0d0
             do i = NodeNew(node,1), NodeNew(node,2)   
               Total = Total + dz(i)
             end do
             DiPoCpNew(node) = 0.0d0
             do i = NodeNew(node,1), NodeNew(node,2)
               DiPoCpNew(node) = DiPoCpNew(node)+DiPoCp(i)*dz(i)/Total
             end do               
           end do
! ---   convert water volume in MB domain based on integration
           do node = 1, NumNodNew
              Total = 0.0d0
             do i = NodeNew(node,1), NodeNew(node,2)   
               Total = Total + dz(i)
             end do
             if (swmbf == 2) then
               WaUnMpDm1CpNew(node) = 0.0d0
               IWaUnDm1CpBegNew(node) = 0.0d0
               WaUnMpDm2CpNew(node) = 0.0d0
               IWaUnDm2CpBegNew(node) = 0.0d0
               do i = NodeNew(node,1), NodeNew(node,2)
                  WaUnMpDm1CpNew(node)   = WaUnMpDm1CpNew(node)   + WaUnMpDm1Cp(i)
                  IWaUnDm1CpBegNew(node) = IWaUnDm1CpBegNew(node) + IWaUnDm1CpBeg(i)
                  WaUnMpDm2CpNew(node)   = WaUnMpDm2CpNew(node)   + WaUnMpDm2Cp(i)
                  IWaUnDm2CpBegNew(node) = IWaUnDm2CpBegNew(node) + IWaUnDm2CpBeg(i)
               end do
             end if
           end do
        end if


! ---   only in dynamic part (part 2)
        if (part == 2) then

! -       Determine hNew
          do node = 1, numnodNew
             do i = 1, 9
                cofgenNew(i,node) = cofgen(i,NodeNew(node,2)) ! CofgenNew Newnode = Cofgen bottom old node
             end do
             
             hNew(node) = prhead (node,disnodNew(node),thetadummie(node),cofgenNew,hNew)
          end do

! ---     convert inqrot to inqrotNew based on integration
          do node = 1, NumNodNew
            inqrotNew(node) = 0.0d0
            do i = NodeNew(node,1), NodeNew(node,2)
              inqrotNew(node) = inqrotNew(node)+inqrot(i)
            end do               
          end do
! ---     convert inq to inqNew
          do node = 1, NumNodNew
            inqNew(node) = inq(NodeNew(node,1))
          end do
          inqNew(NumNodNew+1) = inq(numnod+1)
! ---     convert inqdra to inqdraNew based on integration
          do level = 1, nrlevs
            do node = 1, NumNodNew
              inqdraNew(level,node) = 0.0d0
              do i = NodeNew(node,1), NodeNew(node,2)
                inqdraNew(level,node) = inqdraNew(level,node) + inqdra(level,i)
              end do               
            end do
          end do
        end if

! ---   convert macropore fluxes to New fluxes based on integration, and 
!       IAvFrMpWlWtDm1 to IAvFrMpWlWtDm1New, based on weighed average, and
!       IQTopMpDm1Cp based on top of new compartment numbers.
        if (swop == 2) then
          do node = 1, NumNodNew
            Total = 0.0d0
            do i = NodeNew(node,1), NodeNew(node,2)   
              Total = Total + dz(i)
            end do
            IQExcMtxDm1CpNew(node) = 0.0d0
            IQExcMtxDm2CpNew(node) = 0.0d0
            IQOutDrRapCpNew(node) = 0.0d0         
            IAvFrMpWlWtDm1New(node) = 0.0d0
            IAvFrMpWlWtDm2New(node) = 0.0d0
            do i = NodeNew(node,1), NodeNew(node,2)
              IQExcMtxDm1CpNew(node) = IQExcMtxDm1CpNew(node) + IQExcMtxDm1Cp(i)
              IQExcMtxDm2CpNew(node) = IQExcMtxDm2CpNew(node) + IQExcMtxDm2Cp(i)
              IQOutDrRapCpNew(node) = IQOutDrRapCpNew(node) + IQOutDrRapCp(i) 
              IAvFrMpWlWtDm1New(node) = IAvFrMpWlWtDm1New(node) + IAvFrMpWlWtDm1(i)*dz(i)/Total
              IAvFrMpWlWtDm2New(node) = IAvFrMpWlWtDm2New(node) + IAvFrMpWlWtDm2(i)*dz(i)/Total
            end do
            if (swmbf == 2) then
               IQTopMpDm1CpNew(node) = IQTopMpDm1Cp(NodeNew(node,1))
               IQTopMpDm2CpNew(node) = IQTopMpDm2Cp(NodeNew(node,1))
            end if
          end do
        end if

      else
        write(message,*) 'fatal error in variable SWDISCRVERT'
        call swap_error (modulename, message)
      end if

      return
   end subroutine ConvertDiscrVert

! ----------------------------------------------------------------------
   subroutine checkmassbal (flopenfiledev)
! ----------------------------------------------------------------------
!     Date               : 26-jun-2003; update 01-11-2022
!     Purpose            : Checking of mass balance per period OutPer for
!                          ANIMO/PEARL output
!     Subroutines called : -              
!     Functions called   : -
!     File usage         : outfil
! ---------------------------------------------------------------------
      use MOD_swap_base, only: swmacro, iun_min, iun_max
      implicit none

! -   global
      logical, intent(inout)              :: FlOpenFileDev

! -  local
      integer                             :: Dev, Level, getun, ic
      real(8)                             :: DevMasBalDm1, DevMasBalDm2
      real(8), dimension(:), allocatable  :: Qdra, WaSr, WaSrBeg, DevMasBalCmp
      real(8), dimension(:), allocatable  :: WaSrMP, WaSrMPBeg, DevMasBalMPCmp
      real(8)                             :: DevMasBalPnd, DevMasBalPrf, IQExcMtxDm1
      real(8)                             :: IQExcMtxDm2, IQInTopLatDm,  IQInTopPreDm, IQOutDrRap
      real(8)                             :: QdraPrf, QrotPrf, SrDif
      real(8)                             :: WaSrPrf, WaSrPrfBeg  
      character(len=300)                  :: filnam
      logical, dimension(:), allocatable  :: FlWriteDevCmp, FlWriteDevMPCmp
      logical                             :: FlWriteDev, FlWriteDevDm1, FlWriteDevDm2 
      logical                             :: FlWriteDevPnd, FlWriteDevPrf
      
!     save values oflocals
      save

      if (.NOT. allocated(Qdra)) allocate(Qdra(numnodnew))
      if (.NOT. allocated(WaSr)) allocate(WaSr(numnodnew))
      if (.NOT. allocated(WaSrBeg)) allocate(WaSrBeg(numnodnew))
      if (.NOT. allocated(DevMasBalCmp)) allocate(DevMasBalCmp(numnodnew))
      if (.NOT. allocated(FlWriteDevCmp)) allocate(FlWriteDevCmp(numnodnew))
      if (.NOT. allocated(WaSrMP)) allocate(WaSrMP(numnodnew))
      if (.NOT. allocated(WaSrMPBeg)) allocate(WaSrMPBeg(numnodnew))
      if (.NOT. allocated(DevMasBalMPCmp)) allocate(DevMasBalMPCmp(numnodnew))
      if (.NOT. allocated(FlwRiteDevMPCmp)) allocate(FlWriteDevMPCmp(numnodnew))

! ----------------------------------------------------------------------
! --- Checking of mass balances of sub systems per period OutPer
      FlWriteDev = .FALSE.
      FlWriteDevPnd = .FALSE.
      FlWriteDevPrf = .FALSE.
      FlWriteDevCmp(1:NumNodNew) = .FALSE.
      FlWriteDevMPCmp(1:NumNodNew) = .FALSE.
      FlWriteDevDm1 = .FALSE.
      FlWriteDevDm2 = .FALSE.

!   - 1) Ponding layer
      SrDif        = IPondBeg-Pond + ISsnowBeg-Ssnow
      IQInTopPreDm = 0.d0
      IQInTopLatDm = 0.d0
      if (swmacro == 1 .AND. IcTopMp == 1) then
         IQInTopPreDm = IQInTopVrtDm1 + IQInTopVrtDm2
         IQInTopLatDm = IQInTopLatDm1 + IQInTopLatDm2
      end if

!     - Deviation mass balance Ponding layer in cm
      DevMasBalPnd = igrai + igsnow + igird + irunon + inqNew(1) + SrDif - (igrai-inrai-isnrai + igird-inird + isubl + ievap + iepd +  iruno) - IQInTopPreDm - IQInTopLatDm

!     - Check mass balance against criteria
      if (abs(DevMasBalPnd) > CritDevMasBal) then
         FlWriteDev    = .TRUE.
         FlWriteDevPnd = .TRUE.
      end if

!   - 2) Total Soil Profile
      WaSrPrfBeg  = 0.d0 
      WaSrPrf     = 0.d0 
      QrotPrf     = 0.d0 
      QdraPrf     = 0.d0 
      IQExcMtxDm1 = 0.d0
      IQExcMtxDm2 = 0.d0
      do ic = 1, numnodnew
         WaSrPrfBeg = WaSrPrfBeg + dzNew(ic)*IThetaBegNew(ic)
         WaSrPrf    = WaSrPrf    + dzNew(ic)*ThetaNew(ic)
         QrotPrf    = QrotPrf    + inqrotNew(ic)
         do level = 1, nrlevs
            QdraPrf = QdraPrf + InqdraNew(level,ic)
         end do
         if (swmacro == 1) then
            IQExcMtxDm1 = IQExcMtxDm1 + IQExcMtxDm1CpNew(ic)
            IQExcMtxDm2 = IQExcMtxDm2 + IQExcMtxDm2CpNew(ic)
         end if
      end do
      SrDif = WaSrPrfBeg - WaSrPrf

!     - Deviation mass balance total Profile in cm
      DevMasBalPrf = inqNew(NumNodNew+1) + SrDif + IQExcMtxDm1 + IQExcMtxDm2 - (inqNew(1) + QrotPrf + QdraPrf) 

!     - Check mass balance against criteria
      if (abs(DevMasBalPrf) > CritDevMasBal) then
         FlWriteDev    = .TRUE.
         FlWriteDevPrf = .TRUE.
      end if

!   - 3) Individual Soil Compartments
      do ic = 1, numnodnew
         SrDif       = 0.d0
         Qdra(ic)    = 0.d0 
         WaSrBeg(ic) = dzNew(ic) * IThetaBegNew(ic)
         WaSr(ic)    = dzNew(ic) * ThetaNew(ic)
         SrDif       = WaSrBeg(ic) - WaSr(ic) 
         do level = 1, nrlevs
            Qdra(ic) = Qdra(ic) + inqdraNew(level,ic)
         end do

!     - Deviation mass balance Soil Compartments in cm
         DevMasBalCmp(ic) = inqNew(ic+1) + SrDif - (inqNew(ic) + inqrotNew(ic) + Qdra(ic))
         if (swmacro == 1) DevMasBalCmp(ic) = DevMasBalCmp(ic) + IQExcMtxDm1CpNew(ic) + IQExcMtxDm2CpNew(ic)

!     - Check mass balance against criteria
         if (abs(DevMasBalCmp(ic)) > CritDevMasBal) then
            FlWriteDev        = .TRUE.
            FlWriteDevCmp(ic) = .TRUE.
         end if
      end do

!   - 4) Macropore domains Dm1 and Dm2
      if (swmacro == 1) then
         IQOutDrRap = 0.d0
         do ic = 1, numnodnew
            IQOutDrRap = IQOutDrRap + IQOutDrRapCpNew(ic)
         end do

!     - Deviation mass balance Macropore Domains in cm
         SrDif = IWaSrDm1Beg - WaSrDm1
         DevMasBalDm1 = IQInTopLatDm1 + SrDif - (IQExcMtxDm1  + IQOutDrRap)
         if (IcTopMp == 1) DevMasBalDm1 = DevMasBalDm1 + IQInTopVrtDm1

         SrDif = IWaSrDm2Beg - WaSrDm2
         DevMasBalDm2 = IQInTopLatDm2 + SrDif - IQExcMtxDm2
         if (IcTopMp == 1) DevMasBalDm2 = DevMasBalDm2 + IQInTopVrtDm2

!     - Check mass balance against criteria
         if (abs(DevMasBalDm1) > CritDevMasBal) then
            FlWriteDev    = .TRUE.
            FlWriteDevDm1 = .TRUE.
         end if
         if (abs(DevMasBalDm2) > CritDevMasBal) then
            FlWriteDev    = .TRUE.
            FlWriteDevDm2 = .TRUE.
         end if
         
!   - 5) In case of kinematic wave: individual compartments MP domain
         if (swmbf == 2) then
            do ic = 1, numnodnew
               SrDif         = 0.d0
               WaSrMPBeg(ic) = IWaUnDm1CpBegNew(ic)
               WaSrMP(ic)    = WaUnMpDm1CpNew(ic)
               SrDif         = WaSrMPBeg(ic) - WaSrMP(ic) 
   
!     - Deviation mass balance Soil Compartments in cm
               DevMasBalMPCmp(ic) = SrDif - IQExcMtxDm1CpNew(ic) - IQOutDrRapCpNew(ic) + IQTopMpDm1CpNew(ic) - IQTopMpDm1CpNew(ic+1)
               
!     - Check mass balance against criteria
               if (abs(DevMasBalMPCmp(ic)) > CritDevMasBal) then
                  FlWriteDev          = .TRUE.
                  FlWriteDevMPCmp(ic) = .TRUE.
               end if
            end do
         end if  
      end if

!
! --- In case of deviations of mass balance open file 'xxxxx.dwb.csv'
      if (FlWriteDev .AND. .NOT.FlOpenFileDev) then
         filnam = trim(pathwork)//trim(outfil)//'.dwb'
         dev    = getun (iun_min, iun_max)
         call fopens(dev,filnam,'new','del')
         write(dev,1)
         if (swmacro == 1) write(dev,2)
         FlOpenFileDev = .TRUE.
      end if

!   - Write deviations of water balance Top system
      if (FlWriteDevPnd) write(dev,3) daycum, t, DevMasBalPnd, igrai, igsnow, igird, irunon, isnrai, igrai-inrai,igird-inird, &
                                      isubl, ievap + iepd, iruno, inqNew(1), Pond, IPondBeg, Ssnow, ISsnowBeg, IQInTopPreDm, IQInTopLatDm

!   - Write deviations of water balance whole Profile
      if (FlWriteDevPrf) write(dev,4) daycum, t, DevMasBalPrf, inqNew(1), inqNew(NumNodNew+1), QrotPrf, QdraPrf, WaSrPrf, WaSrPrfBeg, IQExcMtxDm1, IQExcMtxDm2

!   - Write deviations of water balance of Individual Soil Compartments
      do ic = 1, numnodnew
         if (FlWriteDevCmp(ic)) write(dev,5) daycum, t, ic, DevMasBalCmp(ic), inqNew(ic), inqNew(ic+1), inqrotNew(ic), Qdra(ic), WaSr(ic), WaSrBeg(ic), IQExcMtxDm1CpNew(ic), IQExcMtxDm2CpNew(ic)
      end do

!   - Write deviations of water balance Macropore Domains
      if (FlWriteDevDm1) write(dev,6) daycum, t, DevMasBalDm1, IQInTopVrtDm1, IQInTopLatDm1, IQExcMtxDm1, WaSrDm1, IWaSrDm1Beg, IQOutDrRap
      if (FlWriteDevDm2) write(dev,7) daycum, t, DevMasBalDm2, IQInTopVrtDm2, IQInTopLatDm2, IQExcMtxDm2, WaSrDm2, IWaSrDm2Beg

!   - Write deviations of water balance of Individual Soil Compartments in macropore MB domain
      do ic = 1, numnodnew
         if (FlWriteDevMPCmp(ic)) write(dev,8) daycum, t, ic, DevMasBalMPCmp(ic), WaSrMP(ic), WaSrMPBeg(ic), IQExcMtxDm1CpNew(ic), IQOutDrRapCpNew(ic), IQTopMpDm1Cp(ic), IQTopMpDm1Cp(ic+1)
      end do
!
    1 format(' DEVIATIONS WATERBALANCE for different subsystems: 1. Pond.layer; 2. Whole profile; 3. Compartment; (optional: Macrop.Dom.: 4. Dom1; 5. Dom2; 6. Kinematic wave Dom1)',/,               &
       ' Relevant terms of waterbalance per subsystem (all terms in cm):',//,                                                                                                                         &
       ' DayCum, 1. PONDLAY, DevMasBalAbs, IgRai, IgSnow, IgIrd, IRunon, SnowFall,IntcpRai, IntcpIrd, ISubl, IEvap, IRuno, InQTop, Pond, IPondBeg, Ssnow, ISsnowBeg, IQInTopPreDm, IQInTopLatDm,',/,  &
             ' , 2. PROFILE, DevMasBalPrf, InQTop, InQBot, QrotPrf, QdraPrf, WaSrPrf, WaSrPrfBeg, InQExcMtxDm1, InQExcMtxDm2',/,                                                                      &
             ' , 3. COMPno, DevMasBalCmp, InQNew(top), InQNew(bot), InQrotNew, Qdra, WaSr, WaSrBeg, InQExcMtxDm1CpNew, InQExcMtxDm2CpNew')
    2 format(' , 4. MPDOM1, DevMasBalDm1, IQInTopPre/VrtDm1, IQInTopLatDm1, InQExcMtxDm1, WaSrDm1, IWaSrDm1Beg, InQOutDrRap'/                &
             ' , 5. MPDOM2, DevMasBalDm2, IQInTopPre/VrtDm2, IQInTopLatDm2, InQExcMtxDm2, WaSrDm2, IWaSrDm2Beg'/                             &
             ' , 6. COMPno, DevMasBalCmp, WaSrMP, WaSrMPbeg, InQExcMtxDm1Cp, InQOutDrRap, InQTopCp, InQBotCp')
    3 format(i5,',',f12.5,',',' Pondlay. : ',18(',',f12.8))
    4 format(i5,',',f12.5,',',' Profile : ',9(',',f12.8))
    5 format(i5,',',f12.5,',',' Comp',i3,': ',9(',',f12.8))
    6 format(i5,',',f12.5,',',' MpDom1 : ',7(',',f12.8))
    7 format(i5,',',f12.5,',',' MpDom2 : ',6(',',f12.8))
    8 format(i5,',',f12.5,',',' MPComp',i3,': ',7(',',f12.8))    

      return
   end subroutine checkmassbal

end module MOD_out_PEARL_ANIMO
