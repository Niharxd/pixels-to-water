module MOD_runon

use MOD_swap_base,         only: swrunon

implicit none

! global variables
real(8), allocatable, save :: runontim(:)          ! start of runon (t1900) (t)
real(8), allocatable, save :: runonflx(:)          ! flux runon (L/T)
integer, save :: runon_rec                         ! runon record

! local variables
character(len=200), save :: rufilnam               ! name of runon file

! everything is private
private

! except for the following function/subroutine
public :: read_runon

! except for the following variables
public :: runon_rec, runontim, runonflx

contains
    
! ------------------------------------------------------------------------
    
   subroutine read_runon

      ! ------------------------------------------------------------------
     
      use MOD_swap_base,       only: unit_swp, swpfilnam, unit_err, pathrunon

      implicit none
     
      character(len=32)  rufil
      
      ! ------------------------------------------------------------------

      ! read settings from main input
      call rdinit(unit_swp, unit_err, swpfilnam)
     
      ! filename meteo data
      call rdscha ('rufil', rufil)
      rufilnam = trim(pathrunon)//trim(rufil)//'.ru'
     
      close(unit_swp)
         
      ! load all runon data
      call load_runon_data ()

      return
     
   end subroutine read_runon

   ! ---------------------------------------------------------------------
   
   subroutine load_runon_data ()

      ! ------------------------------------------------------------------
       
      ! global variables   
      use MOD_swap_base, only: iun_min2, iun_max2, unit_log, unit_err
      use variables,     only: tstart, tend

      implicit none

      ! local variables
      integer :: n_rec

      real(8), allocatable :: all_runontime(:), all_runonamount(:)
   
      integer              :: unit, getun2, i

      character(len=19)    :: datedum
      character(len=800)   :: message
      logical              :: file_exists
   
      ! local variables (ttutil)
      logical              :: rdinqr
   
      ! local parameters
      real(8), parameter   :: vsmall = 1.0d-8

      ! ------------------------------------------------------------------
       
      ! determine total number of records to allocate
   
      ! open connection
      inquire(file = rufilnam, exist = file_exists)
      if (.NOT. file_exists) then
         message ='File '//trim(rufilnam)//' does not exists!'
         call swap_error ('loadrunondata', message)
      end if
      unit = getun2 (iun_min2, iun_max2, 2)
      call rdinit (unit,unit_err,rufilnam)
   
      ! determine number of records
      if (.NOT. rdinqr('date')) call swap_error ('loadrunondata', 'Variable DATE not present in file '//trim(rufilnam))
      call rdinne ('date',n_rec)
   
      ! allocate variables
      allocate (all_runontime(n_rec + 1))
      allocate (all_runonamount(n_rec + 1))
 
      ! load variables
      call rdatim ('date',all_runontime,n_rec,n_rec)
      call rdfdor ('amount',0.0d0,10000.0d0,all_runonamount,n_rec,n_rec)
  
      close (unit)

      ! check whether dates are in ascending order
      do i = 2,n_rec
         if ( (all_runontime(i)-all_runontime(i-1)) < vsmall) then
            call dtdpst ('year-month-day hour:minute:seconds',all_runontime(i-1),datedum)
            message ='In RUFIL the date after '//datedum//' is not correct! Adapt runon file!'
            call swap_error ('loadrunondata', message)
         end if
      end do        
   
      ! store runontim and runonflux (SWRUNON = 1)
      if (allocated(runontim)) deallocate(runontim); allocate(runontim(n_rec + 1)); runontim = 0.d0
      if (allocated(runonflx)) deallocate(runonflx); allocate(runonflx(n_rec + 1)); runonflx = 0.d0
      runon_rec = 0
      do i = 1,n_rec

         if (all_runontime(i) >= tstart) then

            if (i == 1) then
               if (all_runontime(i) - tstart > vsmall) then
                  runon_rec = runon_rec + 1
                  runontim(runon_rec) = all_runontime(i)
                  runonflx(runon_rec) = all_runonamount(i) * 0.1d0 / (all_runontime(i) - tstart)
               end if
            else               
               runon_rec = runon_rec + 1
               runontim(runon_rec) = all_runontime(i)
               runonflx(runon_rec) = all_runonamount(i) * 0.1d0 / (all_runontime(i) - all_runontime(i-1))
            end if   
       
         end if
      end do
   
      ! closure of previous rain event
      runon_rec = runon_rec + 1
      runontim(runon_rec) = tend + 2.d0
      runonflx(runon_rec) = 0.d0
   
      runon_rec = 1
   
      ! deallocate temporary data
      deallocate(all_runontime, all_runonamount)
   
      ! data read and stored properly
      write (unit_log,'(A)') 'RUFIL: all runon data read and stored.'        
   
      return

   end subroutine load_runon_data
   
   end module MOD_runon
