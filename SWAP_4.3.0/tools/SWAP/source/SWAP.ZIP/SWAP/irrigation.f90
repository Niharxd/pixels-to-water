module MOD_irrigation
   
   use MOD_arrays, only: mairg, macp 
   
   ! local, saved
   integer, dimension(2),      save :: nod_ssdi           ! upper and lower nodes where ssdi takes place

   real(8),                    save :: irr_depth          ! Amount of scheduled irirgation (input as mm, converted to cm)
   real(8),                    save :: irr_rate           ! Application rate (inputs as mm/h, converted to cm/d)

   ! --- irrigation variables
   integer,                    save :: dayfix             ! days since last irrigation event
   integer,                    save :: irrigevent         ! Switch: 0 = no irrigation; 1 = fixed irrigation event; 2 = scheduled irrigation event
   integer, dimension(mairg),  save :: irtype             ! Type of fixed irrigation: 0 = sprinkling irrigation; 1 = surface irrigation
   integer,                    save :: isua               ! Switch for type of irrigation: 0 = sprinkling irrigation, 1 = surface irrigation
   integer,                    save :: isuas              ! Switch for type of scheduled irrigation: 0 = sprinkling irrigation, 1 = surface irrigation
   integer,                    save :: nirri              ! Number of irrigation event
   integer,                    save :: schedule           ! Switch for simulation of irrigation scheduling: 0 = no, 1 = yes
   integer,                    save :: swcirrthres        ! Switch to allow over irrigation when a conc-threshold is exceeded: 0 = no; 1 = yes/allowed
   real(8),                    save :: cirr               ! Solute concentration of irrigation water (M/L3)
   real(8),                    save :: cirrs              ! Solute concentration of irrigation water (M/L3)
   real(8),                    save :: cirrthres          ! Threshold value (M/L3) indicating the concentration that initiates over irrigation
   real(8),                    save :: dcrit              ! Depth (L) of sensor for soil water pressure head or water content
   real(8), dimension(14),     save :: ditab              ! Array with amount of under- or over-irrigation (L) as function of crop development stage
   real(8), dimension(14),     save :: dwatab             ! Array with maximum amounts of water depleted as function of crop development stage
   real(8),                    save :: dt_irr_event       ! Length of SSDI irrigation event (T)
   real(8), dimension(14),     save :: fidtab             ! Array with prescribed fixed irrigation depth (L) as function of crop development stage
   real(8),                    save :: gird               ! Gross irrigation rate (L/T)
   real(8), dimension(14),     save :: hcritab            ! Array with minimum soil water pressure heads (L) as function of crop development stage
   real(8), dimension(mairg),  save :: irconc             ! Array with irrigation concentrations (M/L3) in case of fixed irrigation
   real(8), dimension(mairg),  save :: irdate             ! Array with fixed irrigation dates
   real(8), dimension(mairg),  save :: irrate             ! Array with fixed irrigation rates (mm/h)
   real(8), dimension(mairg),  save :: irdepth            ! Array with fixed irrigation depths (mm)
   real(8), dimension(2),      save :: ir_z               ! Depth (interval) in case of fixed irrigation with subsurface irrigation (cm)
   real(8),                    save :: nird               ! Net irrigation depth (L)
   real(8),                    save :: perirrsurp         ! percentage (-) of the scheduled irrigation depths that may be over irrigated
   real(8), dimension(macp),   save :: qssdi              ! Array with water input via subsurface drip irrigation for each compartment (L/T)
   real(8),                    save :: qssdisum           ! Total subsurface irrigation flux (L/T)
   real(8),                    save :: raithreshold       ! Threshold value (L) indicating the amount of rainfall which is substracted from scheduled irrigation depths
   real(8), dimension(14),     save :: rawtab             ! Array with minimum of readily available water as function of crop development stage
   real(8), dimension(14),     save :: tawtab             ! Array with minimum of totally available water as function of crop development stage
   real(8), dimension(14),     save :: tcritab            ! Array with minimum volumetric soil water contents as function of crop development stage
   real(8),                    save :: tstairrig          ! Date after which scheduled irrigation is allowed
   real(8),                    save :: tendirrig          ! Date after which scheduled irrigation is NOT allowed
   real(8), dimension(14),     save :: treltab            ! Array with minimum of ratio actual/potential transpiration as function of crop development stage
   logical,                    save :: flheadirg          ! Flag indicating that header should be printed in irrigation output file
   logical,                    save :: flirrigate         ! Flag indicating irrigation in simulation run (either fixed or scheduled)

   integer,                    save :: sw_irrig = 1
   real(8),                    save :: f_irr_avail = 1.0d0
   integer,                    save :: tcs
   integer,                    save :: tcsfix
   integer,                    save :: dcslim
   integer,                    save :: dcs
   integer,                    save :: irgdayfix
   integer,                    save :: yearendcrp, yearstacrp
   real(8),                    save :: tstairryrx,tendirryrx
   public
   
   contains

! File VersionID:
!   $Id: irrigation.f90 372 2018-03-13 10:01:20Z heine003 $
! ----------------------------------------------------------------------
      subroutine irrigation (task)
! ----------------------------------------------------------------------
!     Date               : November 2004
!     Purpose            : evaluate and schedule irrigations
!                        : Modified July 2019; 
!                             - tcs=5 obsolete and replaced by tcs=7 (theta) and tcs=8 (presh)
!                             - some calculations only once during initialization
! ----------------------------------------------------------------------
! --  global variables
      use MOD_arrays,           only: maho      
      use MOD_swap_base,        only: swsolu, unit_err, fl_initialize, swirfix
      use plant_interface,      only: unit_crp, crpfilnam, icrop, cropstart, cropend, fl_start_croprotation, fl_cropemergence, dvs, noddrz, hlim3l, hlim3h, hlim4, rd
      use atmosphere_interface, only: grai
      use MOD_grid,             only: zbotcp, numlay, botcom, ztopcp, dz, layer, numnod
      use MOD_MvG,              only: watcon
      use MOD_integral_global,  only: iptra_day, iqreddry_day, iqredsol_day
      use MOD_solute_global,    only: cml
      use variables,            only: t1900, t, h, theta
      
      implicit none
      
      ! locals
      integer, intent(in)        :: task
! -- local variables
      integer                    :: node,nodsen
      integer                    :: ifnd,i,j,datea(6)
      integer                    :: endirr(2),startirr(2)
      real(8)                    :: frlow,phlo,phhi,phme,awlh,awmh,awah,cdef
      real(8)                    :: wclo,wcme,wchi,wcac,tps1,tps2,tps3,tps4,tps5,depl,phcrit
      real(8)                    :: dps1,dps2,afgen,Tred
      real(8)                    :: dvstage(7),trel(7),raw(7),taw(7),dwa(7),hcri(7),tcri(7)
      real(8)                    :: di(7),fid(7),irgdepmax,irgdepmin,irgthreshold
      real(4)                    :: fsec
      real(8)                    :: grai_red, dummy
      real(8), dimension(maho)   :: wclos, wcmes, wchis
      real(8), dimension(2)      :: ir_z
      logical                    :: flIrriTime
      
      character(len=200)         :: message

      ! functions
      logical                    :: rdinqr, rdinar
      
!     save local variables
      save    

!     dcs(1)  = Amount of under- or over-irrigation (L) in case of a scheduled irrigation event
!     dcs(2)  = Prescribed fixed irrigation depth (L) for each scheduled irrigation event

! ----------------------------------------------------------------------
      select case (task)
      
      case (1)

! === initialization calculated irrigation ============================

         ! open connection
         call rdinit(unit_crp, unit_err, crpfilnam)

         ! determine whether irrigation scheduling is applied
         call rdsinr ('schedule',0,1,schedule)

         if (schedule == 1) then

            ! no scheduled irrigation before this date
            call rdfinr('startirr',1,31,startirr,2,2)
            call rdfinr('endirr',1,31,endirr,2,2)
            datea(1) = 1900
            datea(2) = startirr(2)
            datea(3) = startirr(1)        
            fsec = 0.0
            call dtardp (datea, fsec, tstairrig)
            datea(2) = endirr(2)
            datea(3) = endirr(1)        
            call dtardp (datea, fsec, tendirrig)

            call dtdpar (cropstart(icrop),datea,fsec)
            yearstacrp = datea(1)
            call dtdpar (cropend(icrop),datea,fsec)
            yearendcrp = datea(1)
            if (yearendcrp > yearstacrp) then
               datea(1) = yearstacrp
               datea(2) = startirr(2)
               datea(3) = startirr(1)        
               fsec     = 0.0
               call dtardp (datea, fsec, tstairryrx)
               datea(1) = yearendcrp
               datea(2) = endirr(2)
               datea(3) = endirr(1)        
               call dtardp (datea, fsec, tendirryrx)
            end if
            
            ! application method
            call rdsinr ('isuas',0,2,isuas)
            
            ! extra info in case of subsurface irrigation
            if (rdinqr('irr_rate')) then
               call rdsdor('irr_rate',   0.1d0,  100.0d0, irr_rate)        ! mm/h
               irr_rate   = 0.1d0*24.0d0*irr_rate                          ! from mm/h to cm/d
            else
               irr_rate = 0.0d0
            end if
            if (isuas == 2) then
               if (.NOT. rdinar('ss_irr_z')) then
                  ! application at single depth (single compartment)
                  call rdsdor('ss_irr_z', -100.0d0, 0.0d0, dummy)             ! cm
                  ir_z(1) = dummy
                  ir_z(2) = dummy
               else
                  ! application over depth interval between two depth levels (multiple consecutive compartments)
                  call rdfdor('ss_irr_z',-100.0d0, 0.0d0, ir_z, 2, 2)         ! cm
               end if
               ! determine layer number where SSDI takes place
               do j = 1, 2
                  i = 1
                  do while (zbotcp(i) > (ir_z(j) + 1.0d-5))
                     i = i + 1
                  end do
                  nod_ssdi(j) = i
               end do
            end if
         
            ! solute concentration irrigation water
            cirrs = 0.0d0 
            if (swsolu == 1) call rdsdor ('cirrs',0.0d0,100.0d0,cirrs)

            ! timing criteria
            call rdsinr ('tcs',1,8,tcs)
            if (tcs == 5) then
               message = 'Option TCS=5 (together with PHORMC) is obsolete and cannot be used anymore.'
               call swap_warning ('irrigation', message)
               message = 'Use option TCS=7 for pressure head (previously: TCS=5 + PHORMC=0) or TCS=8 for water content (previously: TCS=5 + PHORMC=1).'
               call swap_warning ('irrigation', message)
               call swap_error ('irrigation', 'Option TCS=5 (together with PHORMC) is obsolete and cannot be used anymore.')
            end if

            ! timing - allowable daily stress (ratio actual/potential transpiration)
            if (tcs == 1) then
               call rdador('dvs_tc1',0.0d0,2.0d0,dvstage,7,ifnd)
               call rdfdor('trel',0.0d0,1.0d0,trel,7,ifnd)
               do i = 1, ifnd
                  treltab(i*2) = trel(i)
                  treltab(i*2-1) = dvstage(i)
               end do
            end if

            ! timing - depletion of readily available water
            if (tcs == 2) then
               call rdador('dvs_tc2',0.0d0,2.0d0,dvstage,7,ifnd)
               call rdfdor('raw',0.0d0,1.0d0,raw,7,ifnd)
               do i = 1, ifnd
                  rawtab(i*2) = raw(i)
                  rawtab(i*2-1) = dvstage(i)
               end do
            end if

            ! timing - depletion of totally available water
            if (tcs == 3) then
               call rdador('dvs_tc3',0.0d0,2.0d0,dvstage,7,ifnd)
               call rdfdor('taw',0.0d0,1.0d0,taw,7,ifnd)
               do i = 1, ifnd
                  tawtab(i*2) = taw(i)
                  tawtab(i*2-1) = dvstage(i)
               end do
            end if

            ! timing - allowable depletion amount
            if (tcs == 4) then
                call rdador('dvs_tc4',0.0d0,2.0d0,dvstage,7,ifnd)
                call rdfdor('dwa',0.0d0,500.0d0,dwa,7,ifnd)
                do i = 1, ifnd
                  dwatab(i*2) = dwa(i)
                  dwatab(i*2-1) = dvstage(i)
               end do
            end if

            ! timing - critical press. head or moist. content at sensor depth
            ! OBSOLETE replaced by tcs=7 or tcs=8; see below  (july, 2019)

            ! timing - fixed intervals, weekly with threshold (below it: no irrigation)
            if (tcs == 6) then
               call rdsdor ('irgthreshold',0.0d0,20.0d0,irgthreshold)
            end if

            ! timing - fixed intervals
            call rdsinr ('tcsfix',0,1,tcsfix)
            if (tcsfix == 1) then
               if (tcs == 6) then   
                  message = 'Timing criteria: conflict with fixed intervals tcsfix=1 AND tcs=6 not allowed, adapt input !'
                  call swap_error ('irrigation', message)
               end if
               call rdsinr('irgdayfix',1,366,irgdayfix)
            end if

            ! timing - critical pressure head at sensor depth (dcrit; read later)
            swcirrthres = 0
            if (tcs == 7) then
               call rdador ('dvs_tc7',0.0d0,2.0d0,dvstage,7,ifnd)
               call rdfdor ('value_tc7',-1.0d6,100.0d0,hcri,7,ifnd)
               do i = 1, ifnd
                  hcritab(i*2)   = hcri(i)
                  hcritab(i*2-1) = dvstage(i)
               end do
            end if
            
            ! timing - critical water content at sensor depth (dcrit; read later)
            if (tcs == 8) then
               call rdador ('dvs_tc8',0.0d0,2.0d0,dvstage,7,ifnd)
               call rdfdor ('value_tc8',0.0d0,1.0d0,tcri,7,ifnd)
               do i = 1, ifnd
                  tcritab(i*2)   = tcri(i)
                  tcritab(i*2-1) = dvstage(i)
               end do
            end if
            
            if (tcs == 7 .OR. tcs == 8) then
            
               ! sensor depth
               call rdsdor ('dcrit',-100.0d0,0.0d0,dcrit)
            
               ! determine compartment number of sensor depth
               i = 1
               do while (zbotcp(i) > (dcrit + 1.0d-5))
                  i = i+1
               end do
               nodsen = i

               ! in case of solutes: allow overirrigation when conc exceeds concthreshold
               cirrthres = 0.0d0
               perirrsurp = 0.0d0
               if (rdinqr('swcirrthres')) then
                  call rdsinr ('swcirrthres',0,1,swcirrthres)
                  if (swcirrthres == 1) then
                     call rdsdor ('cirrthres', 0.0d0,100.0d0,cirrthres)
                     call rdsdor ('perirrsurp',0.0d0,100.0d0,perirrsurp)
                  end if
               end if

            end if

            ! depth criteria
            call rdsinr ('dcs',1,2,dcs)

            ! field capacity as input for timing and depth options
            if (tcs == 2 .OR. tcs == 3 .OR. tcs == 4 .OR. dcs == 1) then
               call rdsdor('phfieldcapacity',-500.0d0,0.0d0,phlo)
            else
               phlo = -100.0d0
            end if

            ! depth - back to field capacity
            if (dcs == 1) then
               call rdador('dvs_dc1',0.0d0,2.0d0,dvstage,7,ifnd)
               call rdfdor('di',-100.0d0,+100.0d0,di,7,ifnd)
               raithreshold = 0.0d0
               if (rdinqr('raithreshold')) then
                  call rdsdor('raithreshold',0.0d0,1000.0d0,raithreshold)
               end if
               do i = 1, ifnd
                  ditab(i*2)   = di(i)
                  ditab(i*2-1) = dvstage(i)
               end do
            end if

            ! depth - fixed depth
            if (dcs == 2) then
               call rdador('dvs_dc2',0.0d0,2.0d0,dvstage,7,ifnd)
               call rdfdor('fid',0.0d0,400.0d0,fid,7,ifnd)
               do i = 1, ifnd
                  fidtab(i*2)   = fid(i)
                  fidtab(i*2-1) = dvstage(i)
               end do
            end if

            ! depth - limited by min and max
            call rdsinr ('dcslim',0,1,dcslim)
            if (dcslim == 1) then
               call rdsdor('irgdepmin',0.0d0,100.0d0,irgdepmin)
               call rdsdor('irgdepmax',irgdepmin,1.0d7,irgdepmax)
            else
               irgdepmin = 0.0d0
               irgdepmax = 1.0d7
            end if

            ! for some options some constants can be computed once (per crop) and stored
            if (tcs > 1) then
               call rdsdor ('hlim3h',-10000.0d0,100.0d0,hlim3h)
               call rdsdor ('hlim3l',-10000.0d0,100.0d0,hlim3l)
               call rdsdor ('hlim4' ,-20000.0d0,100.0d0,hlim4)
               phme = (hlim3l + hlim3h) * 0.5d0
               phhi = hlim4
               do i = 1, numlay
                  node     = botcom(i)    ! bottom most compartment per soil layer
                  wclos(i) = watcon(node,phlo)
                  wcmes(i) = watcon(node,phme)
                  wchis(i) = watcon(node,phhi)
               end do
            end if

         end if

         cirr = 0.0d0

         ! close input file
         close(unit_crp)
         
         return
      
      case (2)
         
         if (schedule == 1) then
            
            ! read crop data of former day from *.END file
            !if (fl_initialize .AND. .NOT. fl_start_croprotation) then

!               ! open inifile
!               call rdinit(unit_ini,unit_err,inifilnam)
!
!               ! irrigation
!               call rdsinr ('flirrigate',0,1,sw_value)
!               flirrigate = sw_value == 1
!
!               if (flirrigate) then
!                  call rdsinr ('dayfix',0,366,dayfix)
!               end if
!        
!               ! close inifile
!               close(unit_ini)
        
            !else
            if (.NOT. fl_initialize .OR. fl_start_croprotation) then
               
               ! irrigation
               flirrigate = .TRUE.
               dayfix = 366
      
            end if         
         
         end if

         return
         
      case (3)

         ! determine irrigation rates and states
      
         gird            = 0.0d0
         irrigevent      = 0
         cirr            = 0.0d0
         irr_depth       = 0.0d0
         qssdi(1:numnod) = 0.0d0
         dt_irr_event   = 1.0d0
         qssdisum        = 0.0d0

         ! fixed irrigations events
         if (swirfix == 1) then
            if (abs(irdate(nirri) - t1900) < 1.d-3) then
               isua = irtype(nirri)
               if (isua < 2) then
                  !gird = irdepth(nirri)
                  gird = irrate(nirri)
                  cirr = irconc(nirri)
               else
                  qssdi(nod_ssdi(1):nod_ssdi(2)) = irrate(nirri) 
                  qssdisum                       = qssdisum + sum(qssdi(nod_ssdi(1):nod_ssdi(2)))
               end if
               dt_irr_event = irdepth(nirri) / irrate(nirri)     ! end time (fraction of day) of irrigation event
               nirri = nirri + 1
               irrigevent = 1
            end if
         end if

         ! scheduled timing within desired period?
         if (schedule == 1) then
            flIrriTime = .FALSE.
            if (yearendcrp > yearstacrp) then
               if ( (t1900 - tstairryrx) > 1.0d-3 .AND. (t1900 - tendirryrx) <= 1.0d-3 ) then
                  flIrriTime = .TRUE.
               end if
            else
               if ((t - tstairrig) >= -1.0d-3 .AND. (t - tendirrig) <= 1.0d-3) then
                  flIrriTime = .TRUE.
               end if
            end if
         end if

         if (sw_irrig == 1 .AND. schedule == 1 .AND. irrigevent == 0 .AND. fl_cropemergence .AND. flIrriTime) then
            
            cirr = cirrs
            isua = isuas

            ! determine water holding capacity, readily available water, actual available water and water deficit
            if (tcs > 1) then
               frlow = (ztopcp(noddrz) + rd) / dz(noddrz)
               awlh = 0.0d0; awmh = 0.0d0; awah = 0.0d0; cdef = 0.0d0
               do node = 1,noddrz
                  wclo = wclos(layer(node)) * dz(node); if (node == noddrz) wclo = wclo * frlow
                  wcme = wcmes(layer(node)) * dz(node); if (node == noddrz) wcme = wcme * frlow
                  wchi = wchis(layer(node)) * dz(node); if (node == noddrz) wchi = wchi * frlow
                  wcac = watcon(node,h(node)) * dz(node); if (node == noddrz) wcac = wcac * frlow
                  awlh = awlh + (wclo - wchi)
                  awmh = awmh + (wcme - wchi)
                  awah = awah + (wcac - wchi)
                  cdef = cdef + (wclo - wcac) 
               end do
            end if

            ! timing - allowable daily stress - only under dry or saline stress circumstances
            if (tcs == 1) then
               
               tps1 = afgen(treltab,14,dvs)
               
               ! transpiration fraction due to drought and salinity stress
               if (iptra_day > 1.d-10) then
                  Tred = 1.0d0 - (iqreddry_day + iqredsol_day) / iptra_day
               else
                  Tred = 1.0d0
               end if
               if (Tred < tps1) irrigevent = 2
            end if

            ! timing - depletion of readily available water (fraction)
            if (tcs == 2) then
               
               ! compare readily available water and actual available water
               tps2 = afgen(rawtab,14,dvs)
               depl = tps2 * (awlh - awmh)
               if (depl > awlh) depl = awlh 
               if (awah < (awlh - depl)) irrigevent = 2
            
            end if

            ! timing - depletion of totally available water (fraction)
            if (tcs == 3) then
               
               ! compare totally available water and actual available water
               tps3 = afgen(tawtab,14,dvs)
               depl = tps3 * awlh
               if (awah < (awlh - depl)) irrigevent = 2
            
            end if

            ! timing - allowable amount of depletion
            if (tcs == 4) then
               
               ! check if depletion amount has been exceeded                
               tps4 = afgen(dwatab,14,dvs)
               if ((awlh-awah) > (tps4 * 0.1d0)) irrigevent = 2
            
            end if

            ! timing - critical pressure head or moisture content exceeded
            ! OBSOLETE: replaced by tcs=7 or tcs=8

            ! timing - fixed irrigation time (weekly during crop growth)
            if (tcs == 6) then

               ! (weekly) irrigation only when deficit is higher then threshold cdef (cm) en IrgThreshold (mm)
               dayfix = dayfix + 1
               if (dayfix >= 7)  then
                  dayfix = 0
                  if (10.0d0 * cdef > irgthreshold) then
                     irrigevent = 2
                  end if
               end if

            end if

            ! timing - critical pressure head at dcrit (node=nodsen) exceeded
            if (tcs == 7) then

               ! calculation of critical pressure head
               tps5 = afgen(hcritab,14,dvs)
               phcrit = tps5
               if (h(nodsen) <= phcrit) irrigevent = 2
            end if

            ! timing - critical watercontent at dcrit (node=nodsen) exceeded
            if (tcs == 8) then
               
               tps5 = afgen(tcritab,14,dvs)
               ! compare critical water content and actual water content
               if (theta(nodsen) <= tps5) irrigevent = 2
            
            end if

            ! timing - fixed intervals
            if (tcsfix == 1) then

               if (irrigevent == 2 .AND. (dayfix >= irgdayfix)) then
                  irrigevent = 2
                  dayfix = 1
               else
                  irrigevent = 0
                  if (dayfix < irgdayfix) dayfix = dayfix + 1
               end if
            
            end if

            ! Amount and rate
            if (irrigevent == 2) then
               
               ! depth - back to field capacity [cm]
               if (dcs == 1) then
                  ! correct for over- or under irrigation
                  dps1 = afgen(ditab,14,dvs)
                  ! option to reduce irrigation on rainy (> raithreshold) day
                  grai_red = 0.0d0
                  if (grai > raithreshold) grai_red = grai
                  irr_depth = max (0.0d0, cdef + dps1 * 0.1d0 - grai_red)
               end if

               ! depth - fixed depth [cm]
               if (dcs == 2) then
                  dps2 = afgen(fidtab,14,dvs)
                  irr_depth = dps2 * 0.1d0
               end if

               ! depth - limited depth [cm]
               if (dcslim == 1) then
                  irr_depth = max(irr_depth, irgdepmin * 0.1d0)
                  irr_depth = min(irr_depth, irgdepmax * 0.1d0)
               end if

               ! in case of solutes: allow overirrigation when conc exceeds concthreshold
               if (swsolu == 1  .AND. swcirrthres == 1) then
                  if (cml(nodsen) > cirrthres) then
                     irr_depth = irr_depth + 0.01d0 * perirrsurp * irr_depth
                  end if
               end if
               
               ! Rates
               if (irr_rate > 0.0d0) then
                  if (irr_depth/irr_rate > 1.0d0) then
                     call swap_warning('irrigation', 'irr_depth/irr_rate > 1.0d0; irr_rate temporarily adapted')
                     if (isuas < 2) then
                        gird = irr_depth
                     else
                        qssdi(nod_ssdi(1):nod_ssdi(2)) = irr_depth
                        qssdisum                       = qssdisum + sum(qssdi(nod_ssdi(1):nod_ssdi(2)))
                     end if
                     dt_irr_event = 1.0d0
                  else
                     if (isuas < 2) then
                        gird = irr_rate
                     else
                        qssdi(nod_ssdi(1):nod_ssdi(2)) = irr_rate
                        qssdisum                       = qssdisum + sum(qssdi(nod_ssdi(1):nod_ssdi(2)))
                     end if
                     dt_irr_event = irr_depth/irr_rate
                  end if
               else
                  ! irrigation supplied spread evenly over the whole day
                  if (isuas < 2) then
                     gird = irr_depth
                  else
                     qssdi(nod_ssdi(1):nod_ssdi(2)) = irr_depth
                     qssdisum                       = qssdisum + sum(qssdi(nod_ssdi(1):nod_ssdi(2)))
                  end if
                  dt_irr_event = 1.0d0
               end if

            end if ! irrigevent == 2

         end if
         
         return

      case(4)
         ! possible: limited by external model
         gird = gird * f_irr_avail
         if (irr_rate > 0.0d0) dt_irr_event = dt_irr_event * f_irr_avail

      case(9)
         ! special: reset scheduled irrigation at end of irrigation event
         irrigevent      = 0
         gird            = 0.0d0
         qssdi(1:numnod) = 0.0d0
         dt_irr_event    = 1.0d0
         qssdisum        = 0.0d0
         
      case default
         
         call swap_error ('irrigation', 'Illegal value for TASK')
      
      end select

      return
   
      end subroutine irrigation
      
      subroutine read_irrigation_fixed()
         use MOD_swap_base, only: unit_err, unit_swp, swpfilnam, pathwork, iun_min2, iun_max2, swsolu
         use MOD_arrays,    only: fillen
         use MOD_grid,      only: zbotcp
         use variables,     only: tstart, tend
         implicit none
         ! local
         integer                 :: i, j, ifnd, swirgfil, unit_irg
         real(8)                 :: dummy
         character(len=fillen)   :: irgfil, filnam
         logical                 :: file_exists
         ! functions
         integer                 :: getun2
         logical                 :: rdinqr, rdinar

         swirgfil = 0
         irgfil = ' ' 
         irconc = 0.d0
         call rdsinr ('swirgfil',0,1,swirgfil)
         if (swirgfil == 1) then
            ! input from separate file 
            call rdscha ('irgfil',irgfil)
            close (unit_swp)   ! we must close main input file, so that soils database can be accessed by rdinit
            filnam = trim(pathwork)//trim(irgfil)//'.irg'
            inquire(file = filnam, exist = file_exists)
            if (.NOT. file_exists) call swap_error ('readswap', 'File '//trim(filnam)//' does not exists!')
            unit_irg = getun2 (iun_min2, iun_max2, 2)
            call rdinit(unit_irg,unit_err,filnam)
         end if
         call rdatim ('irdate',irdate,mairg,ifnd)
         call rdfinr ('irtype',0,2,irtype,mairg,ifnd)
         if (rdinqr('irrate')) then
            call rdfdor('irdepth',0.01d0,100.0d0,irdepth,mairg,ifnd)       ! mm
            call rdfdor('irrate',0.0d0,100.0d0,irrate,mairg,ifnd)          ! mm/h
         else
            ! backward compatibility
            call rdfdor ('irdepth',0.01d0,100.d0,irdepth,mairg,ifnd)       ! mm
            irrate(1:ifnd) = irdepth(1:ifnd)/24.0d0                        ! mm/h
         end if

         ! check if irdate is ascending, and determine initial entry point nirri
         nirri = 1
         do i = 1, ifnd-1
            if (irdate(i) >= irdate(i+1)) call swap_error ('readswap', 'irdate not in ascending order')
            if (tstart >= irdate(i)) nirri = i
         end do
         if (tstart >= irdate(ifnd)) nirri = ifnd
         
         ! additional information in case of subsurface irrigation
         if (maxval(irtype) == 2) then
            call rdfdor('irrate',0.0d0,100.0d0,irrate,mairg,ifnd)       ! mm/h
            if (.NOT. rdinar('ir_z')) then
               ! application at single depth (single compartment)
               call rdsdor('ir_z', -100.0d0, 0.0d0, dummy)              ! cm
               ir_z(1) = dummy
               ir_z(2) = dummy
            else
               ! application over depth interval between two depth levels (multiple consecutive compartments)
               call rdfdor('ir_z',-100.0d0, 0.0d0, ir_z, 2, 2)          ! cm
            end if
                  ! determine layer number where SSDI takes place
            do j = 1, 2
               i = 1
               do while (zbotcp(i) > (ir_z(j) + 1.0d-5))
                  i = i + 1
               end do
               nod_ssdi(j) = i
            end do

            ! redefine application rate: uniformly spread over all nodes
            do i = 1, ifnd
               if (irtype(i) == 2) irdepth(i) = irdepth(i)/dble((nod_ssdi(2) - nod_ssdi(1) + 1))
            end do
         end if
         
         if (swsolu > 0) call rdfdor ('irconc',0.d0,1000.d0,irconc,mairg,ifnd)
! -      at least one date must be within simulation period
         call checkdate(ifnd,irdate,tend,tstart,'irdate', 'readswap/swirfix=1      ')

! ---    convert mm irrigation to cm; 
         irdepth = 0.1d0*irdepth
         irrate  = 0.1d0*24.0d0*irrate    ! from mm/h to cm/d

         do i = 1, ifnd
            if (irdepth(i) / irrate(i) > 1.0d0) call swap_error('readswap', 'You cannot consider irrigation duration times > 1 d')
         end do
         
         if (swirgfil == 1) then
            close(unit_irg)
            call rdinit(unit_swp,unit_err,swpfilnam)     ! open main input file again
         end if
      
      end subroutine read_irrigation_fixed
      
end module MOD_irrigation
