! File VersionID:
!   $Id: fluxes.f90 298 2016-07-25 20:07:31Z kroes006 $
! ----------------------------------------------------------------------
      subroutine fluxes ()
! ----------------------------------------------------------------------
!     date               : 29/9/99
!     purpose            : calculates the fluxes between compartments
! ----------------------------------------------------------------------
      use MOD_swap_base,  only: swmacro
      use MOD_grid,       only: numnod, dz
      use MOD_integral,   only: inq
      use MOD_drain,      only: qdra,qdrtot,nrlevs
      use MOD_swap_mp,    only: FrArMtrx,QExcMpMtx,QMaPo
      use MOD_irrigation, only: qssdi, qssdisum
      use variables,      only: q,qbot,dt,thetm1,theta,qrot,qimmob,qtop,volact,volm1,swbotb,fllowgwl
      use MOD_re_global,  only: qrosum
      implicit none

! --- global

! --- local
      integer  :: i

! ----------------------------------------------------------------------

! --- determine qbot if not specified
!      if (swbotb == 5 .OR. swbotb == 7 .OR. swbotb == 8 .OR. swbotb == -2 .OR. (swbotb == 1 .AND. fllowgwl) .OR. swbotb == 9) then
      if (swbotb == 5 .OR. swbotb == 7 .OR. swbotb == 8 .OR. swbotb == -2 .OR. (swbotb == 1 .AND. fllowgwl)) then
         qbot = qtop + qrosum + qdrtot  + (volact-volm1)/dt - qssdisum
         if (swmacro == 1) qbot = qbot - QMaPo
      end if

! --- calculate fluxes (cm/d) from changes in volume per compartment
      i      = numnod+1
      q(i)   = qbot
      inq(i) = inq(i) + q(i)*dt
      do i = numnod, 1, -1
         if (swmacro == 0) then
            q(i) = - (theta(i)-thetm1(i)+qimmob(i))*dz(i)/dt + q(i+1)-qrot(i)+qssdi(i)
         else
            q(i) = - (theta(i)-thetm1(i)+qimmob(i))*FrArMtrx(i)*dz(i)/dt + q(i+1)-qrot(i)+QExcMpMtx(i)+qssdi(i)
         end if
         q(i)   = q(i) - sum(qdra(1:nrlevs,i))
         inq(i) = inq(i) + q(i)*dt
      end do

      return
      end subroutine fluxes

