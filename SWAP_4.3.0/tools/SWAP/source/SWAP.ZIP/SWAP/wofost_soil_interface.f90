! File VersionID:
!   $Id: wofost_soil_interface.f90 307 2016-09-12 17:41:52Z kroes006 $
! ----------------------------------------------------------------------
module wofost_soil_interface

   real(8), save :: idwrt, idwlv, idwst, idwso
   real(8), save :: iNLOSSL,  iNLOSSR, iNLOSSS, iNLOSSO

   real(8), save :: NdemandSoil                   ! total N demand of leaves, stems and roots (kg/ha N)
   real(8), save :: NsupplySoil                   ! total mineral N from soil and fertiliser (kg/ha N)

   real(8), save :: Ndemand                       ! total N demand of leaves, stems and roots (kg/m2 N)
   real(8), save :: Nsupply                       ! total mineral N from soil and fertiliser (kg/m2 N)

   real(8), save :: LaiCritNupt                   ! critical LAI value for N-uptake driven by transpiration or dry matter increase (kg/m2 N)

end module wofost_soil_interface
