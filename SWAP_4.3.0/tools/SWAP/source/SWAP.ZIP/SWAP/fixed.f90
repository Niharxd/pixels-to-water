module MOD_fixed

   use MOD_arrays, only: macroptb   

   implicit none

   ! phenology
   integer, save :: idev                              ! switch for length of growth period in case of simple crop: 1 = fixed; 2 = depends on temperature sum
   integer, save :: lcc                               ! length of crop cycle (d)
   real(8), save :: tsumea                            ! temperature sum from emergence to anthesis (degree C)
   real(8), save :: tsumam                            ! temperature sum from anthesis to maturity (degree C)
   real(8), save :: tbase                             ! start value of temperature sum (degree C)

   ! leaf area index
   real(8), dimension(macroptb), save :: laitb        ! array with leaf area index (cm2/cm2)   

   ! harvest
   integer, save :: sw_harv                           ! switch for timing of harvest (0=cropend, 1=maturity)
   real(8), save :: dvsend                            ! development stage at harvest (-)

   private
   
   public :: cropfixed
   public :: idev, sw_harv, laitb, lcc, tsumea, tsumam, tbase, dvsend
   
   contains
   
   ! ---------------------------------------------------------------------

   subroutine cropfixed (task)

      ! ------------------------------------------------------------------

      use plant_interface, only: icrop, cropend, fl_cropemergence, fl_cropharvest, dvs
      use variables, only: t1900
   
      implicit none
      
      integer, intent(in) :: task

      ! ------------------------------------------------------------------

      select case (task)
      
      case (1)

         ! read crop data
         call read_cropfixed ()

      case (2)

         ! initialize crop data
         call initialize_cropfixed ()

      case (3)   

         ! calculate actual rate and state variables
         call update_cropfixed ()

      case (4)
         
         ! check end of cropping period
         if (sw_harv == 0) then
            if (dabs(t1900 - cropend(icrop) - 1.d0) < 0.1d0) then
               fl_cropemergence = .FALSE.
               fl_cropharvest = .TRUE.
            end if
         else
            if (dvs >= dvsend .OR. dabs(t1900 - cropend(icrop) - 1.d0) < 0.1d0) then
               fl_cropemergence = .FALSE.
               fl_cropharvest = .TRUE.
            end if
         end if

      case default

         call swap_error ('cropfixed', 'Illegal value for TASK')

      end select

      return

   end subroutine cropfixed
   
   ! ---------------------------------------------------------------------

   subroutine read_cropfixed ()
   
      ! ------------------------------------------------------------------

      use MOD_swap_base, only: unit_err
      use plant_interface,only: unit_crp, crpfilnam, kdif, kdir

      implicit  none
      
      ! locals
      integer :: swgc
      character(len=200) :: message

      ! functions
      logical :: rdinqr
      
      ! ------------------------------------------------------------------

      ! open connection
      call rdinit(unit_crp, unit_err, crpfilnam)

      ! phenology
      call rdsinr ('idev', 1, 2, idev)
      if (idev == 1) then
         call rdsinr ('lcc', 1, 366, lcc)
      else
         call rdsdor ('tsumea', 0.d0, 1.d4, tsumea)
         call rdsdor ('tsumam', 0.d0, 1.d4, tsumam)
         call rdsdor ('tbase', -10.d0, 30.d0, tbase)
      end if
      
      ! - leaf area index -

      ! check usage of soil cover fraction (deprecated)
      if (rdinqr('swgc')) then
         call rdsinr ('swgc', 1, 2, swgc)
         if (swgc == 1) then
            message = 'Switch SWGC is deprecated, specify Leaf Area Index instead (LAITB)!' 
            call swap_warning ('leafareaindex', message)
            call rdadortb ('gctb', 0.d0, 2.d0, 0.d0, 12.d0, laitb, macroptb, .FALSE.)
         else
            message = 'Option with usage Soil Cover Fraction (SWGC = 2) is deprecated, specify Leaf Area Index instead (LAITB)!' 
            call swap_error ('readcropfixed', message)
         end if

      else

         ! leaf area index
         call rdadortb ('laitb', 0.d0, 2.d0, 0.d0, 12.d0, laitb, macroptb, .FALSE.)

      end if      

      ! light interception
      call rdsdor ('kdif', 0.d0, 2.d0, kdif)
      call rdsdor ('kdir', 0.d0, 2.d0, kdir)
     
      ! timing of harvest
      if (rdinqr('swharv')) then
         call rdsinr ('swharv', 0, 1, sw_harv)
         if (sw_harv == 1) then
            if (rdinqr('dvsend')) then
               call rdsdor ('dvsend', 0.d0, 2.d0, dvsend)
            else
               dvsend = 2.d0
            end if
         end if
      else
         sw_harv  = 0    
      end if
      
      ! close file with crop data
      close (unit_crp)

      return

   end subroutine read_cropfixed
   
   ! ---------------------------------------------------------------------
   
   subroutine initialize_cropfixed ()
   
      ! ------------------------------------------------------------------
      
      use plant_interface, only: fl_start_cropemergence, sw_drought, sw_oxygen, max_resp_factor, swrdc, wroottb, mrftb, &
                                 sicact, dvs, tsum, lai, wrt

      implicit  none
      
      ! functions
      real(8) :: afgen
      
      ! ------------------------------------------------------------------

      if (fl_start_cropemergence) then
         
         ! interception
         sicact = 0.d0

         ! crop development
         dvs = 0.d0
         tsum = 0.d0
      
      end if

      ! - Leaf area index -
      
      ! initial lai
      lai = afgen (laitb, macroptb, dvs)

      ! initial dry weight of roots; oxygen module, drought module with microscopic water uptake or adaptive rootdistribution
      if (swrdc == 1 .OR. sw_drought > 1 .OR. sw_oxygen == 2) wrt = afgen (wroottb, macroptb, dvs)

      ! initial ratio root total respiration / maintenance respiration; oxygen module
      if (sw_oxygen == 2) max_resp_factor = afgen (mrftb, macroptb, dvs)      
      
      return
      
   end subroutine initialize_cropfixed
   
   ! ---------------------------------------------------------------------

   subroutine update_cropfixed ()

      ! ------------------------------------------------------------------

      use atmosphere_interface,only: tav
      use plant_interface, only: swrdc, wroottb, sw_drought, sw_oxygen, max_resp_factor, mrftb, &
                                 dvs, tsum, lai, wrt, grrt, drrt, grrtpot

      implicit none

      ! local
      real(8) :: dtsum, dvr
      real(8) :: wrt_old

      ! functions
      real(8) :: afgen

      ! ------------------------------------------------------------------

      ! calculate actual rate and state variables

      ! - update phenology -

      ! increase in temperature sum
      dtsum = max (0.d0, tav - tbase)

      ! development rate
      if (idev == 1) then
         dvr = 2.d0 / dble(lcc)
      else
         if (dvs < 1.d0) then
            dvr = dtsum / tsumea
         else
            dvr = dtsum / tsumam
         end if
      end if

      ! phenological development stage
      dvs = min(dvs + dvr, 2.d0)
      tsum = tsum + dtsum
      
      ! - leaf area index -

      ! update leaf area index
      lai = afgen (laitb, macroptb, dvs)

      ! dry weight of plant roots; oxygen module, drought module with microscopic water uptake or adaptive rootdistribution
      if (swrdc == 1 .OR. sw_drought > 1 .OR. sw_oxygen == 2) then
         wrt_old = wrt
         wrt = afgen (wroottb, macroptb, dvs)
         grrt = max(0.d0, wrt - wrt_old)
         grrtpot = grrt
         drrt = dabs(min(0.d0, wrt - wrt_old))
      end if

      ! ratio root total respiration / maintenance respiration; oxygen module
      if (sw_oxygen == 2) max_resp_factor = afgen (mrftb, macroptb, dvs)

      return

   end subroutine update_cropfixed
    
   ! ---------------------------------------------------------------------   
    
end module MOD_fixed
    