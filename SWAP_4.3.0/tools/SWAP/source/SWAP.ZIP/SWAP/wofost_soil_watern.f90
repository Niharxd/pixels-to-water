! File VersionID:
!   $Id: wofost_soil_watern.f90 298 2016-07-25 20:07:31Z kroes006 $
! ----------------------------------------------------------------------
      Subroutine Wofost_SoilWaterN(dz, dt, WFrac_t, WFrac_t0,           &
                       Wflux_out, Wflux_transp,Wflux_inBot, Wflux_inTop,&
                       Wflux_inLat,TCSF, Ratecon, ProducPot, ProducAct, &
                       SorpCoef,Cseep,Ctop, Clat, C_t0, C_t, C_av)

      use MOD_texture_orgmat, only: bdens
      
!0    Declarations
            
      implicit none
!0.1  inputs
      real(8), intent(in)  :: WFrac_t, WFrac_t0, Wflux_out, Wflux_transp, Wflux_inBot, Wflux_inTop, Wflux_inLat
      real(8), intent(in)  :: C_t0, Cseep, Ctop, Clat
      real(8), intent(in)  :: dz, dt, TCSF, Ratecon, ProducPot, SorpCoef 

!0.2  Outputs
      real(8), intent(out) :: C_t, C_av, ProducAct

!0.3  intermediatelocal variables
      Integer :: Iflsol
      real(8) :: A1, A2, B1, B2
      real(8) :: WFrac_av, C_av1
      real(8) :: Hv, Hv1, Hv2, Hv3, Ttry
      real(8) :: Small, Vsmall, Vvsmall, Zero, Half, One
      Logical :: Hv1nil,Hvnil

      Data       Zero, Small, Vsmall, Vvsmall, Half, One                &
                 /0.0d+00, 1.0d-08, 1.0d-12, 1.0d-20, 0.5d+00, 1.0d+00/
      

!        help variables in analytical solution and test for small values
!     HV       rate of change in moisture content [d-1]
!     HV1      rate of disappearance (outflow+decomposition) [d-1]
!     HV2      total nett inflow of substance per timestep [kg m-1 d-1}

      ProducAct = ProducPot

      WFrac_av = Half * (WFrac_t + WFrac_t0)
      Hv = (WFrac_t - WFrac_t0)/dt
      Hvnil = .False.
      if ( abs(Hv) < Small ) then
        Hv    = Zero
        Hvnil = .True.
      End If

      Hv1 = HV + Wflux_out/dz + TCSF*Wflux_transp/dz + Ratecon*WFrac_av
      Hv1nil = .False.
      if ( abs(Hv1) < Small ) then
        Hv1 = Zero
        Hv1nil = .True.
      End If

      Hv2 = Wflux_inBot * Cseep / dz + Wflux_inTop * Ctop / dz +        &
            Wflux_inLat * Clat / dz + ProducPot

!                                   test for type of analytical solution

      if (.Not.Hvnil.And. .Not.Hv1nil) then
         if (abs(Hv-Hv1) > Small) then
           Iflsol = 1
         Else
           Iflsol = 2
         End If
      Else if (Hvnil .And. .Not. Hv1nil) then
         Iflsol = 3
      Else if (.Not.Hvnil .And. Hv1nil) then
         Iflsol = 4
      Else if (Hvnil .And. Hv1nil) then
         Iflsol = 5
      End If

      if (Iflsol == 1 .Or. Iflsol == 2) then

         if ( WFrac_t*dz <= 1.0d-6 .And. WFrac_t0*dz > 1.0d-6) then
            C_t  = 0.0d0
            C_av = (Hv2 - Hv * C_t0)/(Hv1 - Hv)
            Return
         Else if (WFrac_t*dz > 1.d-6 .And. WFrac_t0*dz <= 1.d-6) then
            C_t  = Hv2/hv1
            C_av = Hv2/hv1
            Return
         end if

      Else If (Iflsol == 4) Then

         if (WFrac_t*dz <= 1.0d-6 .And. WFrac_t0*dz > 1.0d-6) then
            C_t  = 0.0d0
            C_av = C_t0 - Hv2/hv
            Return
         Else if (WFrac_t*dz > 1.d-6 .And. WFrac_t0*dz <= 1.d-6) then
            C_t  = Hv2/hv
            C_av = Hv2/hv
            Return
         end if

      End If

!     solution when the amount of disappearance equals the amount of 
!     nett inflow (HV2 equals C_t0*HV1):
      If (Iflsol <= 3 .And.  abs(Hv1*C_t0-Hv2) <= Vvsmall) Then
        C_t  = C_t0
        C_av = C_t0
        Return
      End If
!                                                 determine coefficients
      Call Detcoef2(Iflsol,A1,A2,SorpCoef,B1,B2,Hv,Hv1,WFrac_t0,dt)

!                                                        compute results
      C_t  = A1 * C_t0 + A2 * Hv2
      C_av = B1 * C_t0 + B2 * Hv2

!     if negative concentrations are calculated reduce REKO and the
!     concentrations 
      If ( C_t < Zero ) then

!       the long term steady state concentration (HV2/HV1) is greater 
!       than VSMALL  while the amount disappearance exceeds the amount 
!       of nett inflow;
!         or 
!       VSMALL exceeds the long term steady state concentration while
!       the amount of nett inflow exceeds the amount of disappearance:
        If (C_t+Vsmall > Zero  .Or.  Iflsol <= 3 .And.                 &
            (Hv1*Vsmall-Hv2)/(Hv1*C_t0-Hv2) < Vsmall) Then
            C_t   = C_t0
            C_av  = C_t0
            Return
        End If
 
!       calculate help-variable:
        Hv3 = WFrac_t0 + bdens(1) * SorpCoef

!       reduce TTRY (analytical solutions):
        If (Iflsol <= 2) Then
            Ttry = Hv3/hv*(((Hv1*Vsmall-Hv2)/(Hv1*C_t0-Hv2))**(-Hv/hv1)-One)
        Else If (Iflsol == 3) Then
            Ttry = -Hv3/hv1*log((Hv1*Vsmall-Hv2)/(Hv1*C_t0-Hv2))
        Else If (Iflsol == 4) Then
            Ttry = Hv3/hv*(exp(Hv/hv2*(Vsmall-C_t0))-One)
        Else If (Iflsol == 5) Then
            Ttry = Hv3/hv2*(Vsmall-C_t0)
        End If     
!                                                 determine coefficients
        C_t  = Vsmall
!ckro - 20160504 solution to prevent Ttry=0 and then divide by zero
       if (Ttry < Vsmall) then
            C_av1  = Vsmall
            C_av  = Vsmall
            ProducAct =  Vsmall
        else
            Call Detcoef2(Iflsol,A1,A2,SorpCoef,B1,B2,Hv,Hv1,WFrac_t0,Ttry)
            C_av1  = B1*C_t0 + B2*Hv2
            C_av  = (Ttry * (WFrac_t0+Half*Ttry*Hv) * C_av1+(dt-Ttry)*  &
                (WFrac_t-Half*(dt-Ttry)*Hv)*Vsmall)/(dt*WFrac_av)
            ProducAct =  ProducPot * Ttry / dt
        End If
      End If

      Return

      End

      Subroutine Detcoef2(Iflsol,A1,A2,Avsocf,B1,B2,Hv,Hv1,Mto,T)
!.......................................................................
!  Subprogram:
!     Subroutine Detcoef - 
!
!  Description:
!     Determines the coefficients A1,A2,B1,B2 of the 
!     analytical solution of the conservation equation. 
!     Description of common variables:
!     Input:
!       IFLSOL        indicates the type of equation.
!       T             length of time interval (d)
!       HV            change of moisture content (d-1)
!       HV1           coefficient A within conservation equation (d-1)
!       MTO           moisture content at start of timestep (-)
!       AVSOCF        average value of adsorption coefficient (kg-1.m3)
!     Output:
!       A1,A2,B1,B2   coefficients (-) in the (average) concentration 
!                     relation according to:
!                            c(t) = A1 * c(t0) + A2 * HV2
!                            cav  = B1 * c(t0) + B2 * HV2   
!  History:
!    2003    Groenendijk, Renaud, Hendriks
!            Release of ANIMO4.0 
!.......................................................................
!---- Declarations
      use MOD_texture_orgmat, only: bdens
      Implicit None
!                                                       Formal Variables
      Integer, intent(in)  :: Iflsol
      real(8), intent(out) :: A1,A2,B1,B2
      real(8), intent(in)  :: Avsocf,Hv,Hv1,Mto,T
!                                                        Local Variables
      real(8), parameter :: One = 1.d0

      select case (Iflsol)
      case (1)
         A1 = ((Mto+bdens(1)*Avsocf+Hv*T)/(Mto+bdens(1)*Avsocf))**(-Hv1/hv)
         A2 = (One-A1)/hv1
         B1 = ((Mto+bdens(1)*Avsocf+Hv*T)/                                  &
              (Mto+bdens(1)*Avsocf))**((Hv-Hv1)/hv)-One
         B1 = B1*(Mto+bdens(1)*Avsocf)/(T* (Hv-Hv1))
         B2 = (One-B1)/hv1
      Return

      case (2)
         A1 = ((Mto+bdens(1)*Avsocf+Hv*T)/(Mto+bdens(1)*Avsocf))**(-Hv1/hv)
         A2 = (One-A1)/hv1
         B1 = (Mto+bdens(1)*Avsocf)/hv/t*log((Mto+bdens(1)*Avsocf+Hv*T)/        &
              (Mto+bdens(1)*Avsocf))
         B2 = (One-B1)/hv1
      Return

      case (3)
         A1 =  exp(-Hv1/(Mto+bdens(1)*Avsocf)*T)
         A2 = (One-A1)/hv1
         B1 = (One-A1)/(Hv1/(Mto+bdens(1)*Avsocf)*T)
         B2 = (One-B1)/hv1
      Return

      case (4)
         A1 = One
         A2 = One/hv*log((Mto+bdens(1)*Avsocf+Hv*T)/(Mto+bdens(1)*Avsocf))
         B1 = One
         B2 = A2*(Mto+bdens(1)*Avsocf+Hv*T)/(Hv*T) - One/hv
      Return

      case (5)
         A1 = One
         A2 = T/(Mto+bdens(1)*Avsocf)
         B1 = One
         B2 = 0.5d+00*T/(Mto+bdens(1)*Avsocf)

      case default
         call swap_error ('detcoef2', 'Illegal value for TASK')
      end select

      Return
      End 
