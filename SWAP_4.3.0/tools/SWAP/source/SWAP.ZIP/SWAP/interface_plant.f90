module plant_interface
   
   use MOD_arrays, only: magrs, macrop, macroptb, fillen

   implicit none
   
   ! crop
   integer,                                     save :: unit_crp                    ! unit number of crp-file (crop input)
   character(len = fillen),                     save :: crpfilnam                   ! filename crp-file
   integer,                                     save :: icrop                       ! current crop number
   real(8),               dimension(macrop),    save :: cropstart                   ! array with crop start dates
   real(8),               dimension(macrop),    save :: cropend                     ! array with crop end   dates
   character(len=fillen), dimension(macrop),    save :: cropfil                     ! array with names of crop files
   integer,               dimension(macrop),    save :: croptype                    ! switch for type of crop model: 1 = FIXED; 2 = WOFOST; 3 = LINGRA
   
   ! correction assimilation due to CO2
   real(8),                                     save :: co2                         ! CO2 concentration (ppm)
   real(8),                                     save :: fco2amax                    ! factor to correct AMAX (-)
   real(8),                                     save :: fco2eff                     ! factor to correct EFF (-)
   real(8),                                     save :: fco2tra                     ! factor to correct TRA (     -)

   ! crop sta  tus
   logical,                                     save :: fl_start_croprotation       ! flag indicating start of crop (rotation)
   logical,                                     save :: fl_start_cropemergence      ! flag indicating start of crop (emergence)
   logical,                                     save :: fl_cropemergence            ! flag indicating crop emergence
   logical,                                     save :: fl_cropharvest              ! flag indicating crop harvest
   logical,                                     save :: fl_cropharvestday           ! flag indicating day of crop harvest
   logical,                                     save :: fl_cropisreset              ! flag indicating crop reset has been performed
   
   integer,                                     save :: swcf                        ! switch for cropfactor: 1 = crop factor; 2 = crop height
   real(8),                                     save :: cf                          ! crop factor (-)
   real(8),                                     save :: ch                          ! crop height (cm)
   
   real(8),                                     save :: albedo                      ! crop reflection coefficient (-)
   real(8),                                     save :: rsc                         ! minimum canopy resistance of dry crop (T/L)
   real(8),                                     save :: rsw                         ! canopy resistance of intercepted water (T/L)
   
   real(8),                                     save :: kdif                        ! extinction coefficient for diffuse visible light (-)
   real(8),                                     save :: kdir                        ! extinction coefficient for direct visible light (-)
   real(8),                                     save :: vcover                      ! vegetation cover fraction (-)

   ! drought stress
   integer,                                     save :: sw_drought                  ! switch for drought stress: 1 = Feddes et al., 1978; 2 = De Jong van Lier et al., 2012; 3 = De Willigen et al., 1983   
   
   ! oxygen stress
   integer,                                     save :: sw_oxygen                   ! switch oxygen stress: 0 = no stress; 1 = Feddes et al. (1978); 2 = Bartholomeus et al. (2008)
   real(8),               dimension(macroptb),  save :: mrftb                       ! array with ratio root total respiration / maintenance respiration as function of development stage (kg/m3)
   real(8),                                     save :: max_resp_factor             ! ratio total respiration / maintenance respiration 
   real(8),                                     save :: q10_root                    ! relative increase in root respiration at temperature increase of 10 degree C
   real(8),                                     save :: c_mroot                     ! maintenance coefficient of root
   real(8),                                     save :: f_senes                     ! reduction factor for senescence, used for maintenance respiration

   ! interception
   integer,                                     save :: sw_inter                    ! switch for interception method: 0 = no interception; 1 = agricultural crops; 2 = trees and forests; 3 = Rutter
   real(8),                                     save :: dt_interc_event             ! maximum timestep for interception storage to reach minimum/maximum level

   ! Von Hoyningen-Hune and Braden
   real(8),                                     save :: cofab                       ! interception coefficient (L)

   ! Gash
   real(8),               dimension(macroptb),  save :: pfreetb                     ! free throughfall coefficient (-) as function of time (T)
   real(8),               dimension(macroptb),  save :: pstemtb                     ! stem flow coefficient (-) as function of time (T)
   real(8),               dimension(macroptb),  save :: scanopytb                   ! storage capacity of canopy (-) as function of time (T)
   real(8),               dimension(macroptb),  save :: avevaptb                    ! average evaporation intensity during shower (-) as function of time (T)
   real(8),               dimension(macroptb),  save :: avprectb                    ! average rainfall intensity (-) as function of time (T)

   ! Rutter
   real(8),                                     save :: siccaplai                   ! interception storage per unit of LAI (cm/LAI)
   real(8),                                     save :: siccap                      ! interception storage capacity of canopy (cm)
   real(8),                                     save :: sicact                      ! amount of water stored on canopy (cm)
   real(8),                                     save :: crsflx_in                   ! incoming flux canopy reservoir (cm d-1)
   real(8),                                     save :: crsflx_out                  ! outgoing flux canopy reservoir (cm d-1)
   real(8),                                     save :: siccaploss                  ! loss of canopy reservoir capacity due to falling leaves (cm)

   ! root development
   integer,                                     save :: swrd                        ! Switch for development of root extension
   integer,                                     save :: swrdc                       ! Switch for calculation of root density (0: static; 1: adaptive root development)
   integer,                                     save :: swwrtnonox                  ! limited root extension by aeration (oxygen stress)
   real(8),                                     save :: aeratecrit                  ! threshold to stop root extension in case of oxygen stress; 0.0 minimum oxygen stress, 1.0 maximum oxygenstress [0.0001..1.0 -, R]
   real(8),                                     save :: wrtmax                      ! maximum root weight
   real(8),                dimension(macroptb), save :: wroottb                     ! array with dry weight of plant root as function of development stage (kg/m3)
   integer,                                     save :: noddrz                      ! number of compartments in actual rootzone
   real(8),                                     save :: rd                          ! Rooting depth (L)
   
   ! status crop (actual development)
   real(8),                                     save :: dvs                         ! crop development stage (-)
   real(8),                                     save :: lai                         ! leaf area index (cm2/cm2)
   real(8),                                     save :: tsum                        ! temperature sum from emergence to harvest (degree C)

   real(8),                                     save :: wrt                         ! dry weight of plant root (kg/ha)
   real(8),                                     save :: wst                         ! dry weight of plant stem (kg/ha)
   real(8),                                     save :: wlv                         ! dry weight of plant leaves (kg/ha)
   real(8),                                     save :: wso                         ! dry weight of storage organ (kg/ha)

   real(8),                                     save :: dwrt                        ! dry weight of deceased plant root (kg/ha)
   real(8),                                     save :: dwst                        ! dry weight of deceased plant stem (kg/ha)
   real(8),                                     save :: dwlv                        ! dry weight of deceased plant leaves (kg/ha)

   real(8),                                     save :: grrt                        ! growth rate of dry weight of plant root (kg/ha)
   real(8),                                     save :: drrt                        ! death rate of dry weight of plant root (kg/ha)
   real(8),                                     save :: drst                        ! death rate of dry weight of plant stems (kg/ha)
   real(8),                                     save :: drlv                        ! death rate of dry weight of plant leaves (kg/ha)

   real(8),                                     save :: ipgass                      ! intermediate potential gross assimilation for actual crop (kg/ha)
   real(8),                                     save :: igass                       ! intermediate gross assimilation for actual crop (kg/ha)
   real(8),                                     save :: imres                       ! intermediate maintenance respiration for actual crop (kg/ha)
   
   ! status crop (potential development)
   real(8),                                     save :: laipot                      ! leaf area index  (cm2/cm2)
   
   real(8),                                     save :: wrtpot                      ! dry weight of plant root (kg/ha)
   real(8),                                     save :: wstpot                      ! dry weight of plant stem (kg/ha)
   real(8),                                     save :: wlvpot                      ! dry weight of plant leaves (kg/ha)
   real(8),                                     save :: wsopot                      ! dry weight of storage organ (kg/ha)
   
   real(8),                                     save :: dwrtpot                     ! dry weight of deceased plant root (kg/ha)
   real(8),                                     save :: dwstpot                     ! dry weight of deceased plant stem (kg/ha)
   real(8),                                     save :: dwlvpot                     ! dry weight of deceased plant leaves (kg/ha)
   
   real(8),                                     save :: grrtpot                     ! death rate of dry weight of plant root (kg/ha)
   
   real(8),                                     save :: ipgasspot                   ! intermediate potential gross assimilation for potential crop (kg/ha)
   real(8),                                     save :: igasspot                    ! intermediate gross assimilation for potential crop (kg/ha)
   real(8),                                     save :: imrespot                    ! intermediate maintenance respiration for potential crop (kg/ha)
   
   ! grass
   real(8),                                     save :: dmhrv                       ! total harvest by mowing or grazing
   real(8),                                     save :: dmloss                      ! total losses due to treading
   integer,                                     save :: icut                        ! cut number
   integer,                                     save :: tcut                        ! duration of cut
   
   real(8),                                     save :: dmhrvpot                    ! total harvest by mowing or grazing
   real(8),                                     save :: dmlosspot                   ! total losses due to treading
   integer,                                     save :: icutpot                     ! cut number
   integer,                                     save :: tcutpot                     ! duration of cut

   ! drought stress
   real(8),                                     save :: hlim3h                      ! pressure head below which water uptake reduction starts at high Tpot (L)
   real(8),                                     save :: hlim3l                      ! pressure head below which water uptake reduction starts at low Tpot (L)
   real(8),                                     save :: hlim4                       ! wilting point, no root water uptake at lower soil water pressure heads (L)

end module plant_interface
